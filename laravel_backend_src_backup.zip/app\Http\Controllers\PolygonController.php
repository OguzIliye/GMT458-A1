<?php

namespace App\Http\Controllers;

use App\Models\Polygon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class PolygonController extends Controller
{
    /**
     * Yeni bir poligon (bölge/kampüs vb.) oluşturur.
     * React tarafından gönderilen köşe koordinatlarını (lat, lng dizisi) alıp,
     * PostGIS'in anlayacağı "WKT" (Well-Known Text) formatına (POLYGON((...))) çevirerek kaydeder.
     */
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'category_id' => 'required|exists:categories,id',
            'description' => 'nullable|string',
            'link' => 'nullable|url|max:255',
            'links' => 'nullable|array',
            'links.*.title' => 'required|string|max:255',
            'links.*.url' => 'required|url|max:255',
            'type' => 'nullable|string|in:Polygon,LineString', // Çizgi mi Poligon mu?
            'coordinates' => 'required|array|min:2', // Çizgi için en az 2 nokta yeterli
            'coordinates.*.lat' => 'required|numeric',
            'coordinates.*.lng' => 'required|numeric',
            'parent_id' => 'nullable|integer',
            'parent_type' => 'nullable|string|in:App\Models\Marker,App\Models\Polygon',
            'new_images' => 'nullable|array',
            'new_images.*' => 'image|max:5120',
            'hide_symbology' => 'boolean',
        ]);

        $imagePaths = [];
        if ($request->hasFile('new_images')) {
            foreach ($request->file('new_images') as $image) {
                $path = $image->store('elements', 'public');
                $imagePaths[] = $path;
            }
        }

        $polygon = new Polygon;
        $polygon->name = $validated['name'];
        $polygon->description = $validated['description'] ?? null;
        $polygon->link = $validated['link'] ?? null;
        $polygon->links = $validated['links'] ?? null;
        $polygon->category_id = $validated['category_id'];
        $polygon->parent_id = $validated['parent_id'] ?? null;
        $polygon->parent_type = $validated['parent_type'] ?? null;
        $polygon->hide_symbology = $request->boolean('hide_symbology');
        $polygon->images = $imagePaths;
        /** @phpstan-ignore-next-line */
        $polygon->user_id = auth()->id();

        $type = $validated['type'] ?? 'Polygon'; // Varsayılan Polygon
        $coords = $validated['coordinates'];

        if ($type === 'Polygon') {
            // Ensure the polygon is closed (first and last point must be the same)
            $first = $coords[0];
            $last = end($coords);
            if ($first['lat'] !== $last['lat'] || $first['lng'] !== $last['lng']) {
                $coords[] = $first;
            }
        }

        $points = array_map(function ($coord) {
            return $coord['lng'].' '.$coord['lat'];
        }, $coords);

        if ($type === 'Polygon') {
            $wkt = 'POLYGON(('.implode(', ', $points).'))';
        } else {
            $wkt = 'LINESTRING('.implode(', ', $points).')';
        }

        /** @phpstan-ignore-next-line */
        $polygon->area = DB::raw("ST_GeomFromText('{$wkt}', 4326)");
        $polygon->save();

        return redirect()->back()->with('success', 'Poligon başarıyla eklendi.');
    }

    /**
     * Var olan bir poligonu günceller.
     * Sadece bilgileri (isim vb.) güncellenmiş olabilir veya köşeleri (koordinatları) değiştirilmiş olabilir.
     */
    public function update(Request $request, Polygon $polygon): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'category_id' => 'required|exists:categories,id',
            'description' => 'nullable|string',
            'link' => 'nullable|url|max:255',
            'links' => 'nullable|array',
            'links.*.title' => 'required|string|max:255',
            'links.*.url' => 'required|url|max:255',
            'type' => 'nullable|string|in:Polygon,LineString',
            'coordinates' => 'nullable|array|min:2', // At least 2 points if updating coords
            'coordinates.*.lat' => 'required_with:coordinates|numeric',
            'coordinates.*.lng' => 'required_with:coordinates|numeric',
            'parent_id' => 'nullable|integer',
            'parent_type' => 'nullable|string|in:App\Models\Marker,App\Models\Polygon',
            'new_images' => 'nullable|array',
            'new_images.*' => 'image|max:5120',
            'existing_images' => 'nullable|array',
            'existing_images.*' => 'string',
            'hide_symbology' => 'boolean',
        ]);

        $currentImages = $polygon->images ?? [];
        $keptImages = $request->input('existing_images', []);
        $removedImages = array_diff($currentImages, $keptImages);

        foreach ($removedImages as $removed) {
            Storage::disk('public')->delete($removed);
        }

        $imagePaths = $keptImages;
        if ($request->hasFile('new_images')) {
            foreach ($request->file('new_images') as $image) {
                $path = $image->store('elements', 'public');
                $imagePaths[] = $path;
            }
        }

        $polygon->name = $validated['name'];
        $polygon->description = $validated['description'] ?? null;
        $polygon->link = $validated['link'] ?? null;
        $polygon->links = $validated['links'] ?? null;
        $polygon->category_id = $validated['category_id'];
        $polygon->parent_id = $validated['parent_id'] ?? null;
        $polygon->parent_type = $validated['parent_type'] ?? null;
        $polygon->hide_symbology = $request->boolean('hide_symbology');
        $polygon->images = array_values($imagePaths);

        // Kendi kendisinin ebeveyni olmasını engelle
        if ($polygon->parent_type === 'App\Models\Polygon' && (int) $polygon->parent_id === (int) $polygon->id) {
            $polygon->parent_id = null;
            $polygon->parent_type = null;
        }

        if (! empty($validated['coordinates'])) {
            $type = $validated['type'] ?? 'Polygon';
            $coords = $validated['coordinates'];

            if ($type === 'Polygon') {
                $first = $coords[0];
                $last = end($coords);
                if ($first['lat'] !== $last['lat'] || $first['lng'] !== $last['lng']) {
                    $coords[] = $first;
                }
            }

            $points = array_map(function ($coord) {
                return $coord['lng'].' '.$coord['lat'];
            }, $coords);

            if ($type === 'Polygon') {
                $wkt = 'POLYGON(('.implode(', ', $points).'))';
            } else {
                $wkt = 'LINESTRING('.implode(', ', $points).')';
            }

            /** @phpstan-ignore-next-line */
            $polygon->area = DB::raw("ST_GeomFromText('{$wkt}', 4326)");
        }

        $polygon->save();

        return redirect()->back()->with('success', 'Poligon başarıyla güncellendi.');
    }

    /**
     * Poligonu veritabanından tamamen siler
     */
    public function destroy(Polygon $polygon): RedirectResponse
    {
        $polygon->delete();

        return redirect()->back()->with('success', 'Poligon başarıyla silindi.');
    }

    /**
     * Silinmiş poligonu geri getirir (Restore).
     */
    public function restore(int|string $id): RedirectResponse
    {
        /** @var Polygon $polygon */
        $polygon = Polygon::withTrashed()->findOrFail($id);
        $polygon->restore();

        return redirect()->back()->with('success', 'Poligon başarıyla geri getirildi.');
    }
}
