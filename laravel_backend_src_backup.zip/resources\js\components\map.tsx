import L from 'leaflet';
import iconRetinaUrl from 'leaflet/dist/images/marker-icon-2x.png';
import iconUrl from 'leaflet/dist/images/marker-icon.png';
import shadowUrl from 'leaflet/dist/images/marker-shadow.png';
import 'leaflet/dist/leaflet.css';
import '@geoman-io/leaflet-geoman-free';
import '@geoman-io/leaflet-geoman-free/dist/leaflet-geoman.css';
import React, { useEffect, useRef, useState, useImperativeHandle } from 'react';
import * as ReactDOMServer from 'react-dom/server';
import ReactMarkdown from 'react-markdown';
import remarkBreaks from 'remark-breaks';
import remarkGfm from 'remark-gfm';
import { getVisibleMidpoint } from './geometry';
import { AvailableIcons } from './icons';

delete (L.Icon.Default.prototype as L.Icon.Default & { _getIconUrl?: unknown })
    ._getIconUrl;

L.Icon.Default.mergeOptions({
    iconRetinaUrl,
    iconUrl,
    shadowUrl,
});

export type MapMarker = {
    id: string;
    lat: number;
    lng: number;
    title: string;
    description?: string;
    link?: string;
    images?: string[];
    category?: {
        name?: string;
        color?: string;
        icon?: string;
    } | null;
    parent_id?: string | number | null;
    parent_type?: string | null;
    _zoomHidden?: boolean;
    hide_symbology?: boolean;
};

export type MapPolygon = {
    id: string;
    geojson: string; // JSON string from DB
    title: string;
    description?: string;
    link?: string;
    images?: string[];
    category?: any;
    parent_id?: string | number | null;
    parent_type?: string | null;
    _zoomHidden?: boolean;
    hide_symbology?: boolean;
};

type MapProps = {
    center: [number, number];
    zoom?: number;
    markers?: MapMarker[];
    polygons?: MapPolygon[];
    className?: string;
    mode?:
        | 'pan'
        | 'add'
        | 'delete'
        | 'add-polygon'
        | 'add-linestring'
        | 'delete-polygon'
        | 'edit-polygon'
        | 'edit-linestring'
        | 'edit-marker';
    editingPolygonCoords?: { lat: number; lng: number }[];
    editingPolygonType?:
        'Polygon' | 'LineString' | 'MultiLineString' | 'MultiPolygon';
    editingPolygonCategory?: any;
    globalCanUndo?: boolean;
    globalCanRedo?: boolean;
    editCanUndo?: boolean;
    editCanRedo?: boolean;
    onMapClick?: (lat: number, lng: number) => void;
    onMarkerClick?: (marker: MapMarker) => void;
    onPolygonClick?: (polygon: MapPolygon) => void;
    onPolygonComplete?: (
        coords: { lat: number; lng: number }[],
        type: 'Polygon' | 'LineString' | 'MultiLineString' | 'MultiPolygon',
    ) => void;
    onPolygonEdit?: (
        points: { lat: number; lng: number }[],
        type: string,
    ) => void;
    onCancelEdit?: () => void;
    onZoomChange?: (zoom: number) => void;
    maxZoom?: number;
    isAdmin?: boolean;
};

export type MapRef = {
    flyTo: (lat: number, lng: number, zoom?: number) => void;
    fitBounds: (geojsonStr: string) => void;
};

export const Map = React.forwardRef<MapRef, MapProps>(
    (
        {
            center,
            zoom = 13,
            markers = [],
            polygons = [],
            className = 'h-full w-full',
            mode = 'pan',
            editingPolygonCoords,
            editingPolygonType = 'Polygon',
            editingPolygonCategory,
            onMapClick,
            onMarkerClick,
            onPolygonClick,
            onPolygonComplete,
            onPolygonEdit,
            onZoomChange,
            onCancelEdit,
            maxZoom = 19,
            isAdmin = false,
        },
        ref,
    ) => {
        const containerRef = useRef<HTMLDivElement>(null);
        const mapRef = useRef<L.Map | null>(null);

        // Drawing state for add-polygon
        const drawingLayerRef = useRef<L.LayerGroup | null>(null);
        const [drawingPoints, setDrawingPoints] = useState<L.LatLng[]>([]);
        const [, setRedoStack] = useState<L.LatLng[]>([]);

        useImperativeHandle(ref, () => ({
            flyTo: (lat: number, lng: number, zoomLvl: number = 18) => {
                if (mapRef.current) {
                    mapRef.current.flyTo([lat, lng], zoomLvl, {
                        duration: 1.5,
                    });
                }
            },
            fitBounds: (geojsonInput: string | object) => {
                if (mapRef.current) {
                    try {
                        const geojson =
                            typeof geojsonInput === 'string'
                                ? JSON.parse(geojsonInput)
                                : geojsonInput;
                        const layer = L.geoJSON(geojson);
                        mapRef.current.fitBounds(layer.getBounds(), {
                            padding: [50, 50],
                            duration: 1.5,
                        });
                    } catch (e) {
                        console.error('Geçersiz geojson', e);
                    }
                }
            },
        }));

        // Initialize Map
        useEffect(() => {
            if (!containerRef.current || mapRef.current) {
                return;
            }

            const map = L.map(containerRef.current, {
                center,
                zoom,
                doubleClickZoom: false, // Prevent zoom on double click when drawing
                maxZoom: maxZoom,
                zoomControl: false,
            });

            const satelliteLayer = L.tileLayer(
                'https://mt1.google.com/vt/lyrs=y&x={x}&y={y}&z={z}',
                {
                    attribution: 'Map data &copy; Google',
                    maxNativeZoom: 20,
                    maxZoom: maxZoom,
                },
            );

            satelliteLayer.addTo(map);

            L.control
                .scale({
                    position: 'bottomright',
                    metric: true,
                    imperial: false,
                })
                .addTo(map);

            L.control.zoom({ position: 'bottomright' }).addTo(map);

            mapRef.current = map;
            drawingLayerRef.current = L.layerGroup().addTo(map);

            return () => {
                map.remove();
                mapRef.current = null;
                drawingLayerRef.current = null;
            };
            // eslint-disable-next-line react-hooks/exhaustive-deps
        }, []); // Only run once on mount

        const [currentZoom, setCurrentZoom] = useState(zoom);

        // Handle Map Center/Zoom
        useEffect(() => {
            const map = mapRef.current;

            if (!map) {
                return;
            }

            map.setView(center, zoom);
            setCurrentZoom(zoom);
        }, [center, zoom]);

        // Track zoom level dynamically
        useEffect(() => {
            const map = mapRef.current;

            if (!map) {
                return;
            }

            const handleZoomEnd = () => {
                const z = map.getZoom();
                setCurrentZoom(z);

                if (onZoomChange) {
                    onZoomChange(z);
                }
            };

            map.on('zoomend', handleZoomEnd);

            return () => {
                map.off('zoomend', handleZoomEnd);
            };
        }, [onZoomChange]);

        // Clear drawing points when mode changes
        useEffect(() => {
            if (
                mode !== 'add-polygon' &&
                mode !== 'add-linestring' &&
                mode !== 'edit-polygon'
            ) {
                setDrawingPoints([]);
                setRedoStack([]);
                drawingLayerRef.current?.clearLayers();
            }
        }, [mode]);

        // Handle Map Clicks (dynamic based on mode)
        useEffect(() => {
            const map = mapRef.current;

            if (!map) {
                return;
            }

            const handleClick = (e: L.LeafletMouseEvent) => {
                const target = e.originalEvent.target as HTMLElement;

                // Eğer tıklama bir poligon (path), marker veya popup üzerinde gerçekleştiyse, harita tıklamasını yoksay
                if (
                    target &&
                    (target.tagName.toLowerCase() === 'path' ||
                        target.closest('.leaflet-marker-icon') ||
                        target.closest('.leaflet-popup'))
                ) {
                    return;
                }

                if (onMapClick) {
                    onMapClick(e.latlng.lat, e.latlng.lng);
                }

                if (mode === 'add-polygon' || mode === 'add-linestring') {
                    setDrawingPoints((prev) => [...prev, e.latlng]);
                    setRedoStack([]); // Clear redo stack on new action
                }
            };

            map.on('click', handleClick);

            return () => {
                map.off('click', handleClick);
            };
        }, [mode, onMapClick]);

        // Handle Ctrl+Z to undo last drawn point or deleted element
        useEffect(() => {
            const handleKeyDown = (e: KeyboardEvent) => {
                const target = e.target as HTMLElement;

                if (
                    target &&
                    (target.tagName === 'INPUT' ||
                        target.tagName === 'TEXTAREA' ||
                        target.isContentEditable)
                ) {
                    return; // Let the browser handle text undo/redo
                }

                if (e.ctrlKey || e.metaKey) {
                    if (
                        e.key.toLowerCase() === 'y' ||
                        (e.shiftKey && e.key.toLowerCase() === 'z')
                    ) {
                        e.preventDefault();
                        window.dispatchEvent(new Event('redo-polygon-point'));
                    } else if (e.key.toLowerCase() === 'z' && !e.shiftKey) {
                        e.preventDefault();
                        console.log('Ctrl+Z YAKALANDI!');
                        window.dispatchEvent(new Event('undo-polygon-point'));
                    }
                }
            };

            // Global document dinleyicisi
            document.addEventListener('keydown', handleKeyDown);

            // Custom event listener from UI button
            const handleUndoCustom = () => {
                setDrawingPoints((prev) => {
                    if (prev.length > 0) {
                        const newPoints = [...prev];
                        const popped = newPoints.pop();

                        if (popped) {
                            setRedoStack((r) => [...r, popped]);
                        }

                        return newPoints;
                    }

                    return prev;
                });
            };

            const handleRedoCustom = () => {
                setRedoStack((prev) => {
                    if (prev.length > 0) {
                        const newStack = [...prev];
                        const popped = newStack.pop();

                        if (popped) {
                            setDrawingPoints((pts) => [...pts, popped]);
                        }

                        return newStack;
                    }

                    return prev;
                });
            };

            window.addEventListener('undo-polygon-point', handleUndoCustom);
            window.addEventListener('redo-polygon-point', handleRedoCustom);

            return () => {
                document.removeEventListener('keydown', handleKeyDown);
                window.removeEventListener(
                    'undo-polygon-point',
                    handleUndoCustom,
                );
                window.removeEventListener(
                    'redo-polygon-point',
                    handleRedoCustom,
                );
            };
        }, [mode]);

        // Handle double click or right click to finish polygon
        useEffect(() => {
            const map = mapRef.current;

            if (!map) {
                return;
            }

            const handleFinish = (e: L.LeafletMouseEvent) => {
                if (mode === 'add-polygon' || mode === 'add-linestring') {
                    if (
                        e.type === 'dblclick' ||
                        ((e.type === 'mouseup' || e.type === 'mousedown') &&
                            e.originalEvent.button === 1)
                    ) {
                        if (e.originalEvent) {
                            e.originalEvent.preventDefault();
                            e.originalEvent.stopPropagation();
                        }

                        setDrawingPoints((currentPoints) => {
                            // For Polygon we need at least 3 points normally, but 2 might be a line.
                            // Let's allow finishing with >= 2 points for LineString.
                            if (currentPoints.length >= 2) {
                                // Create a final copy of points
                                const finalPoints = [...currentPoints];

                                // Clear state
                                setTimeout(() => {
                                    setDrawingPoints([]);

                                    if (drawingLayerRef.current) {
                                        drawingLayerRef.current.clearLayers();
                                    }

                                    if (onPolygonComplete) {
                                        onPolygonComplete(
                                            finalPoints.map((p) => ({
                                                lat: p.lat,
                                                lng: p.lng,
                                            })),
                                            mode === 'add-linestring'
                                                ? 'LineString'
                                                : editingPolygonType ||
                                                      'Polygon',
                                        );
                                    }
                                }, 10);

                                return currentPoints;
                            }

                            return currentPoints;
                        });
                    }
                }

                if (
                    (e.type === 'mouseup' || e.type === 'mousedown') &&
                    e.originalEvent.button === 1 &&
                    onCancelEdit
                ) {
                    if (e.originalEvent) {
                        e.originalEvent.preventDefault();
                        e.originalEvent.stopPropagation();
                    }

                    if (['edit-polygon', 'edit-marker'].includes(mode)) {
                        onCancelEdit();
                    }
                }
            };

            map.on('dblclick', handleFinish);
            map.on('mouseup', handleFinish);
            map.on('mousedown', handleFinish); // Catch M3 earlier

            return () => {
                map.off('dblclick', handleFinish);
                map.off('mouseup', handleFinish);
                map.off('mousedown', handleFinish);
            };
        }, [mode, onPolygonComplete, editingPolygonType, onCancelEdit]);

        // Draw the temporary or editable polygon
        useEffect(() => {
            const layer = drawingLayerRef.current;

            if (!layer || !mapRef.current) {
                return;
            }

            layer.clearLayers();

            if (
                (mode === 'add-polygon' ||
                    mode === 'add-linestring' ||
                    mode === 'edit-polygon') &&
                editingPolygonCoords &&
                editingPolygonCoords.length >= 2
            ) {
                // Remove consecutive duplicate points to prevent Geoman overlapping lock/kink bugs
                const removeConsecutiveDuplicates = (
                    coords: { lat: number; lng: number }[],
                ) => {
                    if (!coords || coords.length === 0) {
                        return [];
                    }

                    const threshold = 0.000001; // ~11 centimeters
                    const cleaned = [coords[0]];

                    for (let i = 1; i < coords.length; i++) {
                        const prev = cleaned[cleaned.length - 1];
                        const curr = coords[i];

                        if (
                            Math.abs(prev.lat - curr.lat) > threshold ||
                            Math.abs(prev.lng - curr.lng) > threshold
                        ) {
                            cleaned.push(curr);
                        }
                    }

                    return cleaned;
                };

                const cleanedCoords =
                    removeConsecutiveDuplicates(editingPolygonCoords);

                // Draw Geoman editable shape
                let shape;

                if (
                    editingPolygonType === 'LineString' ||
                    editingPolygonType === 'MultiLineString'
                ) {
                    shape = L.polyline(cleanedCoords, {
                        color: '#f59e0b',
                        weight: 3,
                    }).addTo(layer);
                } else {
                    shape = L.polygon(cleanedCoords, {
                        color: '#f59e0b',
                        weight: 2,
                        fillOpacity: 0.4,
                    }).addTo(layer);
                }

                // Enable Geoman editing for this layer
                shape.pm.enable({
                    allowSelfIntersection: true,
                    preventMarkerRemoval: false,
                    draggable: true,
                    snappable: true,
                    snapDistance: 15,
                });

                // Listen to edit events
                const handleEdit = () => {
                    const latlngs = shape.getLatLngs();

                    if (latlngs) {
                        let coords: { lat: number; lng: number }[] = [];

                        if (
                            editingPolygonType === 'LineString' ||
                            editingPolygonType === 'MultiLineString'
                        ) {
                            coords = (latlngs as L.LatLng[]).map((pt) => ({
                                lat: pt.lat,
                                lng: pt.lng,
                            }));
                        } else {
                            if (Array.isArray(latlngs) && latlngs.length > 0) {
                                coords = (latlngs[0] as L.LatLng[]).map(
                                    (pt) => ({ lat: pt.lat, lng: pt.lng }),
                                );
                            }
                        }

                        // Also clean them before sending to parent
                        if (coords) {
                            coords = removeConsecutiveDuplicates(coords);
                        }

                        if (onPolygonEdit && coords) {
                            onPolygonEdit(coords, editingPolygonType);
                        }
                    }
                };

                let centerMarker: L.Marker | null = null;

                if (
                    editingPolygonCategory &&
                    editingPolygonCategory.icon &&
                    editingPolygonCategory.icon !== 'None'
                ) {
                    const iconName = editingPolygonCategory.icon;
                    const IconComponent =
                        AvailableIcons[
                            iconName as keyof typeof AvailableIcons
                        ] || AvailableIcons.MapPin;
                    const iconHtml = ReactDOMServer.renderToString(
                        <IconComponent size={24} color="white" />,
                    );
                    const markerColor =
                        editingPolygonCategory.color || '#3b82f6';
                    const customDivIcon = L.divIcon({
                        className: 'custom-leaflet-icon',
                        html: `<div style="background-color: ${markerColor}; border-radius: 50%; padding: 6px; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 6px rgba(0,0,0,0.3); border: 2px solid white; position: relative; top: -18px; left: -18px; width: 40px; height: 40px; cursor: move;" title="Taşımak için sürükle">${iconHtml}</div>`,
                        iconSize: [0, 0],
                        iconAnchor: [0, 0],
                    });

                    let centerLatLng: L.LatLng;

                    if (shape instanceof L.Polygon) {
                        centerLatLng = shape.getBounds().getCenter();
                    } else {
                        centerLatLng = getVisibleMidpoint(
                            mapRef.current,
                            shape.getLatLngs() as L.LatLng[],
                        );
                    }

                    centerMarker = L.marker(centerLatLng, {
                        icon: customDivIcon,
                        interactive: true,
                        draggable: true,
                        zIndexOffset: 1000,
                    }).addTo(layer);
                }

                let previousLatLng: L.LatLng | null = null;

                if (centerMarker) {
                    previousLatLng = centerMarker.getLatLng();
                    centerMarker.on('drag', (e) => {
                        if (!previousLatLng) {
                            return;
                        }

                        const currentLatLng = e.target.getLatLng();
                        const latDiff = currentLatLng.lat - previousLatLng.lat;
                        const lngDiff = currentLatLng.lng - previousLatLng.lng;

                        const currentPoints = shape.getLatLngs();
                        const movePoints = (pts: any): any => {
                            if (Array.isArray(pts)) {
                                if (pts.length > 0 && Array.isArray(pts[0])) {
                                    return pts.map((p) => movePoints(p));
                                } else {
                                    return pts.map((p: any) => ({
                                        lat: p.lat + latDiff,
                                        lng: p.lng + lngDiff,
                                    }));
                                }
                            }

                            return pts;
                        };

                        shape.setLatLngs(movePoints(currentPoints));
                        previousLatLng = currentLatLng;
                    });

                    centerMarker.on('dragend', () => {
                        handleEditAndMove();
                    });
                }

                const handleEditAndMove = () => {
                    handleEdit();

                    if (centerMarker) {
                        let newCenter: L.LatLng;

                        if (shape instanceof L.Polygon) {
                            newCenter = shape.getBounds().getCenter();
                        } else {
                            newCenter = getVisibleMidpoint(
                                mapRef.current!,
                                shape.getLatLngs() as L.LatLng[],
                            );
                        }

                        centerMarker.setLatLng(newCenter);
                        previousLatLng = newCenter;
                    }
                };

                shape.on('pm:edit', handleEditAndMove);
                shape.on('pm:markerdragend', handleEditAndMove);
                shape.on('pm:vertexadded', handleEditAndMove);
                shape.on('pm:vertexremoved', handleEditAndMove);
                shape.on('pm:drag', handleEditAndMove);
                shape.on('pm:dragend', handleEditAndMove);
            } else if (drawingPoints.length > 0) {
                // Normal drawing mode
                drawingPoints.forEach((latlng, index) => {
                    const marker = L.circleMarker(latlng, {
                        radius: 6,
                        color: '#ef4444',
                        fillColor: '#ef4444',
                        fillOpacity: 1,
                        interactive: true,
                    }).addTo(layer);

                    marker.on('contextmenu', (e) => {
                        if (e.originalEvent) {
                            e.originalEvent.preventDefault();
                            e.originalEvent.stopPropagation();
                        }

                        setDrawingPoints((pts) => {
                            const newPts = [...pts];
                            newPts.splice(index, 1);

                            return newPts;
                        });
                    });
                });
                L.polyline(drawingPoints, {
                    color: '#3b82f6',
                    dashArray: '5, 5',
                    interactive: false,
                }).addTo(layer);

                if (drawingPoints.length > 2 && mode === 'add-polygon') {
                    L.polygon(drawingPoints, {
                        color: '#3b82f6',
                        fillOpacity: 0.2,
                        weight: 0,
                        interactive: false,
                    }).addTo(layer);
                }
            }
        }, [
            drawingPoints,
            editingPolygonCoords,
            mode,
            onPolygonEdit,
            editingPolygonType,
            editingPolygonCategory,
        ]);

        // Handle Cursors based on mode
        useEffect(() => {
            const mapContainer = containerRef.current;

            if (!mapContainer) {
                return;
            }

            if (
                mode === 'add' ||
                mode === 'add-polygon' ||
                mode === 'edit-polygon' ||
                mode === 'add-linestring' ||
                mode === 'edit-linestring' ||
                mode === 'edit-marker'
            ) {
                mapContainer.style.setProperty(
                    'cursor',
                    'crosshair',
                    'important',
                );
            } else if (mode === 'delete' || mode === 'delete-polygon') {
                mapContainer.style.setProperty(
                    'cursor',
                    'not-allowed',
                    'important',
                );
            } else {
                mapContainer.style.removeProperty('cursor');
            }

            const preventMiddleClickScroll = (e: MouseEvent) => {
                if (e.button === 1) {
                    e.preventDefault();
                }
            };

            mapContainer.addEventListener(
                'mousedown',
                preventMiddleClickScroll,
            );
            mapContainer.addEventListener('auxclick', preventMiddleClickScroll);

            return () => {
                mapContainer.removeEventListener(
                    'mousedown',
                    preventMiddleClickScroll,
                );
                mapContainer.removeEventListener(
                    'auxclick',
                    preventMiddleClickScroll,
                );
            };
        }, [mode]);

        // Handle Markers
        useEffect(() => {
            const map = mapRef.current;

            if (!map) {
                return;
            }

            const leafletMarkers = markers
                .filter(
                    (marker) =>
                        !marker.hide_symbology || marker.id === 'temp-marker',
                )
                .map((marker) => {
                    const isTemp = marker.id === 'temp-marker';

                    let markerOptions: L.MarkerOptions = {
                        interactive:
                            isTemp ||
                            (mode !== 'add' &&
                                mode !== 'add-polygon' &&
                                mode !== 'edit-polygon' &&
                                mode !== 'edit-marker'),
                    };

                    const markerColor = marker.category?.color || '#3b82f6';
                    const markerIconName = marker.category?.icon || 'MapPin';
                    const IconComponent =
                        AvailableIcons[
                            markerIconName as keyof typeof AvailableIcons
                        ] || AvailableIcons.MapPin;

                    const iconHtml = ReactDOMServer.renderToString(
                        <IconComponent size={24} color="white" />,
                    );

                    const customDivIcon = L.divIcon({
                        className: 'custom-leaflet-icon',
                        html: `<div style="background-color: ${markerColor}; border-radius: 50%; padding: 6px; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 6px rgba(0,0,0,0.3); border: 2px solid white; position: relative; top: -18px; left: -18px; width: 40px; height: 40px;">${iconHtml}</div>`,
                        iconSize: [0, 0],
                        iconAnchor: [0, 0],
                        popupAnchor: [0, -20],
                    });

                    markerOptions = { ...markerOptions, icon: customDivIcon };

                    if (isTemp) {
                        markerOptions = {
                            ...markerOptions,
                            draggable: true,
                            zIndexOffset: 1000,
                        };
                    } else if (marker.parent_id) {
                        markerOptions = {
                            ...markerOptions,
                            zIndexOffset: 500,
                        };
                    }

                    const m = L.marker([marker.lat, marker.lng], markerOptions);

                    if (marker.id === 'temp-marker') {
                        m.on('dragend', (e) => {
                            const latlng = e.target.getLatLng();

                            if (onMapClick) {
                                onMapClick(latlng.lat, latlng.lng);
                            }
                        });
                    }

                    if (isAdmin) {
                        if (mode === 'delete') {
                            m.on('click', () => {
                                if (onMarkerClick) {
                                    onMarkerClick(marker);
                                }
                            });
                            m.on('mouseover', (e) => {
                                if (e.target.getElement()) {
                                    e.target.getElement().style.cursor =
                                        'not-allowed';
                                }
                            });
                        } else {
                            // Admin modunda popup göster + Düzenle butonu
                            let descHtml = '';

                            if (marker.description) {
                                descHtml = ReactDOMServer.renderToString(
                                    <div className="prose prose-sm prose-a:text-blue-600 hover:prose-a:text-blue-500 max-w-none">
                                        <ReactMarkdown
                                            remarkPlugins={[
                                                remarkGfm,
                                                remarkBreaks,
                                            ]}
                                        >
                                            {marker.description}
                                        </ReactMarkdown>
                                    </div>,
                                );
                            }

                            let popupContent = `<strong>${marker.title}</strong>`;

                            if (descHtml) {
                                popupContent += `<br>${descHtml}`;
                            }

                            if (marker.link) {
                                popupContent += `<br><a href="${marker.link}" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:underline">Detaylı Bilgi</a>`;
                            }

                            popupContent += `<br><button onclick="window.dispatchEvent(new CustomEvent('edit-map-element', { detail: { id: '${marker.id}', type: 'marker' } }))" style="margin-top: 8px; padding: 4px 12px; background: #4f46e5; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 13px;">Düzenle</button>`;

                            m.bindPopup(popupContent);
                        }
                    } else {
                        let descHtml = '';

                        if (marker.description) {
                            descHtml = ReactDOMServer.renderToString(
                                <div className="prose prose-sm prose-a:text-blue-600 hover:prose-a:text-blue-500 max-w-none">
                                    <ReactMarkdown
                                        remarkPlugins={[
                                            remarkGfm,
                                            remarkBreaks,
                                        ]}
                                    >
                                        {marker.description}
                                    </ReactMarkdown>
                                </div>,
                            );
                        }

                        let popupContent = `<strong>${marker.title}</strong>`;

                        if (descHtml) {
                            popupContent += `<br>${descHtml}`;
                        }

                        if (marker.link) {
                            popupContent += `<br><a href="${marker.link}" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:underline">Detaylı Bilgi</a>`;
                        }

                        m.bindPopup(popupContent);
                        m.on('click', () => {
                            if (onMarkerClick) {
                                onMarkerClick(marker);
                            }
                        });
                    }

                    return m.addTo(map);
                });

            return () => {
                leafletMarkers.forEach((marker) => marker.remove());
            };
        }, [
            markers,
            zoom,
            mode,
            onMarkerClick,
            onMapClick,
            currentZoom,
            isAdmin,
        ]);

        // Handle Polygons
        useEffect(() => {
            const map = mapRef.current;

            if (!map) {
                return;
            }

            // Ebeveyn poligonların alta, çocukların üste çizilmesi için parent_id'ye göre sıralıyoruz
            const sortedPolygons = [...polygons].sort((a, b) => {
                const aHasParent = !!a.parent_id;
                const bHasParent = !!b.parent_id;

                if (aHasParent && !bHasParent) {
                    return 1;
                }

                if (!aHasParent && bHasParent) {
                    return -1;
                }

                return 0;
            });

            const leafletPolygons = sortedPolygons
                .map((polygon) => {
                    try {
                        const isZoomHidden = polygon._zoomHidden;
                        const geojson = JSON.parse(polygon.geojson);
                        const polyColor = polygon.category?.color || '#f59e0b';
                        const fillOpacity = isZoomHidden ? 0 : 0.4;
                        const weight = 2;

                        const isLine = geojson.type === 'LineString';

                        // GeoJSON verisini al ve polyColor değişkeni ile şekli çiz (varsayılan turuncu)
                        const polyLayer = L.geoJSON(geojson, {
                            style: {
                                color: polyColor,
                                weight: isLine ? 3 : weight,
                                fillOpacity: fillOpacity,
                                fill: !isLine,
                            },
                            interactive:
                                !isZoomHidden &&
                                mode !== 'add' &&
                                mode !== 'add-polygon' &&
                                mode !== 'edit-polygon' &&
                                mode !== 'edit-marker',
                        });

                        // Leaflet'te katman grubu (layerGroup) oluşturuyoruz, çünkü poligonun merkezine ikon da ekleyeceğiz. İkisini gruplamak işimizi kolaylaştırıyor.
                        const group = L.layerGroup([polyLayer]);

                        if (
                            polygon.category &&
                            !isZoomHidden &&
                            !polygon.hide_symbology
                        ) {
                            const iconName = polygon.category?.icon || 'MapPin';

                            if (iconName !== 'None') {
                                let center = polyLayer.getBounds().getCenter();
                                const isLineString =
                                    geojson.type === 'LineString';

                                let points: L.LatLng[] = [];

                                if (isLineString) {
                                    const layers = polyLayer.getLayers();

                                    if (
                                        layers.length > 0 &&
                                        typeof (layers[0] as L.Polyline)
                                            .getLatLngs === 'function'
                                    ) {
                                        points = (
                                            layers[0] as L.Polyline
                                        ).getLatLngs() as L.LatLng[];
                                        center = getVisibleMidpoint(
                                            map,
                                            points,
                                        );
                                    }
                                }

                                // İlgili Lucide ikonunu getir
                                const IconComponent =
                                    AvailableIcons[
                                        iconName as keyof typeof AvailableIcons
                                    ] || AvailableIcons.MapPin;

                                // React ikonunu, Leaflet'in anlayacağı düz HTML metnine çevir (bu sayede Leaflet divIcon içinde kullanabiliriz)
                                const iconHtml = ReactDOMServer.renderToString(
                                    <IconComponent
                                        size={16}
                                        color={
                                            polygon.category?.color || '#000'
                                        }
                                    />,
                                );

                                // Leaflet'in özel divIcon özelliği sayesinde dairesel beyaz zeminli bir HTML ikonu oluşturuyoruz
                                const customDivIcon = L.divIcon({
                                    className: 'custom-leaflet-icon-poly',
                                    html: `<div style="
                                        background-color: white; 
                                        border: 2px solid ${polygon.category?.color || '#000'}; 
                                        border-radius: 50%; 
                                        width: 36px; 
                                        height: 36px; 
                                        display: flex; 
                                        align-items: center; 
                                        justify-content: center; 
                                        box-shadow: 0 4px 6px rgba(0,0,0,0.3);
                                    ">${iconHtml}</div>`,
                                    iconSize: [24, 24],
                                    iconAnchor: [12, 12],
                                });

                                // İkonu haritada tam merkeze sabitle ve tıklanabilir yap
                                const centerMarker = L.marker(center, {
                                    icon: customDivIcon,
                                    interactive: true,
                                });
                                group.addLayer(centerMarker);

                                if (isLineString && points.length > 0) {
                                    const updateCenterMarker = () => {
                                        const newCenter = getVisibleMidpoint(
                                            map,
                                            points,
                                        );
                                        centerMarker.setLatLng(newCenter);
                                    };
                                    map.on('move', updateCenterMarker);
                                    centerMarker.on('remove', () =>
                                        map.off('move', updateCenterMarker),
                                    );
                                }
                            }
                        }

                        // Eğer isAdmin verilmişse (Yönetim paneli)
                        if (isAdmin) {
                            if (
                                mode === 'delete' ||
                                mode === 'delete-polygon'
                            ) {
                                // Silme modunda direkt tıklama
                                polyLayer.on('click', () => {
                                    if (onPolygonClick) {
                                        onPolygonClick(polygon);
                                    }
                                });

                                group.eachLayer((layer) => {
                                    if (
                                        layer !== polyLayer &&
                                        layer instanceof L.Marker
                                    ) {
                                        layer.on('click', () => {
                                            if (onPolygonClick) {
                                                onPolygonClick(polygon);
                                            }
                                        });
                                    }
                                });

                                polyLayer.on('mouseover', (e) => {
                                    if (e.layer && e.layer.getElement) {
                                        const el = e.layer.getElement();

                                        if (el) {
                                            el.style.cursor = 'not-allowed';
                                        }
                                    }
                                });
                            } else {
                                // Admin modunda popup göster + Düzenle butonu
                                let descHtml = '';

                                if (polygon.description) {
                                    descHtml = ReactDOMServer.renderToString(
                                        <div className="prose prose-sm prose-a:text-blue-600 hover:prose-a:text-blue-500 max-w-none">
                                            <ReactMarkdown
                                                remarkPlugins={[
                                                    remarkGfm,
                                                    remarkBreaks,
                                                ]}
                                            >
                                                {polygon.description}
                                            </ReactMarkdown>
                                        </div>,
                                    );
                                }

                                let popupContent = `<strong>${polygon.title}</strong>`;

                                if (descHtml) {
                                    popupContent += `<br>${descHtml}`;
                                }

                                if (polygon.link) {
                                    popupContent += `<br><a href="${polygon.link}" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:underline">Detaylı Bilgi</a>`;
                                }

                                popupContent += `<br><button onclick="window.dispatchEvent(new CustomEvent('edit-map-element', { detail: { id: '${polygon.id}', type: 'polygon' } }))" style="margin-top: 8px; padding: 4px 12px; background: #4f46e5; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 13px;">Düzenle</button>`;

                                polyLayer.bindPopup(popupContent);

                                // Semboloji ikonuna da aynı popup'ı bağla
                                group.eachLayer((layer) => {
                                    if (
                                        layer !== polyLayer &&
                                        layer instanceof L.Marker
                                    ) {
                                        layer.bindPopup(popupContent);
                                    }
                                });
                            }
                        } else {
                            // Normal moddaysak (silme modunda değilsek), poligonun açıklamalarını Popup (baloncuk) içerisine ekle
                            let descHtml = '';

                            if (polygon.description) {
                                // Markdown kodunu (<br>, kalın yazı, link) düzgün render etmesi için ReactDOMServer ile HTML'e dönüştür
                                descHtml = ReactDOMServer.renderToString(
                                    <div className="prose prose-sm prose-a:text-blue-600 hover:prose-a:text-blue-500 max-w-none">
                                        <ReactMarkdown
                                            remarkPlugins={[
                                                remarkGfm,
                                                remarkBreaks,
                                            ]}
                                        >
                                            {polygon.description}
                                        </ReactMarkdown>
                                    </div>,
                                );
                            }

                            let popupContent = `<strong>${polygon.title}</strong>`;

                            if (descHtml) {
                                popupContent += `<br>${descHtml}`;
                            }

                            if (polygon.link) {
                                popupContent += `<br><a href="${polygon.link}" target="_blank" rel="noopener noreferrer" class="text-blue-600 hover:underline">Detaylı Bilgi</a>`;
                            }

                            polyLayer.bindPopup(popupContent);
                            polyLayer.on('click', () => {
                                if (onPolygonClick) {
                                    onPolygonClick(polygon);
                                }
                            });

                            // Semboloji ikonuna tıklanınca da aynı popup'ı göster
                            group.eachLayer((layer) => {
                                if (
                                    layer !== polyLayer &&
                                    layer instanceof L.Marker
                                ) {
                                    layer.bindPopup(popupContent);
                                    layer.on('click', () => {
                                        if (onPolygonClick) {
                                            onPolygonClick(polygon);
                                        }
                                    });
                                }
                            });
                        }

                        return group.addTo(map);
                    } catch (e) {
                        console.error('Geçersiz geojson formatı:', e);

                        return null;
                    }
                })
                .filter((layer) => layer !== null) as L.LayerGroup[];

            return () => {
                leafletPolygons.forEach((layer) => layer.remove());
            };
        }, [polygons, zoom, mode, onPolygonClick, currentZoom, isAdmin]);

        return (
            <>
                <style
                    dangerouslySetInnerHTML={{
                        __html: `
                .map-mode-wrapper.add-mode .leaflet-interactive, .map-mode-wrapper.add-polygon-mode .leaflet-interactive, .map-mode-wrapper.add-linestring-mode .leaflet-interactive { cursor: crosshair !important; }
                .map-mode-wrapper.delete-mode .leaflet-interactive, .map-mode-wrapper.delete-polygon-mode .leaflet-interactive { cursor: not-allowed !important; }
            `,
                    }}
                />
                <div ref={containerRef} className={className} />
            </>
        );
    },
);

export default React.forwardRef<MapRef, MapProps>(
    function MapWrapper(props, ref) {
        const modeClass =
            props.mode === 'add'
                ? 'add-mode'
                : props.mode === 'delete'
                  ? 'delete-mode'
                  : props.mode === 'add-polygon'
                    ? 'add-polygon-mode'
                    : props.mode === 'add-linestring'
                      ? 'add-linestring-mode'
                      : props.mode === 'delete-polygon'
                        ? 'delete-polygon-mode'
                        : '';

        return (
            <div
                className={`map-mode-wrapper relative ${props.className || 'h-full w-full'} ${modeClass}`}
            >
                <Map {...props} ref={ref} className="h-full w-full" />

                {(props.mode === 'add-polygon' ||
                    props.mode === 'add-linestring') && (
                    <div className="absolute left-1/2 top-4 z-[1000] flex w-[55vw] -translate-x-1/2 items-center justify-center rounded bg-white px-4 py-3 text-center text-sm font-semibold text-gray-700 shadow-lg md:w-auto">
                        <span className="leading-snug">
                            Haritaya tıklayarak köşeleri belirleyin. Bitirmek
                            için orta (M3) veya çift tıklayın.
                        </span>
                    </div>
                )}

                {(props.mode === 'add-polygon' ||
                    props.mode === 'add-linestring' ||
                    props.globalCanUndo ||
                    props.globalCanRedo ||
                    props.editCanUndo ||
                    props.editCanRedo) && (
                    <div className="undo-redo-container absolute bottom-4 left-4 z-[1000] flex gap-2 transition-all duration-300">
                        <button
                            type="button"
                            onClick={() =>
                                window.dispatchEvent(
                                    new Event('undo-polygon-point'),
                                )
                            }
                            className="flex items-center gap-1 rounded bg-white px-3 py-2 text-sm font-medium text-gray-700 shadow hover:bg-gray-50"
                            title="Geri Al (Ctrl+Z)"
                        >
                            <svg
                                className="h-4 w-4"
                                fill="none"
                                stroke="currentColor"
                                viewBox="0 0 24 24"
                            >
                                <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth={2}
                                    d="M3 10h10a8 8 0 018 8v2M3 10l6 6m-6-6l6-6"
                                />
                            </svg>
                            Geri Al
                        </button>
                        <button
                            type="button"
                            onClick={() =>
                                window.dispatchEvent(
                                    new Event('redo-polygon-point'),
                                )
                            }
                            className="flex items-center gap-1 rounded bg-white px-3 py-2 text-sm font-medium text-gray-700 shadow hover:bg-gray-50"
                            title="İleri Al (Ctrl+Y)"
                        >
                            <svg
                                className="h-4 w-4"
                                fill="none"
                                stroke="currentColor"
                                viewBox="0 0 24 24"
                            >
                                <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth={2}
                                    d="M21 10h-10a8 8 0 00-8 8v2M21 10l-6 6m6-6l-6-6"
                                />
                            </svg>
                            İleri Al
                        </button>
                    </div>
                )}
            </div>
        );
    },
);
