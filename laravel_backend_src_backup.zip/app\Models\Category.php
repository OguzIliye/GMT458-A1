<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Spatie\Activitylog\Models\Concerns\LogsActivity;
use Spatie\Activitylog\Support\LogOptions;

class Category extends Model
{
    use LogsActivity;

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['name', 'type'])
            ->logOnlyDirty()
            ->dontLogEmptyChanges();
    }

    protected $fillable = [
        'name',
        'type',
        'icon',
        'color',
        'order',
        'min_zoom',
        'max_zoom',
        'border_always_visible',
    ];

    protected $casts = [
        'border_always_visible' => 'boolean',
    ];

    /**
     * @return HasMany<Marker, $this>
     */
    public function markers(): HasMany
    {
        return $this->hasMany(Marker::class);
    }
}
