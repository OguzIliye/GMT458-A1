<?php

use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ImportExportController;
use App\Http\Controllers\MarkerController;
use App\Http\Controllers\PolygonController;
use App\Http\Controllers\ProfileController;
use App\Models\Category;
use App\Models\Marker;
use App\Models\PageVisit;
use App\Models\Polygon;
use App\Models\User;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;
use Spatie\Activitylog\Models\Activity;

Route::get('/', fn () => Inertia::render('Welcome', [
    'canLogin' => Route::has('login'),
    'canRegister' => Route::has('register'),
    'laravelVersion' => Application::VERSION,
    'phpVersion' => PHP_VERSION,
]));

Route::get('/harita', fn () => Inertia::render('map/demo', [
    'markers' => Marker::with('category')->select(
        'id', 'name', 'description', 'category_id', 'user_id', 'created_at', 'link', 'links', 'images', 'parent_id', 'parent_type', 'hide_symbology',
        DB::raw('ST_X(location::geometry) as longitude'),
        DB::raw('ST_Y(location::geometry) as latitude')
    )->get(),
    'polygons' => Polygon::with('category')->select(
        'id', 'name', 'description', 'category_id', 'user_id', 'created_at', 'link', 'links', 'images', 'parent_id', 'parent_type', 'hide_symbology',
        DB::raw('ST_AsGeoJSON(area) as geojson')
    )->get(),
]))->name('harita');

Route::get('/dashboard', function () {
    $recentActivities = Activity::with('causer')->latest()->take(10)->get()->map(function (Activity $act) {
        /** @var User|null $causer */
        $causer = $act->causer;

        return [
            'id' => $act->id,
            'user' => $causer ? $causer->name : 'Sistem',
            'action' => $act->event === 'created' ? 'Oluşturuldu' : ($act->event === 'updated' ? 'Güncellendi' : 'Silindi'),
            'details' => data_get($act->properties, 'attributes.name', $act->subject_type),
            'time' => $act->created_at ? $act->created_at->diffForHumans() : '',
            'event' => $act->event,
        ];
    });

    $chartData = PageVisit::selectRaw('visit_date as date, count(id) as visitors')
        ->groupBy('visit_date')
        ->orderBy('visit_date', 'desc')
        ->take(7)
        ->get()
        ->reverse()
        ->values();

    $stats = [
        'markers' => Marker::count(),
        'polygons' => Polygon::count(),
        'visitors_today' => PageVisit::where('visit_date', now()->toDateString())->count(),
    ];

    return Inertia::render('Admin/Dashboard', [
        'recentActivities' => $recentActivities,
        'chartData' => $chartData,
        'stats' => $stats,
    ]);
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    Route::get('/dashboard/markers', fn () => Inertia::render('Admin/Markers/Index', [
        'markers' => Marker::with('category')->select(
            'id', 'name', 'description', 'category_id', 'user_id', 'created_at', 'link', 'links', 'images', 'parent_id', 'parent_type', 'hide_symbology',
            DB::raw('ST_X(location::geometry) as longitude'),
            DB::raw('ST_Y(location::geometry) as latitude')
        )->get(),
        'polygons' => Polygon::with('category')->select(
            'id', 'name', 'description', 'category_id', 'user_id', 'created_at', 'link', 'links', 'images', 'parent_id', 'parent_type', 'hide_symbology',
            DB::raw('ST_AsGeoJSON(area) as geojson')
        )->get(),
        'categories' => Category::orderBy('order')->get(),
    ]))->name('markers.index');
    Route::post('/dashboard/markers', [MarkerController::class, 'store'])->name('markers.store');
    Route::put('/dashboard/markers/{marker}', [MarkerController::class, 'update'])->name('markers.update');
    Route::delete('/dashboard/markers/{marker}', [MarkerController::class, 'destroy'])->name('markers.destroy');
    Route::post('/dashboard/markers/{id}/restore', [MarkerController::class, 'restore'])->name('markers.restore');

    Route::post('/dashboard/polygons', [PolygonController::class, 'store'])->name('polygons.store');
    Route::put('/dashboard/polygons/{polygon}', [PolygonController::class, 'update'])->name('polygons.update');
    Route::delete('/dashboard/polygons/{polygon}', [PolygonController::class, 'destroy'])->name('polygons.destroy');
    Route::post('/dashboard/polygons/{id}/restore', [PolygonController::class, 'restore'])->name('polygons.restore');

    Route::post('/dashboard/categories/reorder', [CategoryController::class, 'reorder'])->name('categories.reorder');
    Route::post('/dashboard/categories', [CategoryController::class, 'store'])->name('categories.store');
    Route::put('/dashboard/categories/{category}', [CategoryController::class, 'update'])->name('categories.update');
    Route::delete('/dashboard/categories/{category}', [CategoryController::class, 'destroy'])->name('categories.destroy');

    Route::get('/dashboard/export', [ImportExportController::class, 'export'])->name('export');
    Route::post('/dashboard/geojson-import', [ImportExportController::class, 'importGeoJson'])->name('geojson.import');
    Route::post('/dashboard/convert-gpkg', [ImportExportController::class, 'convertGpkg'])->name('gpkg.convert');
});
require __DIR__.'/auth.php';
