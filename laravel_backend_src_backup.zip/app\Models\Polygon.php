<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\Models\Concerns\LogsActivity;
use Spatie\Activitylog\Support\LogOptions;

class Polygon extends Model
{
    use LogsActivity, SoftDeletes;

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['name', 'description'])
            ->logOnlyDirty()
            ->dontLogEmptyChanges();
    }

    protected $fillable = [
        'name',
        'description',
        'link',
        'links',
        'images',
        'category_id',
        'user_id',
        'parent_id',
        'parent_type',
        'hide_symbology',
    ];

    protected $casts = [
        'links' => 'array',
        'images' => 'array',
        'hide_symbology' => 'boolean',
    ];

    protected static function booted(): void
    {
        static::forceDeleting(function (Polygon $polygon) {
            $polygon->childMarkers()->update(['parent_id' => null, 'parent_type' => null]);
            $polygon->childPolygons()->update(['parent_id' => null, 'parent_type' => null]);
        });
    }

    /**
     * @return BelongsTo<Category, $this>
     */
    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    /**
     * @return BelongsTo<User, $this>
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * @return MorphTo<Model, $this>
     */
    public function parent(): MorphTo
    {
        return $this->morphTo();
    }

    /**
     * @return MorphMany<Marker, $this>
     */
    public function childMarkers(): MorphMany
    {
        return $this->morphMany(Marker::class, 'parent');
    }

    /**
     * @return MorphMany<Polygon, $this>
     */
    public function childPolygons(): MorphMany
    {
        return $this->morphMany(Polygon::class, 'parent');
    }
}
