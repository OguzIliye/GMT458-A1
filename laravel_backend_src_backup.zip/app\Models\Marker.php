<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\Relations\MorphTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Spatie\Activitylog\Models\Concerns\LogsActivity;
use Spatie\Activitylog\Support\LogOptions;

class Marker extends Model
{
    use LogsActivity, SoftDeletes;

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['name', 'description'])
            ->logOnlyDirty()
            ->dontLogEmptyChanges();
    }

    protected $fillable = [
        'name',
        'description',
        'category_id',
        'user_id',
        'location',
        'link',
        'links',
        'images',
        'parent_id',
        'parent_type',
        'hide_symbology',
    ];

    protected $casts = [
        'links' => 'array',
        'images' => 'array',
        'hide_symbology' => 'boolean',
    ];

    protected static function booted(): void
    {
        static::forceDeleting(function (Marker $marker) {
            $marker->childMarkers()->update(['parent_id' => null, 'parent_type' => null]);
            $marker->childPolygons()->update(['parent_id' => null, 'parent_type' => null]);
        });
    }

    /**
     * @return BelongsTo<Category, $this>
     */
    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    /**
     * @return BelongsTo<User, $this>
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * @return MorphTo<Model, $this>
     */
    public function parent(): MorphTo
    {
        return $this->morphTo();
    }

    /**
     * @return MorphMany<Marker, $this>
     */
    public function childMarkers(): MorphMany
    {
        return $this->morphMany(Marker::class, 'parent');
    }

    /**
     * @return MorphMany<Polygon, $this>
     */
    public function childPolygons(): MorphMany
    {
        return $this->morphMany(Polygon::class, 'parent');
    }
}
