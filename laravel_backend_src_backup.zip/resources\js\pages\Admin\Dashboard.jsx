import React from 'react';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head } from '@inertiajs/react';
import {
    Activity,
    Clock,
    User,
    MapPin,
    Edit3,
    Trash2,
    PlusCircle,
} from 'lucide-react';
import {
    LineChart,
    Line,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    ResponsiveContainer,
} from 'recharts';

export default function Dashboard({
    auth,
    recentActivities = [],
    chartData = [],
    stats = {},
}) {
    // Yardımcı fonksiyon: log action türüne göre icon/renk belirle
    const getIconDetails = (event) => {
        switch (event) {
            case 'created':
                return {
                    icon: PlusCircle,
                    color: 'text-green-500',
                    bg: 'bg-green-100',
                };
            case 'updated':
                return {
                    icon: Edit3,
                    color: 'text-blue-500',
                    bg: 'bg-blue-100',
                };
            case 'deleted':
                return {
                    icon: Trash2,
                    color: 'text-red-500',
                    bg: 'bg-red-100',
                };
            default:
                return {
                    icon: Activity,
                    color: 'text-gray-500',
                    bg: 'bg-gray-100',
                };
        }
    };

    return (
        <AuthenticatedLayout
            user={auth.user}
            header={
                <h2 className="text-xl font-semibold leading-tight text-gray-800">
                    Aktivite Takip Paneli
                </h2>
            }
        >
            <Head title="Aktivite Takip" />

            <div className="py-6">
                <div className="mx-auto max-w-7xl sm:px-6 lg:px-8">
                    {/* İstatistik Kartları */}
                    <div className="mb-6 grid grid-cols-1 gap-6 md:grid-cols-3">
                        <div className="overflow-hidden bg-white p-6 shadow-sm sm:rounded-lg">
                            <div className="flex items-center">
                                <div className="rounded-full bg-indigo-100 p-3 text-indigo-600">
                                    <MapPin size={24} />
                                </div>
                                <div className="ml-4">
                                    <h3 className="text-lg font-medium text-gray-900">
                                        Toplam İşaretçi
                                    </h3>
                                    <p className="text-2xl font-semibold text-gray-700">
                                        {stats.markers || 0}
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div className="overflow-hidden bg-white p-6 shadow-sm sm:rounded-lg">
                            <div className="flex items-center">
                                <div className="rounded-full bg-purple-100 p-3 text-purple-600">
                                    <Activity size={24} />
                                </div>
                                <div className="ml-4">
                                    <h3 className="text-lg font-medium text-gray-900">
                                        Toplam Poligon
                                    </h3>
                                    <p className="text-2xl font-semibold text-gray-700">
                                        {stats.polygons || 0}
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div className="overflow-hidden bg-white p-6 shadow-sm sm:rounded-lg">
                            <div className="flex items-center">
                                <div className="rounded-full bg-blue-100 p-3 text-blue-600">
                                    <User size={24} />
                                </div>
                                <div className="ml-4">
                                    <h3 className="text-lg font-medium text-gray-900">
                                        Bugünkü Ziyaretçi
                                    </h3>
                                    <p className="text-2xl font-semibold text-gray-700">
                                        {stats.visitors_today || 0}
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Grafik Alanı */}
                    <div className="mb-6 overflow-hidden bg-white p-6 shadow-sm sm:rounded-lg">
                        <h3 className="mb-4 border-b pb-2 text-lg font-medium text-gray-900">
                            Son 7 Günün Ziyaretçi Grafiği
                        </h3>
                        <div className="h-64 w-full">
                            {chartData.length > 0 ? (
                                <ResponsiveContainer width="100%" height="100%">
                                    <LineChart
                                        data={chartData}
                                        margin={{
                                            top: 5,
                                            right: 20,
                                            bottom: 5,
                                            left: 0,
                                        }}
                                    >
                                        <CartesianGrid strokeDasharray="3 3" />
                                        <XAxis dataKey="date" />
                                        <YAxis allowDecimals={false} />
                                        <Tooltip />
                                        <Line
                                            type="monotone"
                                            dataKey="visitors"
                                            stroke="#8884d8"
                                            strokeWidth={2}
                                            name="Ziyaretçi"
                                        />
                                    </LineChart>
                                </ResponsiveContainer>
                            ) : (
                                <div className="flex h-full items-center justify-center text-gray-500">
                                    Henüz yeterli ziyaretçi verisi yok.
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Son Aktiviteler Listesi */}
                    <div className="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                        <div className="p-6 text-gray-900">
                            <h3 className="mb-4 border-b pb-2 text-lg font-medium text-gray-900">
                                Son Aktiviteler
                            </h3>
                            <div className="flow-root">
                                <ul role="list" className="-mb-8">
                                    {recentActivities.length > 0 ? (
                                        recentActivities.map(
                                            (activity, itemIdx) => {
                                                const {
                                                    icon: Icon,
                                                    color,
                                                    bg,
                                                } = getIconDetails(
                                                    activity.event,
                                                );
                                                return (
                                                    <li key={activity.id}>
                                                        <div className="relative pb-8">
                                                            {itemIdx !==
                                                            recentActivities.length -
                                                                1 ? (
                                                                <span
                                                                    className="absolute left-5 top-5 -ml-px h-full w-0.5 bg-gray-200"
                                                                    aria-hidden="true"
                                                                />
                                                            ) : null}
                                                            <div className="relative flex items-start space-x-3">
                                                                <div className="relative">
                                                                    <div
                                                                        className={`flex h-10 w-10 items-center justify-center rounded-full ring-8 ring-white ${bg}`}
                                                                    >
                                                                        <Icon
                                                                            className={`h-5 w-5 ${color}`}
                                                                            aria-hidden="true"
                                                                        />
                                                                    </div>
                                                                </div>
                                                                <div className="min-w-0 flex-1 py-1.5">
                                                                    <div className="text-sm text-gray-500">
                                                                        <span className="font-medium text-gray-900">
                                                                            {
                                                                                activity.user
                                                                            }
                                                                        </span>{' '}
                                                                        {
                                                                            activity.action
                                                                        }
                                                                    </div>
                                                                    <div className="mt-2 text-sm text-gray-700">
                                                                        <p>
                                                                            {
                                                                                activity.details
                                                                            }
                                                                        </p>
                                                                    </div>
                                                                    <div className="mt-2 text-xs text-gray-400">
                                                                        {
                                                                            activity.time
                                                                        }
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                );
                                            },
                                        )
                                    ) : (
                                        <div className="text-center text-sm text-gray-500">
                                            Kayıtlı aktivite bulunamadı.
                                        </div>
                                    )}
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
