export default function ApplicationLogo(props) {
    return <img {...props} src="/AHBVU_Logo.png" alt="AHBVU Logo" />;
}
