export const mapConfig = {
    DEFAULT_MAX_ZOOM: 19,
    ADMIN_MAX_ZOOM: 25,
    DEFAULT_CENTER: [39.7919, 32.8066] as [number, number],
    DEFAULT_ZOOM: 12,
    DEMO_DEFAULT_ZOOM: 14,
    FOCUS_ZOOM: 18,
};
