import L from 'leaflet';

/**
 * Clips a line segment (p1, p2) to a bounding box (bounds).
 * Returns the clipped segment [p1_clipped, p2_clipped] or null if completely outside.
 */
function clipSegment(
    p1: L.Point,
    p2: L.Point,
    bounds: L.Bounds,
): [L.Point, L.Point] | null {
    let x0 = p1.x,
        y0 = p1.y,
        x1 = p2.x,
        y1 = p2.y;
    const min = bounds.min,
        max = bounds.max;

    // Cohen-Sutherland outcodes
    const INSIDE = 0,
        LEFT = 1,
        RIGHT = 2,
        BOTTOM = 4,
        TOP = 8;

    const computeOutCode = (x: number, y: number) => {
        let code = INSIDE;

        if (x < min!.x) {
            code |= LEFT;
        } else if (x > max!.x) {
            code |= RIGHT;
        }

        if (y < min!.y) {
            code |= TOP;
        } else if (y > max!.y) {
            code |= BOTTOM;
        }

        return code;
    };

    let outcode0 = computeOutCode(x0, y0);
    let outcode1 = computeOutCode(x1, y1);
    let accept = false;

    while (true) {
        if (!(outcode0 | outcode1)) {
            accept = true;
            break;
        } else if (outcode0 & outcode1) {
            break;
        } else {
            let x = 0,
                y = 0;
            const outcodeOut = outcode0 ? outcode0 : outcode1;

            if (outcodeOut & TOP) {
                x = x0 + ((x1 - x0) * (min!.y - y0)) / (y1 - y0);
                y = min!.y;
            } else if (outcodeOut & BOTTOM) {
                x = x0 + ((x1 - x0) * (max!.y - y0)) / (y1 - y0);
                y = max!.y;
            } else if (outcodeOut & RIGHT) {
                y = y0 + ((y1 - y0) * (max!.x - x0)) / (x1 - x0);
                x = max!.x;
            } else if (outcodeOut & LEFT) {
                y = y0 + ((y1 - y0) * (min!.x - x0)) / (x1 - x0);
                x = min!.x;
            }

            if (outcodeOut === outcode0) {
                x0 = x;
                y0 = y;
                outcode0 = computeOutCode(x0, y0);
            } else {
                x1 = x;
                y1 = y;
                outcode1 = computeOutCode(x1, y1);
            }
        }
    }

    if (accept) {
        return [new L.Point(x0, y0), new L.Point(x1, y1)];
    }

    return null;
}

/**
 * Finds the midpoint of the visible portion of a polyline.
 * If the polyline is outside the view, it returns the closest point to the center.
 */
export function getVisibleMidpoint(
    map: L.Map,
    polylineLatLngs: any[],
): L.LatLng {
    if (!polylineLatLngs || polylineLatLngs.length === 0) {
        return map.getCenter();
    }

    const flatPoints: L.LatLng[] = [];
    const flatten = (arr: any[]) => {
        for (const item of arr) {
            if (Array.isArray(item)) {
                flatten(item);
            } else if (item && typeof item.lat === 'number') {
                flatPoints.push(item);
            }
        }
    };
    flatten(polylineLatLngs);

    if (flatPoints.length === 0) {
        return map.getCenter();
    }

    if (flatPoints.length === 1) {
        return flatPoints[0];
    }

    const mapBounds = map.getBounds();
    // Expand bounds slightly so the marker doesn't abruptly vanish at the exact edge
    const padX = map.getSize().x * 0.1;
    const padY = map.getSize().y * 0.1;
    const nw = map.latLngToLayerPoint(mapBounds.getNorthWest());
    const se = map.latLngToLayerPoint(mapBounds.getSouthEast());

    const bounds = L.bounds(
        new L.Point(nw.x - padX, nw.y - padY),
        new L.Point(se.x + padX, se.y + padY),
    );

    let totalLength = 0;
    const visibleSegments: { p1: L.Point; p2: L.Point; length: number }[] = [];

    for (let i = 0; i < flatPoints.length - 1; i++) {
        const p1 = map.latLngToLayerPoint(flatPoints[i]);
        const p2 = map.latLngToLayerPoint(flatPoints[i + 1]);

        const clipped = clipSegment(p1, p2, bounds);

        if (clipped) {
            const length = clipped[0].distanceTo(clipped[1]);

            // Sadece gerçekten görünür bir uzunluğu olanları ekle
            if (length > 0.001) {
                visibleSegments.push({
                    p1: clipped[0],
                    p2: clipped[1],
                    length,
                });
                totalLength += length;
            }
        }
    }

    if (totalLength === 0) {
        // Fallback: completely outside map, use first point or closest point logic
        // But if outside map, user can't see it anyway, so returning [0] is fine
        return flatPoints[Math.floor(flatPoints.length / 2)];
    }

    let targetLength = totalLength / 2;

    for (const seg of visibleSegments) {
        if (targetLength <= seg.length) {
            const ratio = targetLength / seg.length;
            const x = seg.p1.x + (seg.p2.x - seg.p1.x) * ratio;
            const y = seg.p1.y + (seg.p2.y - seg.p1.y) * ratio;

            return map.layerPointToLatLng(new L.Point(x, y));
        }

        targetLength -= seg.length;
    }

    return map.layerPointToLatLng(
        visibleSegments[visibleSegments.length - 1].p2,
    );
}
