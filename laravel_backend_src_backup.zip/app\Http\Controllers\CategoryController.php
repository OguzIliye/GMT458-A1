<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Marker;
use App\Models\Polygon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    /**
     * Yeni bir kategori (örneğin "Fakülteler", "Kafeteryalar") oluşturur.
     * Bu kategoriler hem markerlar (işaretçiler) hem de poligonlar (bölgeler) için kullanılabilir.
     */
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255|unique:categories,name',
            'type' => 'nullable|string|in:marker,polygon,linestring',
            'icon' => 'nullable|string|max:255', // Lucide ikon kütüphanesindeki ikon adı (Örn: MapPin, Coffee)
            'color' => 'nullable|string|max:255', // HEX renk kodu (Örn: #ff0000)
            'min_zoom' => 'nullable|integer',
            'max_zoom' => 'nullable|integer',
            'border_always_visible' => 'nullable|boolean',
        ]);

        $category = new Category;
        $category->name = $validated['name'];
        if (isset($validated['type'])) {
            $category->type = $validated['type'];
        }
        if (isset($validated['icon'])) {
            $category->icon = $validated['icon'];
        }
        if (isset($validated['color'])) {
            $category->color = $validated['color'];
        }
        $category->min_zoom = $validated['min_zoom'] ?? null;
        $category->max_zoom = $validated['max_zoom'] ?? null;
        $category->border_always_visible = $validated['border_always_visible'] ?? false;

        // Yeni eklenen kategori varsayılan olarak en sona eklensin
        $maxOrder = Category::max('order') ?? 0;
        $category->order = $maxOrder + 1;

        $category->save();

        return redirect()->back()->with('success', 'Kategori başarıyla eklendi.');
    }

    /**
     * Kategorilerin sırasını günceller.
     */
    public function reorder(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'categories' => 'required|array',
            'categories.*.id' => 'required|exists:categories,id',
            'categories.*.order' => 'required|integer',
        ]);

        foreach ($validated['categories'] as $categoryData) {
            Category::where('id', $categoryData['id'])->update(['order' => $categoryData['order']]);
        }

        return redirect()->back()->with('success', 'Katman sıralaması kaydedildi.');
    }

    /**
     * Var olan bir kategoriyi günceller.
     */
    public function update(Request $request, Category $category): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255|unique:categories,name,'.$category->id,
            'type' => 'nullable|string|in:marker,polygon,linestring',
            'icon' => 'nullable|string|max:255',
            'color' => 'nullable|string|max:255',
            'min_zoom' => 'nullable|integer',
            'max_zoom' => 'nullable|integer',
            'border_always_visible' => 'nullable|boolean',
        ]);

        $category->name = $validated['name'];
        if (isset($validated['type'])) {
            $category->type = $validated['type'];
        }
        $category->icon = $validated['icon'] ?? null;
        $category->color = $validated['color'] ?? null;
        $category->min_zoom = $validated['min_zoom'] ?? null;
        $category->max_zoom = $validated['max_zoom'] ?? null;
        if (isset($validated['border_always_visible'])) {
            $category->border_always_visible = $validated['border_always_visible'];
        }

        $category->save();

        return redirect()->back()->with('success', 'Kategori başarıyla güncellendi.');
    }

    /**
     * Kategoriyi siler. Ancak kategorinin içerisinde herhangi bir öğe varsa güvenlik
     * amacıyla (veritabanı hatası almamak için) silmeyi reddeder.
     */
    public function destroy(Category $category): RedirectResponse
    {
        // Check if category is used by any markers or polygons
        // Bu kategoriye atanmış herhangi bir işaretçi veya poligon olup olmadığını kontrol et
        $markersCount = Marker::where('category_id', $category->id)->count();
        $polygonsCount = Polygon::where('category_id', $category->id)->count();

        // Eğer kategori kullanımda ise kullanıcıya hata mesajı döndür
        if ($markersCount > 0 || $polygonsCount > 0) {
            return redirect()->back()->with('error', 'Bu kategoriye ait harita öğeleri (marker veya poligon) olduğu için kategori silinemez. Lütfen önce ilgili öğeleri silin veya kategorilerini değiştirin.');
        }

        $category->delete();

        return redirect()->back()->with('success', 'Kategori başarıyla silindi.');
    }
}
