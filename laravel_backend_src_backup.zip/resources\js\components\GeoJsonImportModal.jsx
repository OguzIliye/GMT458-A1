import React, { useState } from 'react';
import { router } from '@inertiajs/react';
import { AvailableIcons } from './icons';

const GeoJsonImportModal = ({ isOpen, onClose, categories }) => {
    const [fileData, setFileData] = useState(null); // Parsed GeoJSON
    const [propertyKeys, setPropertyKeys] = useState([]);
    const [selectedProperty, setSelectedProperty] = useState('');
    const [uniqueValues, setUniqueValues] = useState([]);

    // Mapping: { [uniqueValue]: { type: 'existing'|'new', categoryId: null, newName: '', newColor: '#f59e0b', newIcon: 'MapPin' } }
    const [mapping, setMapping] = useState({});
    const [step, setStep] = useState(1); // 1: Upload, 2: Select Property, 3: Map Values

    const [isLoading, setIsLoading] = useState(false);

    const processGeoJson = (geojson) => {
        if (geojson.type !== 'FeatureCollection' || !geojson.features) {
            alert(
                'Geçersiz GeoJSON dosyası. "FeatureCollection" tipinde olmalıdır.',
            );
            return;
        }

        setFileData(geojson);

        let keys = new Set();
        geojson.features.forEach((f) => {
            if (f.properties) {
                Object.keys(f.properties).forEach((k) => keys.add(k));
            }
        });

        setPropertyKeys(Array.from(keys));
        setStep(2);
    };

    const handleFileUpload = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        if (file.name.toLowerCase().endsWith('.gpkg')) {
            setIsLoading(true);
            const formData = new FormData();
            formData.append('file', file);

            try {
                const response = await window.axios.post(
                    route('gpkg.convert'),
                    formData,
                    {
                        headers: { 'Content-Type': 'multipart/form-data' },
                    },
                );

                processGeoJson(response.data);
            } catch (err) {
                alert(
                    'GPKG dönüştürülürken hata oluştu: ' +
                        (err.response?.data?.error || err.message),
                );
            } finally {
                setIsLoading(false);
            }
            return;
        }

        const reader = new FileReader();
        reader.onload = (event) => {
            try {
                const geojson = JSON.parse(event.target.result);
                processGeoJson(geojson);
            } catch (err) {
                alert('Dosya okunurken bir hata oluştu: ' + err.message);
            }
        };
        reader.readAsText(file);
    };

    const handlePropertySelect = () => {
        if (!selectedProperty && propertyKeys.length > 0) return;

        let values = new Set();
        fileData.features.forEach((f) => {
            const val = f.properties?.[selectedProperty];
            if (val) values.add(val.toString());
        });

        const vals = Array.from(values);
        setUniqueValues(vals);

        // Initialize mapping
        let initialMap = {};
        vals.forEach((v) => {
            // Otomatik kategori algılama (küçük/büyük harf duyarsız eşleşme)
            const existingCat = categories.find(
                (c) => c.name.toLowerCase() === v.toLowerCase(),
            );

            initialMap[v] = {
                type: existingCat ? 'existing' : 'new',
                categoryId: existingCat ? existingCat.id : '',
                newName: v,
                newColor: existingCat ? existingCat.color : '#3b82f6',
                newIcon: existingCat ? existingCat.icon || 'MapPin' : 'MapPin',
            };
        });
        setMapping(initialMap);
        setStep(3);
    };

    const updateMapping = (val, key, newValue) => {
        setMapping((prev) => ({
            ...prev,
            [val]: { ...prev[val], [key]: newValue },
        }));
    };

    const handleImport = () => {
        // Validate
        for (let val of uniqueValues) {
            const m = mapping[val];
            if (m.type === 'existing' && !m.categoryId) {
                alert(
                    `Lütfen "${val}" için bir kategori seçin veya yeni oluşturun.`,
                );
                return;
            }
        }

        // Prepare payload
        const payload = {
            features: fileData.features,
            mapping: mapping,
            property_key: selectedProperty,
        };

        router.post(route('geojson.import'), payload, {
            onSuccess: () => {
                alert('İçe aktarma başarıyla tamamlandı!');
                onClose();
            },
            onError: (err) => {
                alert('Hata oluştu: ' + JSON.stringify(err));
            },
        });
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
            <div className="flex max-h-[90vh] w-full max-w-3xl flex-col overflow-hidden rounded-lg bg-white shadow-xl">
                <div className="flex items-center justify-between border-b p-4">
                    <h2 className="text-lg font-bold">
                        Akıllı GeoJSON İçe Aktarma Sihirbazı
                    </h2>
                    <button
                        onClick={onClose}
                        className="text-2xl font-bold text-gray-500 hover:text-gray-700"
                    >
                        &times;
                    </button>
                </div>

                <div className="flex-1 overflow-y-auto p-6">
                    {step === 1 && (
                        <div className="py-10 text-center">
                            <h3 className="mb-4 font-medium text-gray-700">
                                İçe aktarmak istediğiniz GeoJSON veya GeoPackage
                                (.gpkg) dosyasını seçin
                            </h3>
                            <input
                                type="file"
                                accept=".geojson,.json,.gpkg"
                                onChange={handleFileUpload}
                                disabled={isLoading}
                                className="mx-auto block w-full max-w-sm cursor-pointer text-sm text-gray-500 file:mr-4 file:rounded-md file:border-0 file:bg-indigo-50 file:px-4 file:py-2 file:text-sm file:font-semibold file:text-indigo-700 hover:file:bg-indigo-100 disabled:opacity-50"
                            />
                            {isLoading && (
                                <p className="mt-4 animate-pulse text-sm text-indigo-600">
                                    GeoPackage dosyası okunuyor, lütfen
                                    bekleyin...
                                </p>
                            )}
                        </div>
                    )}

                    {step === 2 && (
                        <div>
                            <h3 className="mb-2 font-semibold">
                                Kategori Sütununu Seçin
                            </h3>
                            <p className="mb-4 text-sm text-gray-500">
                                GeoJSON dosyanızdaki şekillerin kategorilerini
                                (katmanlarını) belirleyen özelliği seçin.
                            </p>

                            <select
                                value={selectedProperty}
                                onChange={(e) =>
                                    setSelectedProperty(e.target.value)
                                }
                                className="mb-4 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                            >
                                <option value="">Seçiniz...</option>
                                {propertyKeys.map((k) => (
                                    <option key={k} value={k}>
                                        {k}
                                    </option>
                                ))}
                            </select>

                            <button
                                onClick={handlePropertySelect}
                                disabled={!selectedProperty}
                                className="rounded-md bg-indigo-600 px-4 py-2 text-white hover:bg-indigo-700 disabled:bg-gray-400"
                            >
                                İleri
                            </button>
                        </div>
                    )}

                    {step === 3 && (
                        <div>
                            <h3 className="mb-2 font-semibold">
                                Katmanları Eşleştirin
                            </h3>
                            <p className="mb-4 text-sm text-gray-500">
                                GeoJSON dosyasında bulunan katman isimlerini
                                sisteminizdeki kategorilerle eşleştirin veya
                                yepyeni bir kategori oluşturun.
                            </p>

                            <div className="space-y-4">
                                {uniqueValues.map((val) => (
                                    <div
                                        key={val}
                                        className="rounded-md border bg-gray-50 p-4"
                                    >
                                        <div className="mb-3 font-medium text-gray-800">
                                            Bulunan Değer:{' '}
                                            <span className="text-indigo-600">
                                                "{val}"
                                            </span>
                                        </div>

                                        <div className="flex flex-col items-start gap-4 sm:flex-row">
                                            <div className="w-full sm:w-1/3">
                                                <select
                                                    value={mapping[val].type}
                                                    onChange={(e) =>
                                                        updateMapping(
                                                            val,
                                                            'type',
                                                            e.target.value,
                                                        )
                                                    }
                                                    className="block w-full rounded-md border-gray-300 shadow-sm sm:text-sm"
                                                >
                                                    <option value="existing">
                                                        Mevcut Kategoriye Bağla
                                                    </option>
                                                    <option value="new">
                                                        Yeni Kategori Oluştur
                                                    </option>
                                                </select>
                                            </div>

                                            <div className="w-full sm:w-2/3">
                                                {mapping[val].type ===
                                                'existing' ? (
                                                    <select
                                                        value={
                                                            mapping[val]
                                                                .categoryId
                                                        }
                                                        onChange={(e) =>
                                                            updateMapping(
                                                                val,
                                                                'categoryId',
                                                                e.target.value,
                                                            )
                                                        }
                                                        className="block w-full rounded-md border-gray-300 shadow-sm sm:text-sm"
                                                    >
                                                        <option value="">
                                                            -- Kategori Seç --
                                                        </option>
                                                        {categories.map((c) => (
                                                            <option
                                                                key={c.id}
                                                                value={c.id}
                                                            >
                                                                {c.name}
                                                            </option>
                                                        ))}
                                                    </select>
                                                ) : (
                                                    <div className="flex gap-2">
                                                        <input
                                                            type="text"
                                                            placeholder="Kategori Adı"
                                                            value={
                                                                mapping[val]
                                                                    .newName
                                                            }
                                                            onChange={(e) =>
                                                                updateMapping(
                                                                    val,
                                                                    'newName',
                                                                    e.target
                                                                        .value,
                                                                )
                                                            }
                                                            className="block w-full rounded-md border-gray-300 shadow-sm sm:text-sm"
                                                        />
                                                        <input
                                                            type="color"
                                                            value={
                                                                mapping[val]
                                                                    .newColor
                                                            }
                                                            onChange={(e) =>
                                                                updateMapping(
                                                                    val,
                                                                    'newColor',
                                                                    e.target
                                                                        .value,
                                                                )
                                                            }
                                                            className="h-9 w-12 cursor-pointer rounded border-0 p-0"
                                                        />
                                                        <select
                                                            value={
                                                                mapping[val]
                                                                    .newIcon
                                                            }
                                                            onChange={(e) =>
                                                                updateMapping(
                                                                    val,
                                                                    'newIcon',
                                                                    e.target
                                                                        .value,
                                                                )
                                                            }
                                                            className="block w-32 rounded-md border-gray-300 shadow-sm sm:text-sm"
                                                        >
                                                            {Object.keys(
                                                                AvailableIcons,
                                                            ).map((icon) => (
                                                                <option
                                                                    key={icon}
                                                                    value={icon}
                                                                >
                                                                    {icon}
                                                                </option>
                                                            ))}
                                                        </select>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>

                {step === 3 && (
                    <div className="flex justify-end border-t bg-gray-50 p-4">
                        <button
                            onClick={handleImport}
                            className="rounded-md bg-indigo-600 px-6 py-2 font-medium text-white shadow-sm hover:bg-indigo-700"
                        >
                            İçe Aktar ve Kaydet
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default GeoJsonImportModal;
