import { Head, Link } from '@inertiajs/react';
import {
    ChevronDown,
    ChevronRight,
    Menu,
    X,
    Eye,
    EyeOff,
    Search,
    Info,
} from 'lucide-react';
import React, { useState, useRef, useMemo, useCallback } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkBreaks from 'remark-breaks';
import remarkGfm from 'remark-gfm';
import { AvailableIcons } from '@/components/icons';
import Map from '@/components/map';
import type { MapRef } from '@/components/map';
import { mapConfig } from '@/config/mapConfig';
export default function MapDemo({
    markers = [],
    polygons = [],
}: {
    markers?: any[];
    polygons?: any[];
}) {
    const mapRef = useRef<MapRef>(null);
    const [sidebarOpen, setSidebarOpen] = useState(
        typeof window !== 'undefined' ? window.innerWidth >= 768 : true,
    );
    const [detailsOpen, setDetailsOpen] = useState(false);
    const [selectedElement, setSelectedElement] = useState<any>(null);
    const [expandedCategories, setExpandedCategories] = useState<
        Record<string, boolean>
    >({});
    const [expandedItems, setExpandedItems] = useState<Record<string, boolean>>(
        {},
    );
    const [hiddenItems, setHiddenItems] = useState<Record<string, boolean>>({});
    const [mapZoom, setMapZoom] = useState(mapConfig.DEMO_DEFAULT_ZOOM);
    const [searchQuery, setSearchQuery] = useState('');
    const [isolatedElementId, setIsolatedElementId] = useState<string | null>(
        null,
    );
    const [sidebarWidth, setSidebarWidth] = useState(320);
    const [isResizing, setIsResizing] = useState(false);

    // Backend'den gelen (veritabanı formatındaki) marker verilerini, Harita bileşenimizin (Map) beklediği formata dönüştürüyoruz.
    const dbMarkers = useMemo(() => {
        return (markers || [])
            .filter((m) => m && m.latitude && m.longitude)
            .map((m) => {
                let _zoomHidden = false;

                if (m.category) {
                    if (m.category.min_zoom && mapZoom < m.category.min_zoom) {
                        _zoomHidden = true;
                    }

                    if (m.category.max_zoom && mapZoom > m.category.max_zoom) {
                        _zoomHidden = true;
                    }
                }

                return {
                    id: 'm-' + m.id,
                    lat: Number(m.latitude),
                    lng: Number(m.longitude),
                    title: m.name || '',
                    description: m.description || '',
                    link: m.link || '',
                    links: m.links || [],
                    images: m.images || [],
                    category: m.category || {
                        id: 0,
                        name: 'Diğer İşaretçiler',
                    },
                    type: 'marker',
                    _zoomHidden,
                    hide_symbology: m.hide_symbology,
                };
            });
    }, [markers, mapZoom]);

    // Aynı işlemi poligon verileri için yapıyoruz.
    const mapPolygons = useMemo(() => {
        return (polygons || []).map((p) => {
            let _zoomHidden = false;

            if (p.category) {
                if (p.category.min_zoom && mapZoom < p.category.min_zoom) {
                    _zoomHidden = true;
                }

                if (p.category.max_zoom && mapZoom > p.category.max_zoom) {
                    _zoomHidden = true;
                }
            }

            return {
                id: 'p-' + p.id,
                geojson: p.geojson,
                title: p.name || '',
                description: p.description || '',
                link: p.link || '',
                links: p.links || [],
                images: p.images || [],
                category: p.category || { id: 0, name: 'Diğer Poligonlar' },
                parent_id: p.parent_id,
                parent_type: p.parent_type,
                type: 'polygon',
                _zoomHidden,
                hide_symbology: p.hide_symbology,
            };
        });
    }, [polygons, mapZoom]);

    // Tüm marker ve poligonları kategorilerine göre gruplayan fonksiyon (useMemo ile sadece veriler değiştiğinde çalışır).
    const categoriesMap = useMemo(() => {
        const allItems = [...dbMarkers, ...mapPolygons].map((item) => ({
            ...item,
            children: [],
        }));

        const itemMap = new window.Map();
        allItems.forEach((item) => itemMap.set(item.id, item));

        const rootItems: any[] = [];

        // Build the item tree (Parent -> Children)
        allItems.forEach((item) => {
            let parentRef = null;
            // Original records from backend are in markers/polygons arrays.
            // We need to look up parent_id and parent_type from the original arrays.
            const originalSource = item.type === 'marker' ? markers : polygons;
            const originalData = originalSource?.find(
                (d) => d.id === parseInt(item.id.split('-')[1]),
            );

            if (originalData?.parent_id && originalData?.parent_type) {
                const prefix =
                    originalData.parent_type === 'App\\Models\\Marker'
                        ? 'm-'
                        : 'p-';
                parentRef = prefix + originalData.parent_id;
            }

            if (parentRef && itemMap.has(parentRef)) {
                itemMap.get(parentRef).children.push(item);
            } else {
                rootItems.push(item);
            }
        });

        // Helper to group items by category
        const groupByCategory = (items: any[]) => {
            const groups: Record<
                string,
                {
                    id: number;
                    name: string;
                    icon?: string;
                    color?: string;
                    items: any[];
                }
            > = {};
            items.forEach((item) => {
                const catId = item.category?.id || 0;
                const catName = item.category?.name || 'Kategorisiz';
                const catIcon = item.category?.icon || 'MapPin';
                const catColor = item.category?.color || '#3b82f6';

                if (!groups[catId]) {
                    groups[catId] = {
                        id: catId,
                        name: catName,
                        icon: catIcon,
                        color: catColor,
                        items: [],
                    };
                }

                groups[catId].items.push(item);
            });

            return Object.values(groups).sort((a, b) =>
                a.name.localeCompare(b.name),
            );
        };

        // Recursively group children
        const recursivelyGroup = (items: any[]) => {
            items.forEach((item) => {
                if (item.children.length > 0) {
                    item.childCategories = groupByCategory(item.children);
                    recursivelyGroup(item.children);
                }
            });
        };

        recursivelyGroup(rootItems);

        return groupByCategory(rootItems);
    }, [dbMarkers, mapPolygons, markers, polygons]);

    // Seçili elementin parent yolunu (kategorileri ve parent öğeleri) aç
    React.useEffect(() => {
        if (!selectedElement) {
            return;
        }

        const expandPath = () => {
            const newExpandedCats: Record<string, boolean> = {};
            const newExpandedItems: Record<string, boolean> = {};

            const elementIdNum = parseInt(
                String(selectedElement.id).split('-')[1],
            );
            const elementType = selectedElement.type;
            const sourceArray = elementType === 'marker' ? markers : polygons;
            let elementData = sourceArray?.find((d) => d.id === elementIdNum);

            while (elementData) {
                if (elementData.category_id) {
                    newExpandedCats[elementData.category_id] = true;
                }

                if (elementData.parent_id && elementData.parent_type) {
                    const prefix =
                        elementData.parent_type === 'App\\Models\\Marker'
                            ? 'm-'
                            : 'p-';
                    newExpandedItems[prefix + elementData.parent_id] = true;

                    const parentSource =
                        elementData.parent_type === 'App\\Models\\Marker'
                            ? markers
                            : polygons;
                    elementData = parentSource?.find(
                        (d) => d.id === elementData.parent_id,
                    );
                } else {
                    elementData = null;
                }
            }

            if (Object.keys(newExpandedCats).length > 0) {
                setExpandedCategories((prev) => ({
                    ...prev,
                    ...newExpandedCats,
                }));
            }

            if (Object.keys(newExpandedItems).length > 0) {
                setExpandedItems((prev) => ({ ...prev, ...newExpandedItems }));
            }

            setTimeout(() => {
                const domId = `sidebar-item-${selectedElement.type}-${selectedElement.id}`;
                const el = document.getElementById(domId);

                if (el) {
                    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
            }, 100);
        };

        expandPath();
    }, [selectedElement, markers, polygons]);

    const handleZoomChange = useCallback((zoomLvl: number) => {
        setMapZoom(zoomLvl);
    }, []);

    // Yan menüde kategorilerin açılıp kapanmasını (genişletilmesini) sağlar.
    const toggleCategory = (catId: string) => {
        setExpandedCategories((prev) => ({ ...prev, [catId]: !prev[catId] }));
    };

    // Yan menüde her bir öğenin (marker/poligon) açıklamalarının açılıp kapanmasını sağlar.
    const toggleItem = (itemId: string) => {
        setExpandedItems((prev) => ({ ...prev, [itemId]: !prev[itemId] }));
    };

    const isItemVisible = useCallback(
        (item: any) => {
            if (hiddenItems[item.id]) {
                return false;
            }

            return !item._zoomHidden;
        },
        [hiddenItems],
    );

    // Sidebar'da (yan menüde) öğenin görünür olarak çizilip çizilmeyeceğini belirler.
    // Eğer poligonun kenarlığı her zaman görünürse, sidebar'da kapalı (EyeOff/gri) GÖSTERME.
    const isSidebarVisible = useCallback(
        (item: any) => {
            if (hiddenItems[item.id]) {
                return false;
            }

            if (
                item.type === 'polygon' &&
                item.category?.border_always_visible
            ) {
                return true;
            }

            return !item._zoomHidden;
        },
        [hiddenItems],
    );

    const handleSetSelectedElement = useCallback(
        (element: any) => {
            setSelectedElement(element);

            if (!element) {
                setDetailsOpen(false);
            }
        },
        [setDetailsOpen],
    );

    const toggleSidebar = useCallback(() => {
        const nextState = !sidebarOpen;
        setSidebarOpen(nextState);

        if (nextState && window.innerWidth < 768) {
            setDetailsOpen(false);
        }
    }, [sidebarOpen, setSidebarOpen, setDetailsOpen]);

    const handleMapClick = useCallback(
        () => handleSetSelectedElement(null),
        [handleSetSelectedElement],
    );

    const handleMarkerClick = useCallback(
        (m: any) => {
            if (m._zoomHidden) {
                return;
            }

            handleSetSelectedElement(m);
        },
        [handleSetSelectedElement],
    );

    const handlePolygonClick = useCallback(
        (p: any) => {
            if (p._zoomHidden) {
                return;
            }

            handleSetSelectedElement(p);
        },
        [handleSetSelectedElement],
    );

    const visibleMarkers = useMemo(() => {
        return dbMarkers
            .filter((m) => {
                if (isolatedElementId) {
                    return m.id === isolatedElementId;
                }

                return isItemVisible(m);
            })
            .map((m) => ({ ...m, _zoomHidden: false }));
    }, [dbMarkers, isItemVisible, isolatedElementId]);

    const visiblePolygonsMemo = useMemo(() => {
        return mapPolygons
            .filter((p) => {
                if (isolatedElementId) {
                    return p.id === isolatedElementId;
                }

                if (hiddenItems[p.id]) {
                    return false;
                } // Eğer manuel gizlendiyse haritadan tamamen kaldır

                if (isItemVisible(p)) {
                    return true;
                }

                if (p.category?.border_always_visible) {
                    return true;
                }

                return false;
            })
            .map((p) => {
                if (isolatedElementId && p.id === isolatedElementId) {
                    return { ...p, _zoomHidden: false };
                }

                if (isItemVisible(p)) {
                    return { ...p, _zoomHidden: false };
                }

                return { ...p, _zoomHidden: true };
            });
    }, [mapPolygons, isItemVisible, hiddenItems, isolatedElementId]); // For the right sidebar with photos

    const searchResults = useMemo(() => {
        if (!searchQuery) {
            return [];
        }

        const q = searchQuery.toLowerCase();

        return [...dbMarkers, ...mapPolygons].filter(
            (item) => item.title && item.title.toLowerCase().includes(q),
        );
    }, [searchQuery, dbMarkers, mapPolygons]);

    // Helper to get full breadcrumb path of an item
    const getItemPath = (item: any) => {
        const itemType = item.type;
        const itemIdNum = parseInt(String(item.id).split('-')[1]);
        const sourceArray = itemType === 'marker' ? markers : polygons;
        const elementData = sourceArray?.find((d: any) => d.id === itemIdNum);

        const pathParts: string[] = [];
        let current = elementData;

        while (current && current.parent_id && current.parent_type) {
            const parentSource =
                current.parent_type === 'App\\Models\\Marker'
                    ? markers
                    : polygons;
            const parent = parentSource?.find(
                (d: any) => d.id === current.parent_id,
            );

            if (parent && parent.name) {
                pathParts.unshift(parent.name);
            }

            current = parent;
        }

        if (item.category?.name) {
            pathParts.push(item.category.name);
        }

        return pathParts.join(' > ');
    };

    // Helper to get all descendant items
    const getAllDescendants = (item: any) => {
        let descendants: any[] = [];

        if (item.children && item.children.length > 0) {
            item.children.forEach((child: any) => {
                descendants.push(child);
                descendants = descendants.concat(getAllDescendants(child));
            });
        }

        return descendants;
    };

    // Harita üzerinde öğenin görünürlüğünü açıp kapatır (Göz ikonu için)
    const toggleVisibility = (e: React.MouseEvent, item: any) => {
        e.stopPropagation(); // Tıklamanın menüyü genişletmesini engeller

        setHiddenItems((prev) => {
            const nextHiddenState = !prev[String(item.id)];
            const next: Record<string, boolean> = {
                ...prev,
                [String(item.id)]: nextHiddenState,
            };

            // Eğer ebeveyn kapatılıyorsa veya açılıyorsa, çocukları da aynı duruma getir
            const descendants = getAllDescendants(item);
            descendants.forEach((child) => {
                next[String(child.id)] = nextHiddenState;
            });

            return next;
        });
    };

    // Tüm kategoriyi toptan görünür/gizli yapar
    const toggleCategoryVisibility = (e: React.MouseEvent, category: any) => {
        e.stopPropagation();
        const allItemsInCat = category.items;
        const allVisible = allItemsInCat.every((item: any) =>
            isSidebarVisible(item),
        );

        setHiddenItems((prev) => {
            const next: Record<string, boolean> = { ...prev };
            allItemsInCat.forEach((item: any) => {
                next[String(item.id)] = allVisible; // Eğer hepsi görünürse -> true (gizle). Yoksa -> false (göster).

                // Çocukları da aynı şekilde etkile
                const descendants = getAllDescendants(item);
                descendants.forEach((child) => {
                    next[String(child.id)] = allVisible;
                });
            });

            return next;
        });
    };

    // Yan menüdeki "Büyüteç (Zoom)" ikonuna tıklandığında haritayı o öğeye odaklar.
    const handleZoomTo = useCallback((e: React.MouseEvent, item: any) => {
        e.stopPropagation(); // Öğeye tıklandığında listenin de genişlemesini engeller (sadece zoom yapar).

        if (item.type === 'marker') {
            // Marker ise direkt o enleme (lat) ve boylama (lng) uçar, yakınlaştırma seviyesini FOCUS_ZOOM yapar.
            mapRef.current?.flyTo(item.lat, item.lng, mapConfig.FOCUS_ZOOM);
        } else if (item.type === 'polygon') {
            // Poligon ise, poligonun çizim verisinden (geojson) köşe koordinatlarını bulup haritayı ona sığdırır.
            mapRef.current?.fitBounds(item.geojson);
        }
    }, []);

    // Recursive category and item renderer for Sidebar
    const renderCategory = (
        category: any,
        depth = 0,
        parentNodeKey = 'root',
    ) => {
        const categoryNodeKey = `${parentNodeKey}_cat_${category.id}`;

        return (
            <div
                key={`cat-${category.id}-${parentNodeKey}`}
                className={`mb-1 ${depth > 0 ? 'ml-4 border-l border-white/10 pl-2' : ''}`}
            >
                <div
                    className="flex cursor-pointer items-center justify-between rounded-md p-2 transition hover:bg-slate-800/50"
                    onClick={() => toggleCategory(categoryNodeKey)}
                >
                    <div className="flex items-center gap-2">
                        {expandedCategories[categoryNodeKey] ? (
                            <ChevronDown
                                size={16}
                                className="shrink-0 text-slate-500"
                            />
                        ) : (
                            <ChevronRight
                                size={16}
                                className="shrink-0 text-slate-500"
                            />
                        )}
                        <span className="flex items-center gap-2 text-sm font-semibold text-slate-200">
                            {(() => {
                                const Icon =
                                    AvailableIcons[
                                        category.icon as keyof typeof AvailableIcons
                                    ] || AvailableIcons.MapPin;

                                return (
                                    <Icon
                                        size={16}
                                        color={category.color || '#3b82f6'}
                                    />
                                );
                            })()}
                            {category.name}
                        </span>
                    </div>
                    <div className="flex items-center gap-2">
                        <span className="text-xs text-slate-500">
                            {category.items?.length || 0}
                        </span>
                        <button
                            onClick={(e) =>
                                toggleCategoryVisibility(e, category)
                            }
                            className="rounded p-1 text-slate-400 transition hover:bg-slate-700 hover:text-slate-200"
                        >
                            {category.items &&
                            category.items.length > 0 &&
                            category.items.every((item: any) =>
                                isSidebarVisible(item),
                            ) ? (
                                <Eye size={14} />
                            ) : (
                                <EyeOff size={14} />
                            )}
                        </button>
                    </div>
                </div>

                {expandedCategories[categoryNodeKey] && category.items && (
                    <div className="ml-6 mt-1 flex flex-col gap-1">
                        {category.items.length === 0 ? (
                            <p className="py-1 text-xs text-slate-500">
                                Bu kategoride öğe yok.
                            </p>
                        ) : (
                            category.items.map((item: any) => {
                                const isVisible = isSidebarVisible(item);

                                return (
                                    <div
                                        key={`${item.type}-${item.id}`}
                                        id={`sidebar-item-${item.type}-${item.id}`}
                                    >
                                        <div
                                            className={`flex flex-col rounded p-1.5 transition-colors ${selectedElement?.id === item.id ? 'border border-emerald-500/30 bg-emerald-900/40' : 'hover:bg-slate-800/50'} ${!isVisible ? 'opacity-50 grayscale' : ''}`}
                                        >
                                            <div className="flex items-center justify-between">
                                                <div
                                                    className={`flex flex-1 items-center gap-2 overflow-hidden ${isVisible ? 'cursor-pointer' : 'cursor-not-allowed'}`}
                                                    onClick={() => {
                                                        if (!isVisible) {
                                                            return;
                                                        }

                                                        handleSetSelectedElement(
                                                            item,
                                                        );
                                                        toggleItem(item.id);
                                                    }}
                                                >
                                                    {item.childCategories &&
                                                        item.childCategories
                                                            .length > 0 &&
                                                        (expandedItems[
                                                            item.id
                                                        ] ? (
                                                            <ChevronDown
                                                                size={16}
                                                                className="shrink-0 text-slate-500"
                                                            />
                                                        ) : (
                                                            <ChevronRight
                                                                size={16}
                                                                className="shrink-0 text-slate-500"
                                                            />
                                                        ))}
                                                    <span className="truncate text-xs text-slate-300">
                                                        {item.title}
                                                    </span>
                                                </div>
                                                <div className="flex items-center gap-1">
                                                    <button
                                                        onClick={(e) =>
                                                            handleZoomTo(
                                                                e,
                                                                item,
                                                            )
                                                        }
                                                        className="rounded p-1 text-slate-500 transition hover:bg-slate-700 hover:text-emerald-400"
                                                        title="Odaklan"
                                                    >
                                                        <Search size={14} />
                                                    </button>
                                                    <button
                                                        onClick={(e) =>
                                                            toggleVisibility(
                                                                e,
                                                                item,
                                                            )
                                                        }
                                                        className={`rounded p-1 transition hover:bg-slate-700 ${isVisible ? 'text-emerald-400' : 'text-slate-500 hover:text-slate-300'}`}
                                                    >
                                                        {isVisible ? (
                                                            <Eye size={14} />
                                                        ) : (
                                                            <EyeOff size={14} />
                                                        )}
                                                    </button>
                                                </div>
                                            </div>

                                            {/* Item Details */}
                                            {expandedItems[item.id] && (
                                                <div className="mt-2 text-xs text-slate-400">
                                                    {item.description && (
                                                        <p className="mb-1 line-clamp-3">
                                                            {item.description}
                                                        </p>
                                                    )}
                                                    {item.link && (
                                                        <a
                                                            href={item.link}
                                                            target="_blank"
                                                            rel="noopener noreferrer"
                                                            className="text-emerald-500 hover:underline"
                                                            onClick={(e) =>
                                                                e.stopPropagation()
                                                            }
                                                        >
                                                            Detaylı Bilgi &rarr;
                                                        </a>
                                                    )}
                                                </div>
                                            )}
                                        </div>

                                        {/* Recursive rendering of child categories if present */}
                                        {item.childCategories &&
                                            item.childCategories.length > 0 &&
                                            expandedItems[item.id] && (
                                                <div className="ml-2 mt-1">
                                                    {item.childCategories.map(
                                                        (childCat: any) =>
                                                            renderCategory(
                                                                childCat,
                                                                depth + 1,
                                                                item.id,
                                                            ),
                                                    )}
                                                </div>
                                            )}
                                    </div>
                                );
                            })
                        )}
                    </div>
                )}
            </div>
        );
    };

    return (
        <>
            <Head title="AHBVÜ Kampüs Haritası" />
            <style
                dangerouslySetInnerHTML={{
                    __html: `
                .map-demo-container .leaflet-top.leaflet-left { margin-top: 15px; }
            `,
                }}
            />
            <div
                className="map-demo-container flex h-[100dvh] flex-col overflow-hidden bg-slate-950 text-white"
                style={
                    {
                        '--sidebar-width': sidebarOpen
                            ? `${sidebarWidth}px`
                            : '0px',
                        '--resize-transition': isResizing
                            ? '0s'
                            : '0.3s ease-in-out',
                    } as React.CSSProperties
                }
            >
                <header className="z-[2000] flex shrink-0 items-center justify-between border-b border-white/10 bg-slate-900/90 px-4 py-3 backdrop-blur">
                    <div className="flex items-center gap-4">
                        <button
                            onClick={toggleSidebar}
                            className="rounded bg-slate-800 p-1 text-slate-300 transition hover:bg-slate-700"
                        >
                            {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
                        </button>
                        <div className="flex items-center gap-3">
                            <img
                                src="/AHBVU_Logo.png"
                                alt="AHBVU Logo"
                                className="h-9 w-auto rounded bg-white/10 p-1"
                            />
                            <div>
                                <p className="text-xs font-medium uppercase tracking-[0.2em] text-emerald-400">
                                    Harita
                                </p>
                                <h1 className="hidden text-lg font-semibold sm:block">
                                    Ankara Hacı Bayram Veli Üniversitesi
                                </h1>
                            </div>
                        </div>
                    </div>

                    <div className="flex items-center gap-3">
                        <Link
                            href="/"
                            className="rounded-md border border-white/15 px-3 py-1.5 text-sm text-slate-200 transition hover:border-white/30 hover:bg-white/5"
                        >
                            Ana Sayfa
                        </Link>
                        <Link
                            href="/login"
                            className="rounded-md bg-emerald-600 px-3 py-1.5 text-sm font-semibold text-white shadow-sm transition hover:bg-emerald-500"
                        >
                            Giriş Yap
                        </Link>
                    </div>
                </header>

                <div
                    className={`relative flex flex-1 overflow-hidden ${sidebarOpen ? 'layer-sidebar-open' : ''}`}
                >
                    {/* Collapsible Sidebar */}
                    <div
                        className={`absolute left-0 top-0 z-[1500] flex h-full flex-col overflow-hidden border-r border-white/10 bg-slate-900/95 shadow-2xl backdrop-blur transition-transform duration-300 md:max-w-[70vw] ${sidebarOpen ? 'w-[70vw] translate-x-0' : 'w-[70vw] -translate-x-full'} `}
                        style={{
                            width:
                                typeof window !== 'undefined' &&
                                window.innerWidth >= 768
                                    ? sidebarWidth
                                    : undefined,
                        }}
                    >
                        <div
                            className="absolute bottom-0 right-0 top-0 z-50 hidden w-1.5 cursor-col-resize transition-colors hover:bg-emerald-500/50 active:bg-emerald-500 md:block"
                            onMouseDown={(e) => {
                                e.preventDefault();
                                setIsResizing(true);
                                const startX = e.clientX;
                                const startWidth = sidebarWidth;
                                const onMouseMove = (moveEvent: MouseEvent) => {
                                    const newWidth = Math.min(
                                        Math.max(
                                            250,
                                            startWidth +
                                                (moveEvent.clientX - startX),
                                        ),
                                        window.innerWidth * 0.7,
                                    );
                                    setSidebarWidth(newWidth);
                                };
                                const onMouseUp = () => {
                                    setIsResizing(false);
                                    document.removeEventListener(
                                        'mousemove',
                                        onMouseMove,
                                    );
                                    document.removeEventListener(
                                        'mouseup',
                                        onMouseUp,
                                    );
                                };
                                document.addEventListener(
                                    'mousemove',
                                    onMouseMove,
                                );
                                document.addEventListener('mouseup', onMouseUp);
                            }}
                        />
                        <div className="border-b border-white/10 bg-slate-800/50 p-4">
                            <h2 className="font-semibold text-emerald-400">
                                Keşfet
                            </h2>
                            <p className="mt-1 text-xs text-slate-400">
                                Yerleşkeleri, binaları ve tesisleri inceleyin.
                            </p>
                            <div className="mt-3 flex items-center gap-2 rounded-md border border-white/10 bg-slate-900/80 px-2 py-1.5 transition-colors focus-within:border-emerald-500/50 focus-within:bg-slate-900">
                                <Search
                                    size={16}
                                    className="shrink-0 text-slate-500"
                                />
                                <input
                                    type="text"
                                    placeholder="Haritada ara..."
                                    className="w-full min-w-0 border-none bg-transparent p-0 text-sm text-slate-200 placeholder:text-slate-500 focus:outline-none focus:ring-0"
                                    value={searchQuery}
                                    onChange={(e) =>
                                        setSearchQuery(e.target.value)
                                    }
                                />
                                {(searchQuery || isolatedElementId) && (
                                    <button
                                        onClick={() => {
                                            setSearchQuery('');
                                            setIsolatedElementId(null);
                                        }}
                                        className="shrink-0 rounded p-1 transition-colors hover:bg-slate-800"
                                        title="Aramayı temizle ve tüm öğeleri göster"
                                    >
                                        <X
                                            size={14}
                                            className="text-slate-400 hover:text-white"
                                        />
                                    </button>
                                )}
                            </div>
                        </div>

                        <div className="flex-1 overflow-y-auto p-2">
                            {searchQuery ? (
                                <div className="p-2">
                                    {searchResults.length === 0 ? (
                                        <p className="py-4 text-center text-sm text-slate-500">
                                            Sonuç bulunamadı.
                                        </p>
                                    ) : (
                                        searchResults.map((item) => (
                                            <div
                                                key={`search-${item.id}`}
                                                className={`mb-1 flex cursor-pointer items-center justify-between rounded-md p-2 transition hover:bg-slate-800/50 ${isolatedElementId === item.id ? 'border border-emerald-500/30 bg-slate-800/80' : 'border border-transparent'}`}
                                                onClick={(e) => {
                                                    setIsolatedElementId(
                                                        item.id,
                                                    );
                                                    // eslint-disable-next-line react-hooks/refs
                                                    handleZoomTo(e, item);

                                                    if (
                                                        window.innerWidth < 768
                                                    ) {
                                                        setSidebarOpen(false);
                                                    }
                                                }}
                                            >
                                                <div className="flex items-center gap-2 truncate">
                                                    {(() => {
                                                        const Icon =
                                                            AvailableIcons[
                                                                item.category
                                                                    ?.icon as keyof typeof AvailableIcons
                                                            ] ||
                                                            AvailableIcons.MapPin;

                                                        return (
                                                            <Icon
                                                                size={16}
                                                                color={
                                                                    item
                                                                        .category
                                                                        ?.color ||
                                                                    '#3b82f6'
                                                                }
                                                                className="shrink-0"
                                                            />
                                                        );
                                                    })()}
                                                    <div className="flex flex-col truncate">
                                                        <span className="truncate text-sm font-semibold text-slate-200">
                                                            {item.title}
                                                        </span>
                                                        {getItemPath(item) && (
                                                            <span className="truncate text-[10px] text-slate-500">
                                                                {getItemPath(
                                                                    item,
                                                                )}
                                                            </span>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        ))
                                    )}
                                </div>
                            ) : (
                                <>
                                    {categoriesMap.length === 0 && (
                                        <div className="p-4 text-center text-sm text-slate-500">
                                            Henüz haritaya eklenmiş bir veri
                                            bulunmuyor.
                                        </div>
                                    )}
                                    {categoriesMap.map((category) =>
                                        renderCategory(category),
                                    )}
                                </>
                            )}
                        </div>
                    </div>

                    {/* Right Sidebar for Details */}
                    <div
                        className={`absolute right-0 top-0 z-[1500] flex h-full flex-col border-l border-white/10 bg-slate-900/95 shadow-2xl backdrop-blur transition-all duration-300 ${detailsOpen ? 'w-[70vw] translate-x-0 md:w-80' : 'w-[70vw] translate-x-full md:w-80'}`}
                    >
                        <div className="flex items-center justify-between border-b border-white/10 bg-slate-800/50 p-4">
                            <div>
                                <h2 className="font-semibold text-emerald-400">
                                    Detaylar
                                </h2>
                                <p className="mt-1 line-clamp-1 text-xs text-slate-400">
                                    {selectedElement?.title ||
                                        'Seçim yapılmadı'}
                                </p>
                            </div>
                            <button
                                onClick={() => setDetailsOpen(false)}
                                className="rounded p-1 text-slate-400 transition hover:bg-white/10 hover:text-white"
                            >
                                <X size={20} />
                            </button>
                        </div>
                        <div className="flex-1 space-y-6 overflow-y-auto p-4 text-sm text-slate-300">
                            {/* Description */}
                            {selectedElement?.description && (
                                <div>
                                    <h3 className="mb-2 font-semibold text-slate-400">
                                        Açıklama
                                    </h3>
                                    <div className="whitespace-pre-wrap text-sm leading-relaxed text-slate-300">
                                        <ReactMarkdown
                                            remarkPlugins={[
                                                remarkGfm,
                                                remarkBreaks,
                                            ]}
                                            components={{
                                                a: ({
                                                    // eslint-disable-next-line @typescript-eslint/no-unused-vars
                                                    node,
                                                    ...props
                                                }) => (
                                                    <a
                                                        {...props}
                                                        className="text-blue-400 underline hover:text-blue-300"
                                                        target="_blank"
                                                        rel="noopener noreferrer"
                                                    />
                                                ),
                                                p: ({
                                                    // eslint-disable-next-line @typescript-eslint/no-unused-vars
                                                    node,
                                                    ...props
                                                }) => (
                                                    <p
                                                        {...props}
                                                        className="mb-2"
                                                    />
                                                ),
                                                strong: ({
                                                    // eslint-disable-next-line @typescript-eslint/no-unused-vars
                                                    node,
                                                    ...props
                                                }) => (
                                                    <strong
                                                        {...props}
                                                        className="font-bold text-white"
                                                    />
                                                ),
                                            }}
                                        >
                                            {selectedElement.description}
                                        </ReactMarkdown>
                                    </div>
                                </div>
                            )}

                            {/* Link / Links */}
                            {(selectedElement?.link ||
                                (selectedElement?.links &&
                                    selectedElement.links.length > 0)) && (
                                <div>
                                    <h3 className="mb-2 font-semibold text-slate-400">
                                        Bağlantılar
                                    </h3>
                                    <div className="flex flex-col gap-2">
                                        {selectedElement.link && (
                                            <a
                                                href={selectedElement.link}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="break-all text-emerald-400 hover:underline"
                                            >
                                                {selectedElement.link}
                                            </a>
                                        )}
                                        {selectedElement.links?.map(
                                            (linkItem: any, idx: number) => (
                                                <a
                                                    key={idx}
                                                    href={linkItem.url}
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                    className="break-all text-emerald-400 hover:underline"
                                                >
                                                    {linkItem.title ||
                                                        linkItem.url}
                                                </a>
                                            ),
                                        )}
                                    </div>
                                </div>
                            )}

                            {/* Photos */}
                            {selectedElement?.images &&
                                selectedElement.images.length > 0 && (
                                    <div>
                                        <h3 className="mb-2 font-semibold text-slate-400">
                                            Fotoğraflar
                                        </h3>
                                        <div className="space-y-4">
                                            {selectedElement.images.map(
                                                (img: string, idx: number) => (
                                                    <div
                                                        key={idx}
                                                        className="overflow-hidden rounded-lg border border-white/10"
                                                    >
                                                        <img
                                                            src={`/storage/${img}`}
                                                            alt={`${selectedElement?.title} - ${idx + 1}`}
                                                            className="h-auto w-full object-cover"
                                                        />
                                                    </div>
                                                ),
                                            )}
                                        </div>
                                    </div>
                                )}

                            {/* Placeholder for no info */}
                            {!selectedElement?.description &&
                                !selectedElement?.link &&
                                (!selectedElement?.links ||
                                    selectedElement.links.length === 0) &&
                                (!selectedElement?.images ||
                                    selectedElement.images.length === 0) && (
                                    <div className="py-8 text-center text-slate-500">
                                        Bu öğe için ek detay bulunmuyor.
                                    </div>
                                )}
                        </div>
                    </div>

                    <div className="relative z-0 h-full w-full flex-1">
                        <Map
                            ref={mapRef}
                            center={mapConfig.DEFAULT_CENTER}
                            zoom={mapConfig.DEMO_DEFAULT_ZOOM}
                            onZoomChange={handleZoomChange}
                            onMapClick={handleMapClick}
                            onMarkerClick={handleMarkerClick}
                            onPolygonClick={handlePolygonClick}
                            markers={visibleMarkers}
                            polygons={visiblePolygonsMemo}
                        />

                        {selectedElement && (
                            <div className="absolute right-4 top-4 z-[1000]">
                                <button
                                    onClick={() => {
                                        const nextDetails = !detailsOpen;
                                        setDetailsOpen(nextDetails);

                                        if (
                                            nextDetails &&
                                            window.innerWidth < 768
                                        ) {
                                            setSidebarOpen(false);
                                        }
                                    }}
                                    className="flex items-center gap-2 rounded bg-emerald-600 px-3 py-2 text-sm font-semibold text-white shadow-lg transition hover:bg-emerald-500"
                                >
                                    <Info size={18} />
                                    <span className="hidden sm:inline">
                                        {detailsOpen
                                            ? 'Detayları Gizle'
                                            : 'Detayları Gör'}
                                    </span>
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </>
    );
}
