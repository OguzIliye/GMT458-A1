<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('markers', function (Blueprint $table) {
            $table->boolean('hide_symbology')->default(false);
        });

        Schema::table('polygons', function (Blueprint $table) {
            $table->boolean('hide_symbology')->default(false);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('markers', function (Blueprint $table) {
            $table->dropColumn('hide_symbology');
        });

        Schema::table('polygons', function (Blueprint $table) {
            $table->dropColumn('hide_symbology');
        });
    }
};
