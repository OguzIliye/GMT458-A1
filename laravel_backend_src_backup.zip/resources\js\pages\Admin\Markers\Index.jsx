import React, { useState, useEffect, useRef, useMemo } from 'react';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, useForm, router } from '@inertiajs/react';
import Map from '@/components/map';
import { AvailableIcons } from '@/components/icons';
import GeoJsonImportModal from '@/components/GeoJsonImportModal';
import ContextMenu from './components/ContextMenu';
import { mapConfig } from '@/config/mapConfig';
import {
    Eye,
    EyeOff,
    Search,
    Layers,
    X,
    GripVertical,
    ChevronRight,
    ChevronDown,
    MousePointer2,
    MapPin,
    Hexagon,
    Trash2,
    Route,
    PenTool,
    Settings,
} from 'lucide-react';

const formatScale = (zoom) => {
    if (
        zoom === null ||
        zoom === undefined ||
        zoom === '' ||
        zoom <= 0 ||
        zoom >= 25
    )
        return 'Yok';
    const scale = 450000000 / Math.pow(2, zoom);
    if (scale < 1) return `2:${Math.round(1 / scale)}`;
    if (scale < 10) return `1:${scale.toFixed(1)}`;
    return `1:${Math.round(scale).toLocaleString('tr-TR')}`;
};

const DualRangeSlider = ({
    minVal,
    maxVal,
    setMinVal,
    setMaxVal,
    maxZoomLimit = 25,
}) => {
    // left thumb (0 = max zoom, most zoomed in). right thumb (maxZoomLimit = zoom 0, most zoomed out)
    const leftIndex = maxVal ? maxZoomLimit - parseInt(maxVal) : 0;
    const rightIndex = minVal ? maxZoomLimit - parseInt(minVal) : maxZoomLimit;

    const handleMinChange = (e) => {
        let val = parseInt(e.target.value);
        if (val > rightIndex) {
            setMaxVal(maxZoomLimit - rightIndex);
            setMinVal(maxZoomLimit - val);
        } else {
            setMaxVal(maxZoomLimit - val);
        }
    };

    const handleMaxChange = (e) => {
        let val = parseInt(e.target.value);
        if (val < leftIndex) {
            setMinVal(maxZoomLimit - leftIndex);
            setMaxVal(maxZoomLimit - val);
        } else {
            setMinVal(maxZoomLimit - val);
        }
    };

    const getPercent = (value) => Math.round((value / maxZoomLimit) * 100);

    return (
        <div className="relative mb-4 mt-4 flex h-8 w-full items-center">
            <style>{`
                .dual-slider-input {
                    -webkit-appearance: none;
                    appearance: none;
                    width: 100%;
                    background: transparent;
                    pointer-events: none;
                    position: absolute;
                    z-index: 20;
                    height: 4px;
                    outline: none;
                }
                .dual-slider-input::-webkit-slider-thumb {
                    -webkit-appearance: none;
                    appearance: none;
                    pointer-events: auto;
                    width: 16px;
                    height: 16px;
                    border-radius: 50%;
                    background: white;
                    border: 2px solid #6366f1; /* indigo-500 */
                    cursor: pointer;
                    box-shadow: 0 1px 3px rgba(0,0,0,0.3);
                }
                .dual-slider-input::-moz-range-thumb {
                    pointer-events: auto;
                    width: 16px;
                    height: 16px;
                    border-radius: 50%;
                    background: white;
                    border: 2px solid #6366f1;
                    cursor: pointer;
                    box-shadow: 0 1px 3px rgba(0,0,0,0.3);
                }
            `}</style>
            {/* Track */}
            <div className="absolute z-0 h-1.5 w-full rounded-full bg-gray-200"></div>
            {/* Range highlight */}
            <div
                className="absolute z-[1] h-1.5 rounded-full bg-indigo-500"
                style={{
                    left: `${getPercent(leftIndex)}%`,
                    width: `${getPercent(rightIndex) - getPercent(leftIndex)}%`,
                }}
            ></div>
            {/* Inputs */}
            <input
                type="range"
                min="0"
                max={maxZoomLimit}
                value={leftIndex}
                onChange={handleMinChange}
                className="dual-slider-input absolute w-full"
                style={{ zIndex: leftIndex > rightIndex - 1 ? '5' : '3' }}
            />
            <input
                type="range"
                min="0"
                max={maxZoomLimit}
                value={rightIndex}
                onChange={handleMaxChange}
                className="dual-slider-input absolute w-full"
                style={{ zIndex: '4' }}
            />
        </div>
    );
};

const ImageUploader = ({
    existingImages,
    newImages,
    onExistingRemove,
    onNewAdd,
    onNewRemove,
}) => {
    const handleFileChange = (e) => {
        if (e.target.files) {
            onNewAdd(Array.from(e.target.files));
        }
        e.target.value = null; // reset
    };

    return (
        <div className="mt-4 border-t pt-4">
            <label className="mb-2 block text-sm font-medium text-gray-700">
                Fotoğraflar
            </label>
            <div className="flex flex-col gap-3">
                {existingImages.length > 0 && (
                    <div>
                        <div className="mb-1 text-xs font-medium text-gray-500">
                            Mevcut Fotoğraflar
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                            {existingImages.map((img, i) => (
                                <div
                                    key={i}
                                    className="group relative overflow-hidden rounded border"
                                >
                                    <img
                                        src={`/storage/${img}`}
                                        alt="existing"
                                        className="h-16 w-full object-cover"
                                    />
                                    <button
                                        type="button"
                                        onClick={() => onExistingRemove(i)}
                                        className="absolute right-0 top-0 rounded-bl bg-red-500 px-1 text-xs text-white opacity-0 transition-opacity group-hover:opacity-100"
                                    >
                                        ✕
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {newImages.length > 0 && (
                    <div>
                        <div className="mb-1 text-xs font-medium text-gray-500">
                            Eklenecek Yeni Fotoğraflar
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                            {newImages.map((file, i) => (
                                <div
                                    key={i}
                                    className="group relative overflow-hidden rounded border"
                                >
                                    <img
                                        src={URL.createObjectURL(file)}
                                        alt="new"
                                        className="h-16 w-full object-cover"
                                    />
                                    <button
                                        type="button"
                                        onClick={() => onNewRemove(i)}
                                        className="absolute right-0 top-0 rounded-bl bg-red-500 px-1 text-xs text-white opacity-0 transition-opacity group-hover:opacity-100"
                                    >
                                        ✕
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                <div>
                    <label className="inline-flex cursor-pointer items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium leading-4 text-gray-700 shadow-sm hover:bg-gray-50">
                        <span>+ Fotoğraf Ekle</span>
                        <input
                            type="file"
                            multiple
                            accept="image/*"
                            className="hidden"
                            onChange={handleFileChange}
                        />
                    </label>
                    <p className="mt-1 text-xs text-gray-400">
                        Sürükle bırak özelliği için dosya seçiciyi
                        kullanabilirsiniz.
                    </p>
                </div>
            </div>
        </div>
    );
};

const ParentSelector = ({
    value,
    onChange,
    polygons,
    markers,
    categories,
    editingId,
    editingType,
}) => {
    const [isOpen, setIsOpen] = useState(false);
    const [expandedCategories, setExpandedCategories] = useState({});

    // Kategoriye ve parent'a göre hiyerarşik gruplama
    const groupedData = useMemo(() => {
        const groups = {};

        categories.forEach((cat) => {
            groups[cat.id] = { ...cat, items: [] };
        });

        groups[0] = { id: 0, name: 'Kategorisiz', items: [] };

        const itemMap = {};
        const editingModelType =
            editingType === 'polygon'
                ? 'App\\Models\\Polygon'
                : 'App\\Models\\Marker';
        const editingKey = `${editingModelType}|${editingId}`;

        const isDescendant = (parentType, parentId) => {
            let currentType = parentType;
            let currentId = parentId;
            const seen = new Set();

            while (currentType && currentId) {
                const key = `${currentType}|${currentId}`;
                if (key === editingKey) return true;
                if (seen.has(key)) return false; // Döngü koruması
                seen.add(key);

                let parentItem;
                if (currentType === 'App\\Models\\Polygon') {
                    parentItem = polygons.find(
                        (p) => p.id === parseInt(currentId),
                    );
                } else {
                    parentItem = markers.find(
                        (m) => m.id === parseInt(currentId),
                    );
                }

                if (!parentItem) break;
                currentType = parentItem.parent_type;
                currentId = parentItem.parent_id;
            }
            return false;
        };

        const processItem = (item, type, typeLabel) => {
            const isSelf =
                type === editingModelType && item.id === parseInt(editingId);
            if (isSelf) return null;

            if (isDescendant(item.parent_type, item.parent_id)) return null;

            return {
                ...item,
                type,
                typeLabel,
                children: [],
            };
        };

        polygons.forEach((p) => {
            const processed = processItem(p, 'App\\Models\\Polygon', 'Poligon');
            if (processed) {
                itemMap[`App\\Models\\Polygon|${p.id}`] = processed;
            }
        });

        markers.forEach((m) => {
            const processed = processItem(m, 'App\\Models\\Marker', 'Marker');
            if (processed) {
                itemMap[`App\\Models\\Marker|${m.id}`] = processed;
            }
        });

        Object.values(itemMap).forEach((item) => {
            if (item.parent_type && item.parent_id) {
                const parentKey = `${item.parent_type}|${item.parent_id}`;
                if (itemMap[parentKey]) {
                    itemMap[parentKey].children.push(item);
                    return;
                }
            }

            const catId = item.category_id || 0;
            if (groups[catId]) {
                groups[catId].items.push(item);
            }
        });

        return Object.values(groups)
            .filter((g) => g.items.length > 0)
            .sort((a, b) => a.name.localeCompare(b.name));
    }, [polygons, markers, categories, editingId, editingType]);

    const toggleCat = (e, id) => {
        e.stopPropagation();
        setExpandedCategories((prev) => ({ ...prev, [id]: !prev[id] }));
    };

    const handleSelect = (val) => {
        onChange(val);
        setIsOpen(false);
    };

    const [expandedItems, setExpandedItems] = useState({});

    const toggleItem = (e, val) => {
        e.stopPropagation();
        setExpandedItems((prev) => ({ ...prev, [val]: !prev[val] }));
    };

    const renderTreeNodes = (items, level = 0) => {
        return items.map((item) => {
            const val = `${item.type}|${item.id}`;
            const isSelected = value === val;
            const hasChildren = item.children && item.children.length > 0;
            const isExpanded = expandedItems[val];

            return (
                <React.Fragment key={val}>
                    <div
                        className={`flex cursor-pointer items-center justify-between py-2 pr-3 text-sm ${isSelected ? 'bg-indigo-50 font-semibold text-indigo-700' : 'group text-gray-900 hover:bg-indigo-600 hover:text-white'}`}
                        style={{ paddingLeft: `${1.5 + level * 1.5}rem` }}
                        onClick={() => handleSelect(val)}
                    >
                        <span className="flex items-center">
                            {level > 0 && (
                                <span className="mr-2 text-gray-300 opacity-50">
                                    └
                                </span>
                            )}
                            {hasChildren && (
                                <span
                                    className="-ml-1 mr-1 p-1 text-gray-400 hover:text-gray-600 group-hover:text-white"
                                    onClick={(e) => toggleItem(e, val)}
                                >
                                    {isExpanded ? (
                                        <ChevronDown size={14} />
                                    ) : (
                                        <ChevronRight size={14} />
                                    )}
                                </span>
                            )}
                            <span className={hasChildren ? '' : 'ml-4'}>
                                {item.name}
                            </span>
                        </span>
                        <span
                            className={`text-xs ${isSelected ? 'text-indigo-500' : 'text-gray-400 group-hover:text-indigo-200'} opacity-75`}
                        >
                            {item.typeLabel}
                        </span>
                    </div>
                    {hasChildren && isExpanded && (
                        <div>{renderTreeNodes(item.children, level + 1)}</div>
                    )}
                </React.Fragment>
            );
        });
    };

    const displayValue = useMemo(() => {
        if (!value || value === '|') return 'Yok (Kök Element)';
        const [type, id] = value.split('|');
        if (type === 'App\\Models\\Polygon') {
            const p = polygons.find((x) => x.id === parseInt(id));
            return p ? `Poligon: ${p.name}` : 'Bilinmeyen Poligon';
        } else {
            const m = markers.find((x) => x.id === parseInt(id));
            return m ? `Marker: ${m.name}` : 'Bilinmeyen Marker';
        }
    }, [value, polygons, markers]);

    return (
        <div className="relative">
            <button
                type="button"
                className="mt-1 flex w-full items-center justify-between rounded-md border border-gray-300 bg-white px-3 py-2 text-sm shadow-sm focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                onClick={() => setIsOpen(!isOpen)}
            >
                <span className="truncate">{displayValue}</span>
                <ChevronDown size={16} className="text-gray-400" />
            </button>

            {isOpen && (
                <>
                    <div
                        className="fixed inset-0 z-40"
                        onClick={() => setIsOpen(false)}
                    ></div>
                    <div className="absolute z-50 mt-1 max-h-80 w-full overflow-auto rounded-md bg-white py-1 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm">
                        <div
                            className="cursor-pointer border-b border-gray-100 px-3 py-2 text-gray-900 hover:bg-indigo-600 hover:text-white"
                            onClick={() => handleSelect('|')}
                        >
                            Yok (Kök Element)
                        </div>
                        {groupedData.map((group) => (
                            <div
                                key={group.id}
                                className="border-b border-gray-50"
                            >
                                <div
                                    className="flex cursor-pointer items-center justify-between bg-gray-50 px-3 py-2 font-medium text-gray-700 hover:bg-gray-100"
                                    onClick={(e) => toggleCat(e, group.id)}
                                >
                                    <span>{group.name}</span>
                                    {expandedCategories[group.id] ? (
                                        <ChevronDown
                                            size={16}
                                            className="shrink-0"
                                        />
                                    ) : (
                                        <ChevronRight
                                            size={16}
                                            className="shrink-0"
                                        />
                                    )}
                                </div>
                                {expandedCategories[group.id] && (
                                    <div>{renderTreeNodes(group.items, 0)}</div>
                                )}
                            </div>
                        ))}
                    </div>
                </>
            )}
        </div>
    );
};

const Index = ({
    auth,
    flash = {},
    markers = [],
    polygons = [],
    categories = [],
}) => {
    const mapRef = useRef(null);
    // Yan menü ve sekme durumlarını yöneten stateler
    const [isSidebarOpen, _setIsSidebarOpen] = useState(false);
    const [isLayerSidebarOpen, _setIsLayerSidebarOpen] = useState(true);
    const [sidebarWidth, setSidebarWidth] = useState(320);
    const [isResizing, setIsResizing] = useState(false);

    const setIsSidebarOpen = (val) => {
        _setIsSidebarOpen(val);
        if (val && window.innerWidth < 768) {
            _setIsLayerSidebarOpen(false);
        }
    };

    const setIsLayerSidebarOpen = (val) => {
        _setIsLayerSidebarOpen(val);
        if (val && window.innerWidth < 768) {
            _setIsSidebarOpen(false);
        }
    };

    const [contextMenu, setContextMenu] = useState(null); // { x, y, items }
    const [hiddenItems, setHiddenItems] = useState({});
    const [expandedCategories, setExpandedCategories] = useState({});
    const [draggedCategory, setDraggedCategory] = useState(null);
    const [isSavingOrder, setIsSavingOrder] = useState(false);
    const [activeTab, setActiveTab] = useState('add'); // 'add' | 'add-polygon'
    const [mapZoom, setMapZoom] = useState(12);
    const [zoomSettingsOpen, setZoomSettingsOpen] = useState(null); // Category ID
    const [tempMinZoom, setTempMinZoom] = useState('');
    const [tempMaxZoom, setTempMaxZoom] = useState('');
    const [tempBorderAlwaysVisible, setTempBorderAlwaysVisible] =
        useState(false);

    // Haritanın o anki etkileşim modunu belirler (kaydırma, marker ekleme, silme vs.)
    const [mapMode, setMapMode] = useState('pan'); // 'pan' | 'add' | 'delete' | 'add-polygon' | 'delete-polygon'

    // GeoJSON Sihirbazı state
    const [isGeoJsonModalOpen, setIsGeoJsonModalOpen] = useState(false);

    // Kategori ekleme formu için stateler
    const [showCategoryForm, setShowCategoryForm] = useState(false);
    const [newCategoryName, setNewCategoryName] = useState('');
    const [newCategoryIcon, setNewCategoryIcon] = useState('MapPin');
    const [newCategoryColor, setNewCategoryColor] = useState('#3b82f6');
    const [newCategoryMinZoom, setNewCategoryMinZoom] = useState('');
    const [newCategoryMaxZoom, setNewCategoryMaxZoom] = useState('');
    const [newCategoryBorderAlwaysVisible, setNewCategoryBorderAlwaysVisible] =
        useState(false);
    const [isSubmittingCategory, setIsSubmittingCategory] = useState(false);

    // Eğer bir öğe düzenleniyorsa onun ID'sini tutar (null ise yeni ekleniyor demektir)
    const [editingMarkerId, setEditingMarkerId] = useState(null);
    const [editingPolygonId, setEditingPolygonId] = useState(null);

    // Global Undo/Redo state for deleted elements
    const [deletedStack, setDeletedStack] = useState([]);
    const [redoDeletedStack, setRedoDeletedStack] = useState([]);

    useEffect(() => {
        const handleUndo = () => {
            if (
                mapMode === 'add-polygon' ||
                mapMode === 'add-linestring' ||
                mapMode === 'edit-polygon' ||
                mapMode === 'edit-marker' ||
                mapMode === 'edit-linestring'
            ) {
                return;
            }
            if (deletedStack.length > 0) {
                const last = deletedStack[deletedStack.length - 1];
                setDeletedStack((prev) => prev.slice(0, -1));
                setRedoDeletedStack((prev) => [...prev, last]);
                const routeName =
                    last.type === 'marker'
                        ? 'markers.restore'
                        : 'polygons.restore';
                router.post(
                    route(routeName, last.id),
                    {},
                    { preserveScroll: true, preserveState: true },
                );
            }
        };

        const handleRedo = () => {
            if (
                mapMode === 'add-polygon' ||
                mapMode === 'add-linestring' ||
                mapMode === 'edit-polygon' ||
                mapMode === 'edit-marker' ||
                mapMode === 'edit-linestring'
            ) {
                return;
            }
            if (redoDeletedStack.length > 0) {
                const last = redoDeletedStack[redoDeletedStack.length - 1];
                setRedoDeletedStack((prev) => prev.slice(0, -1));
                setDeletedStack((prev) => [...prev, last]);
                const routeName =
                    last.type === 'marker'
                        ? 'markers.destroy'
                        : 'polygons.destroy';
                router.delete(route(routeName, last.id), {
                    preserveScroll: true,
                    preserveState: true,
                });
            }
        };

        window.addEventListener('undo-polygon-point', handleUndo);
        window.addEventListener('redo-polygon-point', handleRedo);

        return () => {
            window.removeEventListener('undo-polygon-point', handleUndo);
            window.removeEventListener('redo-polygon-point', handleRedo);
        };
    }, [mapMode, deletedStack, redoDeletedStack]);

    // Marker (İşaretçi) ekleme/düzenleme formu (Inertia.js useForm hook'u kullanılarak veriler Laravel'e gönderilir)
    const {
        data: markerData,
        setData: setMarkerData,
        setDefaults: setMarkerDefaults,
        post: postMarker,
        put: putMarker,
        processing: processingMarker,
        errors: errorsMarker,
        reset: resetMarker,
        isDirty: isMarkerDirty,
        transform: transformMarker,
    } = useForm({
        name: '',
        description: '',
        category_id: '',
        link: '',
        links: [],
        existing_images: [],
        new_images: [],
        new_images: [],
        existing_images: [],
        latitude: '',
        longitude: '',
        parent_id: '',
        parent_type: '',
        hide_symbology: false,
    });

    // Poligon ekleme/dzenleme formu
    const {
        data: polygonData,
        setData: setPolygonData,
        setDefaults: setPolygonDefaults,
        post: postPolygon,
        put: putPolygon,
        processing: processingPolygon,
        errors: errorsPolygon,
        reset: resetPolygon,
        isDirty: isPolygonDirty,
        transform: transformPolygon,
    } = useForm({
        name: '',
        description: '',
        category_id: '',
        link: '',
        links: [],
        existing_images: [],
        new_images: [],
        type: 'Polygon', // 'Polygon' veya 'LineString'
        coordinates: [],
        parent_id: '',
        parent_type: '',
        hide_symbology: false,
    });

    // Haritaya tıklandığında (ve mod 'add' ise) tıklanan koordinatları form state'ine aktar
    const handleMapClick = (lat, lng) => {
        if (mapMode === 'add' || mapMode === 'edit-marker') {
            setMarkerData((prev) => ({
                ...prev,
                latitude: lat,
                longitude: lng,
            }));
            setActiveTab('add');
            setIsSidebarOpen(true);
        }
    };

    // Silme modundayken bir markera tıklandığında silme işlemini başlat, değilse düzenle
    const handleMarkerClick = (marker) => {
        if (marker._zoomHidden) return;
        if (mapMode === 'delete') {
            if (
                confirm(
                    `'${marker.title}' işaretçisini silmek istediğinize emin misiniz?`,
                )
            ) {
                router.delete(route('markers.destroy', marker.id), {
                    preserveScroll: true,
                    preserveState: true,
                    onSuccess: () => {
                        setDeletedStack((prev) => [
                            ...prev,
                            { type: 'marker', id: marker.id },
                        ]);
                        setRedoDeletedStack([]);
                    },
                });
            }
        } else {
            // Bulunan marker'ın orijinal verisini bul (harita componentinden sadece title/lat/lng geliyor olabilir)
            const originalMarker =
                markers.find((m) => m.id.toString() === marker.id.toString()) ||
                marker;
            editMarker(originalMarker, true);
        }
    };

    // Silme modundayken bir poligona tıklandığında silme işlemini başlat, değilse düzenle
    const handlePolygonClick = (polygon) => {
        if (polygon._zoomHidden) return;
        if (mapMode === 'delete' || mapMode === 'delete-polygon') {
            if (
                confirm(
                    `'${polygon.title}' poligonunu silmek istediğinize emin misiniz?`,
                )
            ) {
                router.delete(route('polygons.destroy', polygon.id), {
                    preserveScroll: true,
                    preserveState: true,
                    onSuccess: () => {
                        setDeletedStack((prev) => [
                            ...prev,
                            { type: 'polygon', id: polygon.id },
                        ]);
                        setRedoDeletedStack([]);
                    },
                });
            }
        } else {
            // Bulunan poligonun orijinal verisini bul
            const originalPolygon =
                polygons.find(
                    (p) => p.id.toString() === polygon.id.toString(),
                ) || polygon;
            editPolygon(originalPolygon, true);
        }
    };

    useEffect(() => {
        let catId = null;
        let parentId = null;

        if (editingMarkerId) {
            const m = markers.find((x) => x.id === editingMarkerId);
            if (m) {
                catId = m.category_id;
                parentId = m.parent_id
                    ? `${m.parent_type === 'App\\Models\\Marker' ? 'marker' : 'polygon'}_${m.parent_id}`
                    : null;
            }
        } else if (editingPolygonId) {
            const p = polygons.find((x) => x.id === editingPolygonId);
            if (p) {
                catId = p.category_id;
                parentId = p.parent_id
                    ? `${p.parent_type === 'App\\Models\\Marker' ? 'marker' : 'polygon'}_${p.parent_id}`
                    : null;
            }
        }

        if (catId || parentId) {
            setExpandedCategories((prev) => {
                const next = { ...prev };
                if (catId) next[catId] = true;
                if (parentId) next[parentId] = true;
                return next;
            });
        }
    }, [editingMarkerId, editingPolygonId, markers, polygons]);

    // Harita popup'ındaki "Düzenle" butonuna basıldığında tetiklenen event listener
    useEffect(() => {
        const handleEditFromPopup = (e) => {
            const { id, type } = e.detail;
            if (type === 'marker') {
                const originalMarker = markers.find(
                    (m) => m.id.toString() === id.toString(),
                );
                if (originalMarker) {
                    editMarker(originalMarker, true);
                }
            } else if (type === 'polygon') {
                const originalPolygon = polygons.find(
                    (p) => p.id.toString() === id.toString(),
                );
                if (originalPolygon) {
                    editPolygon(originalPolygon, true);
                }
            }
        };

        window.addEventListener('edit-map-element', handleEditFromPopup);
        return () => {
            window.removeEventListener('edit-map-element', handleEditFromPopup);
        };
    }, [markers, polygons]);

    // Haritada Geoman eklentisiyle poligon çizimi bitirildiğinde, çizilen köşe koordinatlarını (coordinates) form state'ine aktar
    const handlePolygonComplete = (coordinates) => {
        if (mapMode === 'add-polygon' || mapMode === 'add-linestring') {
            setPolygonData('coordinates', coordinates);
            setActiveTab('add-polygon');
            setIsSidebarOpen(true);
        }
    };

    const editMarker = (marker, forceOpenSidebar = false, switchTab = true) => {
        setEditingMarkerId(marker.id);
        setEditingPolygonId(null);
        const newData = {
            name: marker.name || '',
            description: marker.description || '',
            category_id: marker.category_id || '',
            link: marker.link || '',
            links: marker.links || [],
            latitude: marker.latitude || '',
            longitude: marker.longitude || '',
            parent_id: marker.parent_id || '',
            parent_type: marker.parent_type || '',
            existing_images: marker.images || [],
            new_images: [],
            hide_symbology: marker.hide_symbology || false,
        };
        setMarkerData(newData);
        setMarkerDefaults(newData);
        if (switchTab) {
            setActiveTab('edit');
            setMapMode('edit-marker');
        }
        if (forceOpenSidebar) {
            setIsSidebarOpen(true);
        }
    };
    const [polygonHistory, setPolygonHistory] = useState([]);
    const [polygonRedoStack, setPolygonRedoStack] = useState([]);

    const editPolygon = (
        polygon,
        forceOpenSidebar = false,
        switchTab = true,
    ) => {
        setEditingPolygonId(polygon.id);
        setEditingMarkerId(null);
        setPolygonHistory([]);
        setPolygonRedoStack([]);

        let coords = [];
        let type = 'Polygon';
        if (polygon.geojson) {
            try {
                const geojson =
                    typeof polygon.geojson === 'string'
                        ? JSON.parse(polygon.geojson)
                        : polygon.geojson;
                type = geojson.type || 'Polygon';

                if (
                    geojson.type === 'Polygon' &&
                    geojson.coordinates.length > 0
                ) {
                    coords = geojson.coordinates[0].map((c) => ({
                        lat: c[1],
                        lng: c[0],
                    }));
                } else if (
                    geojson.type === 'LineString' &&
                    geojson.coordinates.length > 0
                ) {
                    coords = geojson.coordinates.map((c) => ({
                        lat: c[1],
                        lng: c[0],
                    }));
                } else if (
                    geojson.type === 'MultiLineString' &&
                    geojson.coordinates.length > 0
                ) {
                    coords = geojson.coordinates[0].map((c) => ({
                        lat: c[1],
                        lng: c[0],
                    }));
                } else if (
                    geojson.type === 'MultiPolygon' &&
                    geojson.coordinates.length > 0
                ) {
                    coords = geojson.coordinates[0][0].map((c) => ({
                        lat: c[1],
                        lng: c[0],
                    }));
                }
            } catch (e) {
                console.error('GeoJSON parse error', e);
            }
        }

        const newData = {
            name: polygon.name || '',
            description: polygon.description || '',
            category_id: polygon.category_id || '',
            link: polygon.link || '',
            links: polygon.links || [],
            type: type,
            coordinates: coords,
            parent_id: polygon.parent_id || '',
            parent_type: polygon.parent_type || '',
            existing_images: polygon.images || [],
            new_images: [],
            hide_symbology: polygon.hide_symbology || false,
        };
        setPolygonData(newData);
        setPolygonDefaults(newData);
        if (switchTab) {
            setActiveTab('edit');
            setMapMode('edit-polygon');
        }
        if (forceOpenSidebar) {
            setIsSidebarOpen(true);
        }
    };

    // Tree Construction
    const categoriesMap = React.useMemo(() => {
        const allItems = [];

        // Add markers
        markers.forEach((marker) => {
            allItems.push({ ...marker, type: 'marker', children: [] });
        });

        // Add polygons
        polygons.forEach((polygon) => {
            let geo = null;
            if (polygon.geojson) {
                try {
                    geo = JSON.parse(polygon.geojson);
                } catch (e) {}
            }
            allItems.push({
                ...polygon,
                type: 'polygon',
                geojson: geo,
                children: [],
            });
        });

        const itemMap = new window.Map();
        allItems.forEach((item) =>
            itemMap.set(`${item.type}_${item.id}`, item),
        );

        const rootItems = [];

        allItems.forEach((item) => {
            let parentRef = null;
            if (item.parent_id && item.parent_type) {
                const prefix =
                    item.parent_type === 'App\\Models\\Marker'
                        ? 'marker'
                        : 'polygon';
                parentRef = `${prefix}_${item.parent_id}`;
            }

            if (parentRef && itemMap.has(parentRef)) {
                itemMap.get(parentRef).children.push(item);
            } else {
                rootItems.push(item);
            }
        });

        // Helper to group items by category
        const groupByCategory = (items) => {
            const map = categories.map((cat) => ({
                ...cat,
                items: [],
            }));

            // Add a default category for items without one
            map.push({ id: 0, name: 'Kategorisiz', items: [], order: 999 });

            items.forEach((item) => {
                const cat =
                    map.find((c) => c.id === item.category_id) ||
                    map.find((c) => c.id === 0);
                if (cat) {
                    cat.items.push(item);
                }
            });

            return map.filter((cat) => cat.items.length > 0); // only return categories with items
        };

        const recursivelyGroup = (items) => {
            items.forEach((item) => {
                if (item.children.length > 0) {
                    item.childCategories = groupByCategory(item.children);
                    recursivelyGroup(item.children);
                }
            });
        };

        recursivelyGroup(rootItems);

        return groupByCategory(rootItems);
    }, [categories, markers, polygons]);

    const isItemVisible = (itemKey, item) => {
        if (hiddenItems[itemKey]) return false; // force hidden by user
        const cat = categories.find((c) => c.id === item.category_id);
        if (cat) {
            if (cat.min_zoom && mapZoom < cat.min_zoom) return false;
            if (cat.max_zoom && mapZoom > cat.max_zoom) return false;
        }
        return true;
    };

    // LOD Filter
    const rawVisibleMarkers = React.useMemo(() => {
        return markers
            .filter((m) => {
                return isItemVisible(`marker_${m.id}`, m);
            })
            .sort((a, b) => {
                const catA = categories.find((c) => c.id === a.category_id);
                const catB = categories.find((c) => c.id === b.category_id);
                const orderA = catA ? catA.order || 0 : 0;
                const orderB = catB ? catB.order || 0 : 0;
                return orderB - orderA; // DESC (top sidebar items render last -> physical top)
            });
    }, [markers, hiddenItems, mapZoom, categories]);

    const rawVisiblePolygons = React.useMemo(() => {
        return polygons
            .map((p) => {
                const itemKey = `polygon_${p.id}`;
                const cat = categories.find((c) => c.id === p.category_id);
                let _zoomHidden = false;
                const visible = isItemVisible(itemKey, p);

                if (!visible) {
                    if (cat && cat.border_always_visible) {
                        _zoomHidden = true;
                    }
                }
                return { ...p, _zoomHidden, _visible: visible || _zoomHidden };
            })
            .filter((p) => p._visible)
            .sort((a, b) => {
                const catA = categories.find((c) => c.id === a.category_id);
                const catB = categories.find((c) => c.id === b.category_id);
                const orderA = catA ? catA.order || 0 : 0;
                const orderB = catB ? catB.order || 0 : 0;
                return orderB - orderA; // DESC
            });
    }, [polygons, hiddenItems, mapZoom, categories]);

    const toggleItemExpanded = (itemId) => {
        setExpandedCategories((prev) => ({ ...prev, [itemId]: !prev[itemId] }));
    };

    const getAllDescendants = (item) => {
        let descendants = [];
        if (item.children && item.children.length > 0) {
            item.children.forEach((child) => {
                descendants.push(child);
                descendants = descendants.concat(getAllDescendants(child));
            });
        }
        return descendants;
    };

    const toggleItemVisibility = (e, itemKey, item) => {
        e.stopPropagation();
        setHiddenItems((prev) => {
            const nextHiddenState = !prev[itemKey];
            const next = { ...prev, [itemKey]: nextHiddenState };

            const descendants = getAllDescendants(item);
            descendants.forEach((child) => {
                const childKey = `${child.type}_${child.id}`;
                next[childKey] = nextHiddenState;
            });
            return next;
        });
    };

    const handleContextMenu = (e, item, type) => {
        e.preventDefault();
        e.stopPropagation();

        const menuItems = [];

        if (type === 'category') {
            menuItems.push({
                label: 'Zoom Sınırı Ayarla',
                onClick: () => {
                    setZoomSettingsOpen(item.id);
                    setTempMinZoom(item.min_zoom || '');
                    setTempMaxZoom(item.max_zoom || '');
                },
            });
            menuItems.push('separator');
            menuItems.push({
                label: 'Düzenle',
                onClick: () => {
                    openEditCategory(item.id);
                },
            });
            menuItems.push('separator');
            menuItems.push({
                label: 'Kategoriyi Sil',
                danger: true,
                onClick: () => {
                    if (
                        confirm(
                            'Bu kategoriyi silmek istediğinize emin misiniz?',
                        )
                    ) {
                        deleteCategory(item.id);
                    }
                },
            });
        } else {
            menuItems.push({
                label: 'Düzenle',
                onClick: () => {
                    if (type === 'marker') editMarker(item, true);
                    else editPolygon(item, true);
                },
            });
            menuItems.push('separator');
            menuItems.push({
                label: 'Sil',
                danger: true,
                onClick: () => {
                    if (
                        confirm('Bu öğeyi silmek istediğininize emin misiniz?')
                    ) {
                        if (type === 'marker') deleteMarker(item.id);
                        else deletePolygon(item.id);
                    }
                },
            });
        }

        setContextMenu({
            x: e.clientX,
            y: e.clientY,
            items: menuItems,
        });
    };

    const handleZoomTo = (e, item) => {
        e.stopPropagation();
        if (item.type === 'marker' || item.type === 'Marker' || item.latitude) {
            if (mapRef.current && item.latitude && item.longitude)
                mapRef.current.flyTo(item.latitude, item.longitude, 18);
        } else if (
            item.type === 'polygon' ||
            item.type === 'Polygon' ||
            item.geojson
        ) {
            if (mapRef.current && mapRef.current.fitBounds && item.geojson) {
                mapRef.current.fitBounds(item.geojson);
            }
        }
    };

    const handleItemSelect = (e, item) => {
        e.stopPropagation();
        if (item.type === 'marker' || item.type === 'Marker' || item.latitude) {
            if (mapRef.current && item.latitude && item.longitude)
                mapRef.current.flyTo(item.latitude, item.longitude, 18);
            editMarker(item, false, false);
        } else if (
            item.type === 'polygon' ||
            item.type === 'Polygon' ||
            item.geojson
        ) {
            if (mapRef.current && mapRef.current.fitBounds && item.geojson) {
                mapRef.current.fitBounds(item.geojson);
            }
            editPolygon(item, false, false);
        }
    };

    const handleSaveZoom = (categoryId) => {
        const category = categories.find((c) => c.id === categoryId);

        let minZ = tempMinZoom ? parseInt(tempMinZoom) : null;
        let maxZ = tempMaxZoom ? parseInt(tempMaxZoom) : null;

        if (minZ === 0) minZ = null;
        if (maxZ === 19) maxZ = null;

        const payload = {
            ...category,
            min_zoom: minZ,
            max_zoom: maxZ,
            border_always_visible: tempBorderAlwaysVisible,
        };
        router.put(route('categories.update', categoryId), payload, {
            preserveScroll: true,
            preserveState: true,
            onSuccess: () => {
                setZoomSettingsOpen(null);
                setFlashMessage({
                    success: 'Yakınlaştırma sınırı güncellendi',
                });
                setTimeout(() => setFlashMessage(null), 3000);
            },
        });
    };

    const [dragTargetIndex, setDragTargetIndex] = useState(null);

    // Sürükle Bırak Mantığı (Drag & Drop)
    const handleDragStart = (e, catIndex) => {
        setDraggedCategory(catIndex);
        setDragTargetIndex(null);
        e.dataTransfer.effectAllowed = 'move';
        // e.currentTarget represents the specific category container being dragged, not the whole list
        e.dataTransfer.setDragImage(e.currentTarget, 20, 20);
    };

    const handleDragOver = (e, index) => {
        e.preventDefault();
        if (dragTargetIndex !== index) {
            setDragTargetIndex(index);
        }
    };

    const handleDragEnd = () => {
        setDraggedCategory(null);
        setDragTargetIndex(null);
    };

    const handleDrop = (e, dropIndex) => {
        e.preventDefault();
        setDragTargetIndex(null);
        if (draggedCategory === null || draggedCategory === dropIndex) {
            setDraggedCategory(null);
            return;
        }

        setIsSavingOrder(true);
        const newCats = [...categories];
        const draggedItem = newCats[draggedCategory];

        newCats.splice(draggedCategory, 1);
        newCats.splice(dropIndex, 0, draggedItem);

        const payload = newCats.map((cat, idx) => ({ id: cat.id, order: idx }));

        router.post(
            route('categories.reorder'),
            { categories: payload },
            {
                onFinish: () => {
                    setIsSavingOrder(false);
                    setDraggedCategory(null);
                },
            },
        );
    };

    const submitMarker = (e) => {
        e.preventDefault();
        const routeName = editingMarkerId
            ? route('markers.update', editingMarkerId)
            : route('markers.store');

        if (editingMarkerId) {
            transformMarker((data) => ({
                ...data,
                _method: 'PUT',
            }));
        } else {
            transformMarker((data) => data); // Reset transform if needed
        }

        postMarker(routeName, {
            preserveScroll: true,
            preserveState: true,
            forceFormData: true,
            onSuccess: () => {
                resetMarker();
                setEditingMarkerId(null);
                setActiveTab('list');
                setMapMode('pan');
            },
            onError: (errors) => {
                setTimeout(() => {
                    const errorElement =
                        document.querySelector('.text-red-600');
                    if (errorElement) {
                        errorElement.scrollIntoView({
                            behavior: 'smooth',
                            block: 'center',
                        });
                        const input = errorElement.parentElement?.querySelector(
                            'input, select, textarea',
                        );
                        if (input) input.focus();
                    }
                }, 100);
            },
        });
    };

    const submitPolygon = (e) => {
        e.preventDefault();
        const routeName = editingPolygonId
            ? route('polygons.update', editingPolygonId)
            : route('polygons.store');

        if (editingPolygonId) {
            transformPolygon((data) => ({
                ...data,
                _method: 'PUT',
            }));
        } else {
            transformPolygon((data) => data);
        }

        postPolygon(routeName, {
            preserveScroll: true,
            preserveState: true,
            forceFormData: true,
            onSuccess: () => {
                resetPolygon();
                setEditingPolygonId(null);
                setActiveTab('list');
                setMapMode('pan');
            },
            onError: (errors) => {
                setTimeout(() => {
                    const errorElement =
                        document.querySelector('.text-red-600');
                    if (errorElement) {
                        errorElement.scrollIntoView({
                            behavior: 'smooth',
                            block: 'center',
                        });
                        const input = errorElement.parentElement?.querySelector(
                            'input, select, textarea',
                        );
                        if (input) input.focus();
                    }
                }, 100);
            },
        });
    };

    const [editingCategoryId, setEditingCategoryId] = useState(null);

    const resetCategoryForm = () => {
        setNewCategoryName('');
        setNewCategoryIcon('MapPin');
        setNewCategoryColor('#3b82f6');
        setNewCategoryMinZoom('');
        setNewCategoryMaxZoom('');
        setNewCategoryBorderAlwaysVisible(false);
        setShowCategoryForm(false);
        setEditingCategoryId(null);
        setIsSubmittingCategory(false);
    };

    const openEditCategory = (categoryId) => {
        const cat = categories.find((c) => c.id == categoryId);
        if (cat) {
            setNewCategoryName(cat.name);
            setNewCategoryIcon(cat.icon || 'MapPin');
            setNewCategoryColor(cat.color || '#3b82f6');
            setNewCategoryMinZoom(cat.min_zoom || '');
            setNewCategoryMaxZoom(cat.max_zoom || '');
            setNewCategoryBorderAlwaysVisible(
                cat.border_always_visible || false,
            );
            setEditingCategoryId(cat.id);
            setShowCategoryForm(true);
        }
    };

    const submitCategory = (e) => {
        e.preventDefault();
        if (!newCategoryName.trim()) return;

        setIsSubmittingCategory(true);
        let categoryType = 'marker';
        if (activeTab === 'add-polygon') {
            categoryType =
                polygonData.type === 'LineString' ? 'linestring' : 'polygon';
        }

        let minZ = newCategoryMinZoom ? parseInt(newCategoryMinZoom) : null;
        let maxZ = newCategoryMaxZoom ? parseInt(newCategoryMaxZoom) : null;
        if (minZ === 0) minZ = null;
        if (maxZ === 19) maxZ = null;

        const payload = {
            name: newCategoryName,
            type: categoryType,
            icon: newCategoryIcon,
            color: newCategoryColor,
            min_zoom: minZ,
            max_zoom: maxZ,
            border_always_visible: newCategoryBorderAlwaysVisible,
        };

        if (editingCategoryId) {
            router.put(route('categories.update', editingCategoryId), payload, {
                preserveScroll: true,
                onSuccess: resetCategoryForm,
                onError: () => setIsSubmittingCategory(false),
            });
        } else {
            router.post(route('categories.store'), payload, {
                preserveScroll: true,
                onSuccess: resetCategoryForm,
                onError: () => setIsSubmittingCategory(false),
            });
        }
    };

    const deleteMarker = (id) => {
        if (confirm('Bu işaretçiyi silmek istediğinize emin misiniz?')) {
            router.delete(route('markers.destroy', id), {
                preserveScroll: true,
                preserveState: true,
                onSuccess: () => {
                    setDeletedStack((prev) => [
                        ...prev,
                        { type: 'marker', id },
                    ]);
                    setRedoDeletedStack([]);
                },
            });
        }
    };

    const deletePolygon = (id) => {
        if (confirm('Bu poligonu silmek istediğinize emin misiniz?')) {
            router.delete(route('polygons.destroy', id), {
                preserveScroll: true,
                preserveState: true,
                onSuccess: () => {
                    setDeletedStack((prev) => [
                        ...prev,
                        { type: 'polygon', id },
                    ]);
                    setRedoDeletedStack([]);
                },
            });
        }
    };

    const deleteCategory = (id) => {
        if (
            confirm(
                'Bu kategoriyi silmek istediğinize emin misiniz? Kategoriye bağlı öğeler varsa silinemez.',
            )
        ) {
            router.delete(route('categories.destroy', id), {
                preserveScroll: true,
                onSuccess: () => resetCategoryForm(),
            });
        }
    };

    const mapMarkers = (rawVisibleMarkers || [])
        .filter(
            (m) => m && m.latitude && m.longitude && m.id !== editingMarkerId,
        )
        .map((m) => ({
            id: m.id.toString(),
            lat: Number(m.latitude),
            lng: Number(m.longitude),
            title: m.name || '',
            description: m.description || '',
            link: m.link || '',
            category: m.category || null,
            parent_id: m.parent_id,
            parent_type: m.parent_type,
            hide_symbology: m.hide_symbology,
        }));

    const mapPolygons = (rawVisiblePolygons || [])
        .filter((p) => p && p.id.toString() !== editingPolygonId)
        .map((p) => ({
            id: p.id.toString(),
            geojson: p.geojson,
            title: p.name || '',
            description: p.description || '',
            link: p.link || '',
            category: p.category || null,
            parent_id: p.parent_id,
            parent_type: p.parent_type,
            _zoomHidden: p._zoomHidden,
            hide_symbology: p.hide_symbology,
        }));

    if (
        (mapMode === 'add' || mapMode === 'edit-marker') &&
        markerData.latitude &&
        markerData.longitude
    ) {
        mapMarkers.push({
            id: 'temp-marker',
            lat: markerData.latitude,
            lng: markerData.longitude,
            title: editingMarkerId ? 'İşaretçiyi Taşı' : 'Yeni İşaretçi',
            description: editingMarkerId
                ? 'İşaretçiyi sürükleyerek yerini değiştirebilirsiniz.'
                : 'Bu işaretçiyi kaydetmek için formu doldurun. Sürükleyerek yerini değiştirebilirsiniz.',
        });
    }

    const visibleMarkers = mapMarkers;
    const visiblePolygons = mapPolygons;

    const [flashMessage, setFlashMessage] = useState({
        success: null,
        error: null,
    });

    useEffect(() => {
        if (flash?.success || flash?.error) {
            setFlashMessage({ success: flash.success, error: flash.error });
            const timer = setTimeout(() => {
                setFlashMessage({ success: null, error: null });
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [flash]);

    const closePanelAndReset = () => {
        resetMarker();
        resetPolygon();
        setEditingMarkerId(null);
        setEditingPolygonId(null);
        setActiveTab('list');
        setMapMode('pan');
        setIsSidebarOpen(false);
    };

    const [unsavedChangesModal, setUnsavedChangesModal] = useState(false);

    // Orta tıklayınca (M3) menüyü kapatıp "Hareket Et" moduna dönme ve kaydedilmemiş değişiklik uyarısı
    useEffect(() => {
        const handleMiddleClick = (e) => {
            // Sadece orta tık (M3) için çalışsın
            if (e.button !== 1) return;

            // Eğer poligon çizme modundaysak VE henüz çizim bitmediyse (koordinatlar boşsa),
            // M3 işlemini Leaflet/Geoman devralmalı (Çizimi bitirmek için).
            if (
                mapMode === 'add-polygon' &&
                (!polygonData.coordinates ||
                    polygonData.coordinates.length === 0)
            ) {
                return;
            }

            // Eğer panel açıksa
            if (
                activeTab === 'edit' ||
                activeTab === 'add' ||
                activeTab === 'add-polygon'
            ) {
                e.preventDefault();

                let isCurrentDirty = false;
                if (
                    activeTab === 'add' ||
                    (activeTab === 'edit' && editingMarkerId)
                ) {
                    isCurrentDirty = isMarkerDirty;
                } else if (activeTab === 'add-polygon') {
                    isCurrentDirty = polygonData.coordinates.length > 0;
                } else if (activeTab === 'edit' && editingPolygonId) {
                    isCurrentDirty = polygonHistory.length > 0;
                }

                if (isCurrentDirty) {
                    setUnsavedChangesModal(true);
                    return; // Kullanıcının kararını bekle
                }

                // Formu sıfırla ve kapat
                closePanelAndReset();
            }
        };

        document.addEventListener('mouseup', handleMiddleClick);
        return () => {
            document.removeEventListener('mouseup', handleMiddleClick);
        };
    }, [
        mapMode,
        activeTab,
        isMarkerDirty,
        isPolygonDirty,
        editingMarkerId,
        editingPolygonId,
        markerData,
        polygonData,
    ]);

    useEffect(() => {
        const handleUndo = () => {
            if (
                mapMode === 'edit-polygon' ||
                mapMode === 'edit-linestring' ||
                ((mapMode === 'add-polygon' || mapMode === 'add-linestring') &&
                    polygonData.coordinates.length > 0)
            ) {
                setPolygonHistory((prev) => {
                    if (prev.length > 0) {
                        const newHistory = [...prev];
                        const prevCoords = newHistory.pop();
                        setPolygonRedoStack((r) => [
                            ...r,
                            polygonData.coordinates,
                        ]);
                        setPolygonData('coordinates', prevCoords);
                        return newHistory;
                    }
                    return prev;
                });
            }
        };

        const handleRedo = () => {
            if (
                mapMode === 'edit-polygon' ||
                mapMode === 'edit-linestring' ||
                ((mapMode === 'add-polygon' || mapMode === 'add-linestring') &&
                    polygonData.coordinates.length > 0)
            ) {
                setPolygonRedoStack((prev) => {
                    if (prev.length > 0) {
                        const newRedo = [...prev];
                        const nextCoords = newRedo.pop();
                        setPolygonHistory((h) => [
                            ...h,
                            polygonData.coordinates,
                        ]);
                        setPolygonData('coordinates', nextCoords);
                        return newRedo;
                    }
                    return prev;
                });
            }
        };

        window.addEventListener('undo-polygon-point', handleUndo);
        window.addEventListener('redo-polygon-point', handleRedo);

        return () => {
            window.removeEventListener('undo-polygon-point', handleUndo);
            window.removeEventListener('redo-polygon-point', handleRedo);
        };
    }, [mapMode, polygonData.coordinates]);

    const handlePolygonEditChange = (coords) => {
        setPolygonHistory((prev) => [...prev, polygonData.coordinates]);
        setPolygonRedoStack([]);
        setPolygonData('coordinates', coords);
    };

    const renderCategory = (
        category,
        index = -1,
        depth = 0,
        parentNodeKey = 'root',
    ) => {
        const categoryNodeKey = `${parentNodeKey}_cat_${category.id}`;
        return (
            <div
                key={`cat-${category.id}-${depth}-${parentNodeKey}`}
                className={`mb-1 transition-all duration-300 ease-in-out ${depth > 0 ? 'ml-4 border-l-2 border-gray-100 pl-2' : ''} ${
                    draggedCategory === index && depth === 0
                        ? 'scale-95 opacity-40'
                        : 'scale-100 opacity-100'
                } ${
                    dragTargetIndex === index &&
                    draggedCategory !== index &&
                    depth === 0
                        ? draggedCategory < index
                            ? 'mb-2 border-b-2 border-indigo-400 pb-3'
                            : 'mt-2 border-t-2 border-indigo-400 pt-3'
                        : 'border-b-2 border-t-2 border-transparent'
                }`}
                draggable={depth === 0}
                onDragStart={
                    depth === 0 ? (e) => handleDragStart(e, index) : undefined
                }
                onDragOver={
                    depth === 0 ? (e) => handleDragOver(e, index) : undefined
                }
                onDrop={depth === 0 ? (e) => handleDrop(e, index) : undefined}
                onDragEnd={depth === 0 ? handleDragEnd : undefined}
            >
                <div
                    className="flex cursor-move items-center justify-between rounded-md border border-transparent p-2 transition-colors hover:border-gray-200 hover:bg-gray-100"
                    onContextMenu={(e) =>
                        handleContextMenu(e, category, 'category')
                    }
                    onClick={() => toggleItemExpanded(categoryNodeKey)}
                >
                    <div className="flex items-center gap-2">
                        {depth === 0 && (
                            <GripVertical
                                size={14}
                                className="flex-shrink-0 text-gray-400"
                            />
                        )}
                        {expandedCategories[categoryNodeKey] ? (
                            <ChevronDown
                                size={16}
                                className="shrink-0 text-gray-500"
                            />
                        ) : (
                            <ChevronRight
                                size={14}
                                className="flex-shrink-0 text-gray-500"
                            />
                        )}
                        <span className="flex items-center gap-2 whitespace-nowrap text-sm font-semibold text-gray-700">
                            {(() => {
                                const Icon =
                                    AvailableIcons[category.icon] ||
                                    AvailableIcons.MapPin;
                                return (
                                    <Icon
                                        size={16}
                                        color={category.color || '#3b82f6'}
                                    />
                                );
                            })()}
                            {category.name}
                        </span>
                    </div>
                    <div className="ml-4 flex items-center gap-2">
                        <span className="text-xs text-gray-400">
                            {category.items?.length || 0}
                        </span>
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                if (zoomSettingsOpen === category.id) {
                                    setZoomSettingsOpen(null);
                                } else {
                                    setZoomSettingsOpen(category.id);
                                    setTempMinZoom(category.min_zoom || '');
                                    setTempMaxZoom(category.max_zoom || '');
                                    setTempBorderAlwaysVisible(
                                        category.border_always_visible || false,
                                    );
                                }
                            }}
                            className="rounded p-1 text-gray-400 hover:bg-gray-200 hover:text-indigo-600"
                            title="Zoom Ayarı"
                        >
                            <Settings size={14} />
                        </button>
                    </div>
                </div>

                {zoomSettingsOpen === category.id && (
                    <div
                        className="relative z-10 mb-2 ml-6 rounded-md border border-gray-200 bg-white p-3 shadow-md"
                        draggable={true}
                        onDragStart={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                        }}
                    >
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                setZoomSettingsOpen(null);
                            }}
                            className="absolute right-1 top-1 text-gray-400 hover:text-gray-700"
                        >
                            <X size={14} />
                        </button>
                        <div className="mb-2 mt-2">
                            <label className="mb-1 flex justify-between text-xs font-medium text-gray-700">
                                <span>
                                    Yakınlaşma (Min): {formatScale(tempMaxZoom)}
                                </span>
                                <span>
                                    Uzaklaşma (Maks): {formatScale(tempMinZoom)}
                                </span>
                            </label>
                            <DualRangeSlider
                                minVal={tempMinZoom}
                                maxVal={tempMaxZoom}
                                setMinVal={setTempMinZoom}
                                setMaxVal={setTempMaxZoom}
                                maxZoomLimit={mapConfig.ADMIN_MAX_ZOOM}
                            />
                            {category.type === 'polygon' && (
                                <div className="mt-2 flex items-start gap-2">
                                    <input
                                        type="checkbox"
                                        id={`border-${category.id}`}
                                        checked={tempBorderAlwaysVisible}
                                        onChange={(e) =>
                                            setTempBorderAlwaysVisible(
                                                e.target.checked,
                                            )
                                        }
                                        className="mt-0.5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                                    />
                                    <label
                                        htmlFor={`border-${category.id}`}
                                        className="text-xs text-gray-600"
                                    >
                                        Görsel kaybolsa bile poligon sınırlarını
                                        her zaman göster
                                    </label>
                                </div>
                            )}
                        </div>
                        <div className="mt-2 flex items-center justify-between">
                            <p className="w-2/3 text-[10px] leading-tight text-gray-500">
                                Bu aralıktayken görünür. Sıfırlamak için ölçeği
                                iki uca çekin.
                            </p>
                            <button
                                onClick={() => handleSaveZoom(category.id)}
                                className="rounded-md bg-indigo-600 px-3 py-1 text-xs font-medium text-white hover:bg-indigo-700"
                            >
                                Kaydet
                            </button>
                        </div>
                    </div>
                )}

                {expandedCategories[categoryNodeKey] && (
                    <div className="ml-6 mt-1 flex flex-col gap-1 border-l-2 border-gray-100 pl-2">
                        {category.items?.length === 0 ? (
                            <p className="py-1 text-xs text-gray-400">
                                Bu kategoride öğe yok.
                            </p>
                        ) : (
                            category.items?.map((item) => {
                                const itemKey = `${item.type}_${item.id}`;
                                let isSidebarHidden = !isItemVisible(
                                    itemKey,
                                    item,
                                );
                                if (
                                    item.type === 'Polygon' ||
                                    item.type === 'polygon' ||
                                    item.geojson ||
                                    item.area
                                ) {
                                    if (
                                        category &&
                                        category.border_always_visible
                                    ) {
                                        if (!hiddenItems[itemKey]) {
                                            isSidebarHidden = false;
                                        }
                                    }
                                }

                                const isItemTypeMarker =
                                    item.type === 'marker' ||
                                    item.type === 'Marker' ||
                                    item.latitude ||
                                    item.location;
                                const isEditing = isItemTypeMarker
                                    ? Number(editingMarkerId) ===
                                      Number(item.id)
                                    : Number(editingPolygonId) ===
                                      Number(item.id);

                                return (
                                    <div key={itemKey}>
                                        <div
                                            onContextMenu={(e) =>
                                                handleContextMenu(
                                                    e,
                                                    item,
                                                    item.type,
                                                )
                                            }
                                            className={`flex cursor-pointer items-center justify-between rounded p-1.5 transition-colors ${
                                                isEditing
                                                    ? 'border border-emerald-500 bg-emerald-50'
                                                    : 'border border-transparent hover:bg-indigo-50'
                                            } ${isSidebarHidden ? 'opacity-50 grayscale' : ''}`}
                                        >
                                            <div
                                                className="flex flex-1 items-center gap-2"
                                                onClick={(e) => {
                                                    if (
                                                        item.childCategories &&
                                                        item.childCategories
                                                            .length > 0
                                                    ) {
                                                        toggleItemExpanded(
                                                            itemKey,
                                                        );
                                                    } else {
                                                        handleItemSelect(
                                                            e,
                                                            item,
                                                        );
                                                    }
                                                }}
                                            >
                                                {item.childCategories &&
                                                    item.childCategories
                                                        .length > 0 &&
                                                    (expandedCategories[
                                                        itemKey
                                                    ] ? (
                                                        <ChevronDown
                                                            size={16}
                                                            className="shrink-0 text-gray-500"
                                                        />
                                                    ) : (
                                                        <ChevronRight
                                                            size={16}
                                                            className="shrink-0 text-gray-500"
                                                        />
                                                    ))}
                                                <span className="flex items-center gap-1 whitespace-nowrap text-xs font-medium text-gray-700">
                                                    {(() => {
                                                        const itemCategory =
                                                            categories.find(
                                                                (c) =>
                                                                    c.id ===
                                                                    parseInt(
                                                                        item.category_id,
                                                                    ),
                                                            );
                                                        if (!itemCategory)
                                                            return null;
                                                        const Icon =
                                                            AvailableIcons[
                                                                itemCategory
                                                                    .icon
                                                            ] ||
                                                            AvailableIcons.MapPin;
                                                        return (
                                                            <Icon
                                                                size={14}
                                                                color={
                                                                    itemCategory.color ||
                                                                    '#3b82f6'
                                                                }
                                                            />
                                                        );
                                                    })()}
                                                    {item.name}
                                                </span>
                                            </div>
                                            <div className="flex items-center gap-1">
                                                <button
                                                    onClick={(e) =>
                                                        handleZoomTo(e, item)
                                                    }
                                                    className="rounded p-1 text-gray-400 hover:bg-gray-200 hover:text-indigo-600"
                                                    title="Odaklan"
                                                >
                                                    <Search size={14} />
                                                </button>
                                                <button
                                                    onClick={(e) =>
                                                        toggleItemVisibility(
                                                            e,
                                                            itemKey,
                                                            item,
                                                        )
                                                    }
                                                    className={`rounded p-1 ${isSidebarHidden ? 'text-gray-300 hover:text-gray-500' : 'text-emerald-500 hover:text-emerald-700'} hover:bg-gray-200`}
                                                    title={
                                                        isSidebarHidden
                                                            ? 'Göster'
                                                            : 'Gizle'
                                                    }
                                                >
                                                    {isSidebarHidden ? (
                                                        <EyeOff size={14} />
                                                    ) : (
                                                        <Eye size={14} />
                                                    )}
                                                </button>
                                            </div>
                                        </div>
                                        {item.childCategories &&
                                            item.childCategories.length > 0 &&
                                            expandedCategories[itemKey] && (
                                                <div className="ml-2 mt-1">
                                                    {item.childCategories.map(
                                                        (childCat) =>
                                                            renderCategory(
                                                                childCat,
                                                                -1,
                                                                depth + 1,
                                                                itemKey,
                                                            ),
                                                    )}
                                                </div>
                                            )}
                                    </div>
                                );
                            })
                        )}
                    </div>
                )}
            </div>
        );
    };

    return (
        <AuthenticatedLayout user={auth.user}>
            <Head title="Harita Yönetimi" />

            <div
                className={`admin-map-container relative overflow-hidden ${isLayerSidebarOpen ? 'layer-sidebar-open' : ''} ${isSidebarOpen ? 'admin-sidebar-open' : ''}`}
                style={{
                    height: 'calc(100dvh - 65px)',
                    '--sidebar-width': isLayerSidebarOpen
                        ? `${sidebarWidth}px`
                        : '0px',
                    '--resize-transition': isResizing
                        ? '0s'
                        : '0.3s ease-in-out',
                }}
            >
                <style
                    dangerouslySetInnerHTML={{
                        __html: `
                    .admin-map-container .leaflet-top.leaflet-left { margin-top: 280px; }
                    .admin-map-container .leaflet-top.leaflet-right { margin-top: 70px; }
                    
                    @media (min-width: 768px) {
                        .admin-map-container .undo-redo-container {
                            transform: translateX(var(--sidebar-width));
                            transition: transform var(--resize-transition);
                        }
                    }
                    @media (max-width: 767px) {
                        .admin-map-container .undo-redo-container {
                            transform: translateX(${isLayerSidebarOpen ? '70vw' : '0'});
                            transition: transform 0.3s ease-in-out;
                        }
                    }
                `,
                    }}
                />
                {/* Flash Messages */}
                {(flashMessage?.success || flashMessage?.error) && (
                    <div className="absolute left-1/2 top-4 z-[2000] min-w-[300px] -translate-x-1/2">
                        {flashMessage?.success && (
                            <div className="relative mb-2 rounded border border-green-400 bg-green-100 px-4 py-3 text-green-700 shadow-lg transition-opacity duration-500">
                                <span className="block sm:inline">
                                    {flashMessage.success}
                                </span>
                                <button
                                    onClick={() =>
                                        setFlashMessage({
                                            ...flashMessage,
                                            success: null,
                                        })
                                    }
                                    className="absolute bottom-0 right-0 top-0 px-4 py-3"
                                >
                                    <span className="font-bold text-green-500">
                                        &times;
                                    </span>
                                </button>
                            </div>
                        )}
                        {flashMessage?.error && (
                            <div className="relative rounded border border-red-400 bg-red-100 px-4 py-3 text-red-700 shadow-lg transition-opacity duration-500">
                                <span className="block sm:inline">
                                    {flashMessage.error}
                                </span>
                                <button
                                    onClick={() =>
                                        setFlashMessage({
                                            ...flashMessage,
                                            error: null,
                                        })
                                    }
                                    className="absolute bottom-0 right-0 top-0 px-4 py-3"
                                >
                                    <span className="font-bold text-red-500">
                                        &times;
                                    </span>
                                </button>
                            </div>
                        )}
                    </div>
                )}

                {/* Unsaved Changes Modal */}
                {unsavedChangesModal && (
                    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/50 backdrop-blur-sm">
                        <div className="w-full max-w-md rounded-lg bg-white p-6 shadow-xl">
                            <h3 className="mb-4 text-lg font-medium text-gray-900">
                                Değişiklikleri Kaydet
                            </h3>
                            <p className="mb-6 text-sm text-gray-500">
                                Yaptığınız değişiklikleri kaydetmek istiyor
                                musunuz?
                            </p>
                            <div className="flex justify-end gap-3">
                                <button
                                    onClick={() =>
                                        setUnsavedChangesModal(false)
                                    }
                                    className="rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
                                >
                                    İptal
                                </button>
                                <button
                                    onClick={() => {
                                        setUnsavedChangesModal(false);
                                        closePanelAndReset();
                                    }}
                                    className="rounded-md bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700"
                                >
                                    Hayır
                                </button>
                                <button
                                    onClick={() => {
                                        setUnsavedChangesModal(false);
                                        if (
                                            activeTab === 'add' ||
                                            (activeTab === 'edit' &&
                                                editingMarkerId)
                                        ) {
                                            submitMarker({
                                                preventDefault: () => {},
                                            });
                                        } else {
                                            submitPolygon({
                                                preventDefault: () => {},
                                            });
                                        }
                                        // Form başarıyla gönderilirse zaten submit methodu içinde kapanıyor, ama yan paneli kapatmayı garantileyelim:
                                        setIsSidebarOpen(false);
                                    }}
                                    className="rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700"
                                >
                                    Evet
                                </button>
                            </div>
                        </div>
                    </div>
                )}

                <Map
                    ref={mapRef}
                    center={mapConfig.DEFAULT_CENTER}
                    zoom={mapConfig.DEFAULT_ZOOM}
                    maxZoom={mapConfig.ADMIN_MAX_ZOOM}
                    isAdmin={true}
                    onZoomChange={setMapZoom}
                    markers={visibleMarkers}
                    polygons={visiblePolygons}
                    mode={mapMode}
                    globalCanUndo={deletedStack.length > 0}
                    globalCanRedo={redoDeletedStack.length > 0}
                    editCanUndo={polygonHistory.length > 0}
                    editCanRedo={polygonRedoStack.length > 0}
                    onMapClick={handleMapClick}
                    onMarkerClick={handleMarkerClick}
                    onPolygonClick={handlePolygonClick}
                    onPolygonComplete={handlePolygonComplete}
                    editingPolygonCoords={
                        [
                            'add-polygon',
                            'edit-polygon',
                            'add-linestring',
                            'edit-linestring',
                        ].includes(mapMode)
                            ? polygonData.coordinates
                            : undefined
                    }
                    editingPolygonType={
                        [
                            'add-polygon',
                            'edit-polygon',
                            'add-linestring',
                            'edit-linestring',
                        ].includes(mapMode)
                            ? polygonData.type
                            : undefined
                    }
                    editingPolygonCategory={
                        [
                            'add-polygon',
                            'edit-polygon',
                            'add-linestring',
                            'edit-linestring',
                        ].includes(mapMode) && polygonData.category_id
                            ? categories.find(
                                  (c) =>
                                      c.id ===
                                      parseInt(polygonData.category_id),
                              ) || null
                            : null
                    }
                    onPolygonEdit={handlePolygonEditChange}
                    onCancelEdit={() => {
                        let isCurrentDirty = false;
                        if (
                            activeTab === 'add' ||
                            (activeTab === 'edit' && editingMarkerId)
                        ) {
                            isCurrentDirty = isMarkerDirty;
                        } else if (activeTab === 'add-polygon') {
                            isCurrentDirty = polygonData.coordinates.length > 0;
                        } else if (activeTab === 'edit' && editingPolygonId) {
                            isCurrentDirty = polygonHistory.length > 0;
                        }

                        if (isCurrentDirty) {
                            setUnsavedChangesModal(true);
                        } else {
                            closePanelAndReset();
                        }
                    }}
                    className="z-0 h-full w-full"
                />

                {!isLayerSidebarOpen && (
                    <button
                        onClick={() => setIsLayerSidebarOpen(true)}
                        className="absolute left-4 top-4 z-10 rounded-md bg-white p-3 text-gray-700 shadow-md hover:bg-gray-50"
                        title="Katmanları Aç"
                    >
                        <Layers size={20} />
                    </button>
                )}

                {/* Sol Menü: Katmanlar */}
                <div
                    className={`absolute bottom-0 left-0 top-0 z-[1000] flex w-[70vw] flex-col overflow-hidden border-r border-gray-200 bg-white/95 shadow-2xl backdrop-blur-md transition-transform duration-300 md:max-w-[70vw] ${
                        isLayerSidebarOpen
                            ? 'translate-x-0'
                            : '-translate-x-full'
                    }`}
                    style={{
                        width:
                            window.innerWidth >= 768 ? sidebarWidth : undefined,
                    }}
                >
                    <div
                        className="absolute bottom-0 right-0 top-0 z-50 hidden w-1.5 cursor-col-resize transition-colors hover:bg-indigo-400 active:bg-indigo-600 md:block"
                        onMouseDown={(e) => {
                            e.preventDefault();
                            setIsResizing(true);
                            const startX = e.clientX;
                            const startWidth = sidebarWidth;
                            const onMouseMove = (moveEvent) => {
                                const newWidth = Math.min(
                                    Math.max(
                                        250,
                                        startWidth +
                                            (moveEvent.clientX - startX),
                                    ),
                                    window.innerWidth * 0.7,
                                );
                                setSidebarWidth(newWidth);
                            };
                            const onMouseUp = () => {
                                setIsResizing(false);
                                document.removeEventListener(
                                    'mousemove',
                                    onMouseMove,
                                );
                                document.removeEventListener(
                                    'mouseup',
                                    onMouseUp,
                                );
                            };
                            document.addEventListener('mousemove', onMouseMove);
                            document.addEventListener('mouseup', onMouseUp);
                        }}
                    />
                    <div className="flex items-center justify-between border-b border-gray-200 bg-gray-50 p-4">
                        <h2 className="flex items-center gap-2 font-semibold text-gray-800">
                            <Layers size={18} /> Katmanlar
                        </h2>
                        <button
                            onClick={() => setIsLayerSidebarOpen(false)}
                            className="rounded p-1 text-gray-500 hover:bg-gray-200"
                        >
                            <X size={18} />
                        </button>
                    </div>

                    <div className="flex-1 overflow-x-auto overflow-y-auto p-2">
                        <div className="min-w-max pr-4">
                            {isSavingOrder && (
                                <div className="mb-2 rounded bg-indigo-50 p-1 text-center text-xs text-indigo-600">
                                    Sıralama kaydediliyor...
                                </div>
                            )}
                            {categoriesMap.length === 0 ? (
                                <p className="mt-4 text-center text-xs text-gray-500">
                                    Henüz katman yok.
                                </p>
                            ) : (
                                categoriesMap.map((category, index) =>
                                    renderCategory(category, index),
                                )
                            )}
                        </div>
                    </div>
                </div>

                {contextMenu && (
                    <ContextMenu
                        x={contextMenu.x}
                        y={contextMenu.y}
                        items={contextMenu.items}
                        onClose={() => setContextMenu(null)}
                    />
                )}

                <div
                    className={`custom-toolbar absolute left-4 top-20 z-[1000] flex flex-col gap-2 rounded-lg bg-white/80 p-2 shadow-md backdrop-blur-sm ${isLayerSidebarOpen ? 'hidden md:flex' : ''}`}
                    style={{
                        transform: `translateX(var(--sidebar-width))`,
                        transition:
                            'transform var(--resize-transition, 0.3s ease-in-out)',
                    }}
                >
                    <button
                        title="Hareket Et"
                        onClick={() => setMapMode('pan')}
                        className={`flex items-center justify-center rounded-md p-2 transition-colors ${mapMode === 'pan' ? 'bg-indigo-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-100'}`}
                    >
                        <MousePointer2 size={20} />
                    </button>
                    <button
                        title="Marker Ekle"
                        onClick={() => {
                            setMapMode('add');
                            setActiveTab('add');
                            if (window.innerWidth >= 768)
                                setIsSidebarOpen(true);
                            const emptyData = {
                                name: '',
                                description: '',
                                category_id: '',
                                link: '',
                                links: [],
                                existing_images: [],
                                new_images: [],
                                latitude: '',
                                longitude: '',
                            };
                            setMarkerDefaults(emptyData);
                            setMarkerData(emptyData);
                            setEditingMarkerId(null);
                        }}
                        className={`flex items-center justify-center rounded-md p-2 transition-colors ${mapMode === 'add' ? 'bg-indigo-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-100'}`}
                    >
                        <MapPin size={20} />
                    </button>
                    {editingMarkerId && (
                        <button
                            title="Marker Düzenle"
                            onClick={() => {
                                setMapMode('edit-marker');
                                setActiveTab('add');
                                if (window.innerWidth >= 768)
                                    setIsSidebarOpen(true);
                            }}
                            className={`flex items-center justify-center rounded-md p-2 transition-colors ${mapMode === 'edit-marker' ? 'bg-indigo-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-100'}`}
                        >
                            <PenTool size={20} />
                        </button>
                    )}
                    <button
                        title="LineString Ekle"
                        onClick={() => {
                            setMapMode('add-linestring');
                            setActiveTab('add-polygon');
                            if (window.innerWidth >= 768)
                                setIsSidebarOpen(true);
                            const emptyData = {
                                name: '',
                                description: '',
                                category_id: '',
                                link: '',
                                links: [],
                                existing_images: [],
                                new_images: [],
                                type: 'LineString',
                                coordinates: [],
                            };
                            setPolygonDefaults(emptyData);
                            setPolygonData(emptyData);
                            setEditingPolygonId(null);
                        }}
                        className={`flex items-center justify-center rounded-md p-2 transition-colors ${mapMode === 'add-linestring' ? 'bg-indigo-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-100'}`}
                    >
                        <Route size={20} />
                    </button>
                    <button
                        title="Poligon Ekle"
                        onClick={() => {
                            setMapMode('add-polygon');
                            setActiveTab('add-polygon');
                            if (window.innerWidth >= 768)
                                setIsSidebarOpen(true);
                            const emptyData = {
                                name: '',
                                description: '',
                                category_id: '',
                                link: '',
                                links: [],
                                existing_images: [],
                                new_images: [],
                                type: 'Polygon',
                                coordinates: [],
                            };
                            setPolygonDefaults(emptyData);
                            setPolygonData(emptyData);
                            setEditingPolygonId(null);
                        }}
                        className={`flex items-center justify-center rounded-md p-2 transition-colors ${mapMode === 'add-polygon' ? 'bg-indigo-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-100'}`}
                    >
                        <Hexagon size={20} />
                    </button>
                    {editingPolygonId && (
                        <button
                            title="Şekil Düzenle"
                            onClick={() => {
                                setMapMode('edit-polygon');
                                setActiveTab('add-polygon');
                                if (window.innerWidth >= 768)
                                    setIsSidebarOpen(true);
                            }}
                            className={`flex items-center justify-center rounded-md p-2 transition-colors ${mapMode === 'edit-polygon' ? 'bg-indigo-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-100'}`}
                        >
                            <PenTool size={20} />
                        </button>
                    )}
                    <button
                        title="Sil"
                        onClick={() => setMapMode('delete')}
                        className={`flex items-center justify-center rounded-md p-2 transition-colors ${mapMode === 'delete' ? 'bg-red-600 text-white' : 'bg-white text-gray-700 text-red-600 hover:bg-gray-100'}`}
                    >
                        <Trash2 size={20} />
                    </button>
                </div>

                {!isSidebarOpen && (
                    <button
                        onClick={() => setIsSidebarOpen(true)}
                        className="absolute right-4 top-4 z-10 rounded-md bg-white p-3 text-gray-700 shadow-md hover:bg-gray-50"
                    >
                        <svg
                            className="h-6 w-6"
                            fill="none"
                            stroke="currentColor"
                            viewBox="0 0 24 24"
                        >
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M4 6h16M4 12h16M4 18h16"
                            />
                        </svg>
                    </button>
                )}

                <div
                    className={`absolute right-0 top-0 z-[1200] flex h-full w-[70vw] transform flex-col bg-white shadow-2xl transition-transform duration-300 ease-in-out md:w-96 ${isSidebarOpen ? 'translate-x-0' : 'translate-x-full'}`}
                >
                    <div className="flex items-center justify-between border-b p-4">
                        <h3 className="text-lg font-medium text-gray-900">
                            Yönetim Paneli
                        </h3>
                        <button
                            onClick={() => setIsSidebarOpen(false)}
                            className="text-gray-500 hover:text-gray-700"
                        >
                            <svg
                                className="h-6 w-6"
                                fill="none"
                                stroke="currentColor"
                                viewBox="0 0 24 24"
                            >
                                <path
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                    strokeWidth={2}
                                    d="M6 18L18 6M6 6l12 12"
                                />
                            </svg>
                        </button>
                    </div>

                    <div className="flex overflow-x-auto border-b">
                        <button
                            className={`flex-1 whitespace-nowrap px-4 py-3 text-sm font-medium ${activeTab === 'add' ? 'border-b-2 border-indigo-500 text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}
                            onClick={() => {
                                setActiveTab('add');
                                setMapMode('add');
                                const emptyData = {
                                    name: '',
                                    description: '',
                                    category_id: '',
                                    link: '',
                                    links: [],
                                    existing_images: [],
                                    new_images: [],
                                    latitude: '',
                                    longitude: '',
                                };
                                setMarkerDefaults(emptyData);
                                setMarkerData(emptyData);
                                setEditingMarkerId(null);
                            }}
                        >
                            Marker Ekle
                        </button>
                        <button
                            className={`flex-1 whitespace-nowrap px-4 py-3 text-sm font-medium ${activeTab === 'add-polygon' ? 'border-b-2 border-indigo-500 text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}
                            onClick={() => {
                                setActiveTab('add-polygon');
                                setMapMode('add-polygon');
                                const emptyData = {
                                    name: '',
                                    description: '',
                                    category_id: '',
                                    link: '',
                                    links: [],
                                    existing_images: [],
                                    new_images: [],
                                    type: 'Polygon',
                                    coordinates: [],
                                };
                                setPolygonDefaults(emptyData);
                                setPolygonData(emptyData);
                                setEditingPolygonId(null);
                            }}
                        >
                            Şekil Ekle
                        </button>
                        {(editingMarkerId || editingPolygonId) && (
                            <button
                                className={`flex-1 whitespace-nowrap px-4 py-3 text-sm font-medium ${activeTab === 'edit' ? 'border-b-2 border-indigo-500 text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}
                                onClick={() => setActiveTab('edit')}
                            >
                                Düzenle
                            </button>
                        )}
                        <button
                            className={`flex-1 whitespace-nowrap px-4 py-3 text-sm font-medium ${activeTab === 'import-export' ? 'border-b-2 border-indigo-500 text-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}
                            onClick={() => {
                                setActiveTab('import-export');
                                setMapMode('pan');
                            }}
                        >
                            Yedekle
                        </button>
                    </div>

                    <div className="flex-1 overflow-y-auto p-4">
                        {(activeTab === 'add' ||
                            (activeTab === 'edit' && editingMarkerId)) && (
                            <form onSubmit={submitMarker} className="space-y-4">
                                <h4 className="border-b pb-2 font-semibold text-gray-700">
                                    {editingMarkerId
                                        ? 'İşaretçi Düzenle'
                                        : 'Yeni İşaretçi Ekle'}
                                </h4>
                                {!editingMarkerId && (
                                    <div className="mb-4 rounded-md bg-blue-50 p-3 text-sm text-blue-700">
                                        <strong>İpucu:</strong> Haritaya
                                        tıklayarak marker ekleyebilirsiniz.
                                    </div>
                                )}
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">
                                        İsim
                                    </label>
                                    <input
                                        type="text"
                                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                                        value={markerData.name}
                                        onChange={(e) =>
                                            setMarkerData(
                                                'name',
                                                e.target.value,
                                            )
                                        }
                                    />
                                    {errorsMarker.name && (
                                        <div className="text-sm text-red-600">
                                            {errorsMarker.name}
                                        </div>
                                    )}
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">
                                        Kategori
                                    </label>
                                    <div className="mt-1 flex gap-2">
                                        <select
                                            className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                                            value={markerData.category_id}
                                            onChange={(e) =>
                                                setMarkerData(
                                                    'category_id',
                                                    e.target.value,
                                                )
                                            }
                                        >
                                            <option value="">Seçiniz...</option>
                                            {categories.map((cat) => (
                                                <option
                                                    key={cat.id}
                                                    value={cat.id}
                                                >
                                                    {cat.name}
                                                </option>
                                            ))}
                                        </select>
                                        <button
                                            type="button"
                                            onClick={() =>
                                                resetCategoryForm() ||
                                                setShowCategoryForm(
                                                    !showCategoryForm,
                                                )
                                            }
                                            className="inline-flex items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium leading-4 text-gray-700 shadow-sm hover:bg-gray-50"
                                        >
                                            + Ekle
                                        </button>
                                        {markerData.category_id && (
                                            <button
                                                type="button"
                                                onClick={() =>
                                                    openEditCategory(
                                                        markerData.category_id,
                                                    )
                                                }
                                                className="inline-flex items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium leading-4 text-gray-700 shadow-sm hover:bg-gray-50"
                                            >
                                                ✎ Düzenle
                                            </button>
                                        )}
                                    </div>
                                    {errorsMarker.category_id && (
                                        <div className="text-sm text-red-600">
                                            {errorsMarker.category_id}
                                        </div>
                                    )}

                                    {showCategoryForm && (
                                        <div className="mt-2 rounded-md border bg-gray-50 p-3 shadow-inner">
                                            <label className="block text-xs font-medium text-gray-700">
                                                {editingCategoryId
                                                    ? 'Kategoriyi Düzenle'
                                                    : 'Yeni Marker Kategorisi'}
                                            </label>
                                            <div className="mt-1 flex flex-col gap-2">
                                                <input
                                                    type="text"
                                                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                                                    value={newCategoryName}
                                                    onChange={(e) =>
                                                        setNewCategoryName(
                                                            e.target.value,
                                                        )
                                                    }
                                                    placeholder="Kategori adı"
                                                />

                                                <div className="flex items-center gap-2">
                                                    <div className="w-full flex-1">
                                                        <label className="mb-2 block text-[10px] uppercase text-gray-500">
                                                            İkon Seç (
                                                            {
                                                                Object.keys(
                                                                    AvailableIcons,
                                                                ).length
                                                            }{' '}
                                                            ikon)
                                                        </label>
                                                        <div className="grid max-h-40 grid-cols-6 gap-2 overflow-y-auto rounded-md border border-gray-300 bg-white p-2">
                                                            {Object.entries(
                                                                AvailableIcons,
                                                            ).map(
                                                                ([
                                                                    key,
                                                                    IconComponent,
                                                                ]) => (
                                                                    <button
                                                                        key={
                                                                            key
                                                                        }
                                                                        type="button"
                                                                        onClick={() =>
                                                                            setNewCategoryIcon(
                                                                                key,
                                                                            )
                                                                        }
                                                                        className={`flex items-center justify-center rounded border p-2 transition-colors ${
                                                                            newCategoryIcon ===
                                                                            key
                                                                                ? 'border-indigo-600 bg-indigo-50 text-indigo-700'
                                                                                : 'border-transparent text-gray-600 hover:bg-gray-100'
                                                                        }`}
                                                                        title={
                                                                            key
                                                                        }
                                                                    >
                                                                        <IconComponent
                                                                            size={
                                                                                20
                                                                            }
                                                                        />
                                                                    </button>
                                                                ),
                                                            )}
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <label className="mb-2 block text-[10px] uppercase text-gray-500">
                                                            Renk
                                                        </label>
                                                        <input
                                                            type="color"
                                                            className="block h-12 w-12 cursor-pointer rounded-md border-gray-300 shadow-sm"
                                                            value={
                                                                newCategoryColor
                                                            }
                                                            onChange={(e) =>
                                                                setNewCategoryColor(
                                                                    e.target
                                                                        .value,
                                                                )
                                                            }
                                                        />
                                                    </div>
                                                </div>

                                                <div className="rounded-md border border-gray-200 bg-white p-2">
                                                    <label className="mb-2 block text-[10px] uppercase text-gray-500">
                                                        Görünürlük Zoom Aralığı
                                                    </label>
                                                    <div className="mb-2">
                                                        <label className="mb-1 flex justify-between text-xs font-medium text-gray-700">
                                                            <span>
                                                                Yakınlaşma
                                                                (Min):{' '}
                                                                {formatScale(
                                                                    newCategoryMaxZoom,
                                                                )}
                                                            </span>
                                                            <span>
                                                                Uzaklaşma
                                                                (Maks):{' '}
                                                                {formatScale(
                                                                    newCategoryMinZoom,
                                                                )}
                                                            </span>
                                                        </label>
                                                        <DualRangeSlider
                                                            minVal={
                                                                newCategoryMinZoom
                                                            }
                                                            maxVal={
                                                                newCategoryMaxZoom
                                                            }
                                                            setMinVal={
                                                                setNewCategoryMinZoom
                                                            }
                                                            setMaxVal={
                                                                setNewCategoryMaxZoom
                                                            }
                                                            maxZoomLimit={
                                                                mapConfig.ADMIN_MAX_ZOOM
                                                            }
                                                        />
                                                    </div>
                                                </div>

                                                <div className="mt-1 flex gap-2">
                                                    {editingCategoryId && (
                                                        <button
                                                            type="button"
                                                            onClick={() =>
                                                                deleteCategory(
                                                                    editingCategoryId,
                                                                )
                                                            }
                                                            className="inline-flex flex-1 items-center justify-center rounded-md border border-transparent bg-red-600 px-3 py-2 text-sm font-medium leading-4 text-white shadow-sm hover:bg-red-700"
                                                        >
                                                            Sil
                                                        </button>
                                                    )}
                                                    <button
                                                        type="button"
                                                        onClick={submitCategory}
                                                        disabled={
                                                            isSubmittingCategory
                                                        }
                                                        className="inline-flex flex-1 items-center justify-center rounded-md border border-transparent bg-indigo-600 px-3 py-2 text-sm font-medium leading-4 text-white shadow-sm hover:bg-indigo-700"
                                                    >
                                                        {editingCategoryId
                                                            ? 'Güncelle'
                                                            : 'Ekle'}
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700">
                                            Enlem
                                        </label>
                                        <input
                                            type="text"
                                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                                            value={markerData.latitude}
                                            onChange={(e) =>
                                                setMarkerData({
                                                    ...markerData,
                                                    latitude: e.target.value,
                                                })
                                            }
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700">
                                            Boylam
                                        </label>
                                        <input
                                            type="text"
                                            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                                            value={markerData.longitude}
                                            onChange={(e) =>
                                                setMarkerData({
                                                    ...markerData,
                                                    longitude: e.target.value,
                                                })
                                            }
                                        />
                                    </div>
                                </div>
                                <div className="mt-4 flex items-center">
                                    <input
                                        id="marker_hide_symbology"
                                        type="checkbox"
                                        className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                                        checked={markerData.hide_symbology}
                                        onChange={(e) =>
                                            setMarkerData({
                                                ...markerData,
                                                hide_symbology:
                                                    e.target.checked,
                                            })
                                        }
                                    />
                                    <label
                                        htmlFor="marker_hide_symbology"
                                        className="ml-2 block text-sm text-gray-900"
                                    >
                                        Sembolojiyi Gizle (Haritada görünmez
                                        yap)
                                    </label>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">
                                        Bağlı Olduğu Element (Ebeveyn)
                                    </label>
                                    <ParentSelector
                                        value={`${markerData.parent_type || ''}|${markerData.parent_id || ''}`}
                                        onChange={(val) => {
                                            if (val === '|') {
                                                setMarkerData((prev) => ({
                                                    ...prev,
                                                    parent_type: '',
                                                    parent_id: '',
                                                }));
                                            } else {
                                                const [type, id] =
                                                    val.split('|');
                                                setMarkerData((prev) => ({
                                                    ...prev,
                                                    parent_type: type,
                                                    parent_id: id,
                                                }));
                                            }
                                        }}
                                        polygons={polygons}
                                        markers={markers}
                                        categories={categories}
                                        editingId={editingMarkerId}
                                        editingType="marker"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">
                                        Açıklama (Markdown Destekli)
                                    </label>
                                    <p className="mb-1 text-xs text-gray-500">
                                        Metin içi kalınlaştırma (**kalın**),
                                        liste, link
                                        ([Google](https://google.com)) gibi
                                        Markdown özelliklerini
                                        kullanabilirsiniz.
                                    </p>
                                    <textarea
                                        rows={3}
                                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                                        value={markerData.description}
                                        onChange={(e) =>
                                            setMarkerData(
                                                'description',
                                                e.target.value,
                                            )
                                        }
                                    />
                                </div>

                                <div className="border-t pt-4">
                                    <div className="mb-2 flex items-center justify-between">
                                        <label className="block text-sm font-medium text-gray-700">
                                            Ekstra Bağlantılar (Linkler)
                                        </label>
                                        <button
                                            type="button"
                                            onClick={() =>
                                                setMarkerData('links', [
                                                    ...markerData.links,
                                                    { title: '', url: '' },
                                                ])
                                            }
                                            className="text-xs font-medium text-indigo-600 hover:text-indigo-800"
                                        >
                                            + Yeni Link Ekle
                                        </button>
                                    </div>
                                    <div className="space-y-2">
                                        {markerData.links.map((link, index) => (
                                            <div
                                                key={index}
                                                className="flex items-center gap-2"
                                            >
                                                <input
                                                    type="text"
                                                    placeholder="Link Başlığı"
                                                    className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                                                    value={link.title}
                                                    onChange={(e) => {
                                                        const newLinks = [
                                                            ...markerData.links,
                                                        ];
                                                        newLinks[index].title =
                                                            e.target.value;
                                                        setMarkerData(
                                                            'links',
                                                            newLinks,
                                                        );
                                                    }}
                                                />
                                                <input
                                                    type="url"
                                                    placeholder="https://..."
                                                    className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                                                    value={link.url}
                                                    onChange={(e) => {
                                                        const newLinks = [
                                                            ...markerData.links,
                                                        ];
                                                        newLinks[index].url =
                                                            e.target.value;
                                                        setMarkerData(
                                                            'links',
                                                            newLinks,
                                                        );
                                                    }}
                                                />
                                                <button
                                                    type="button"
                                                    className="px-2 font-bold text-red-500 hover:text-red-700"
                                                    onClick={() => {
                                                        const newLinks = [
                                                            ...markerData.links,
                                                        ];
                                                        newLinks.splice(
                                                            index,
                                                            1,
                                                        );
                                                        setMarkerData(
                                                            'links',
                                                            newLinks,
                                                        );
                                                    }}
                                                >
                                                    ×
                                                </button>
                                            </div>
                                        ))}
                                    </div>
                                </div>

                                <ImageUploader
                                    existingImages={markerData.existing_images}
                                    newImages={markerData.new_images}
                                    onExistingRemove={(idx) => {
                                        const updated = [
                                            ...markerData.existing_images,
                                        ];
                                        updated.splice(idx, 1);
                                        setMarkerData(
                                            'existing_images',
                                            updated,
                                        );
                                    }}
                                    onNewAdd={(files) => {
                                        setMarkerData('new_images', [
                                            ...markerData.new_images,
                                            ...files,
                                        ]);
                                    }}
                                    onNewRemove={(idx) => {
                                        const updated = [
                                            ...markerData.new_images,
                                        ];
                                        updated.splice(idx, 1);
                                        setMarkerData('new_images', updated);
                                    }}
                                />

                                <button
                                    type="submit"
                                    disabled={processingMarker}
                                    className="w-full rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-indigo-700 disabled:bg-indigo-400"
                                >
                                    {editingMarkerId
                                        ? 'Marker Güncelle'
                                        : 'Marker Kaydet'}
                                </button>
                            </form>
                        )}

                        {(activeTab === 'add-polygon' ||
                            (activeTab === 'edit' && editingPolygonId)) && (
                            <form
                                onSubmit={submitPolygon}
                                className="space-y-4"
                            >
                                <h4 className="border-b pb-2 font-semibold text-gray-700">
                                    {editingPolygonId
                                        ? 'Poligon Düzenle'
                                        : 'Yeni Poligon Ekle'}
                                </h4>
                                <div className="mb-4 rounded-md bg-blue-50 p-3 text-sm text-blue-700">
                                    <strong>İpucu:</strong>{' '}
                                    {editingPolygonId
                                        ? 'Poligonun köşelerini sürükleyerek değiştirebilir, ara noktalara tıklayarak yeni köşeler ekleyebilirsiniz.'
                                        : 'Haritaya tıklayarak poligon köşelerini çizin. Bitirmek için sağ tıklayın.'}
                                </div>
                                <div>
                                    <label className="mb-2 block text-sm font-medium text-gray-700">
                                        Şekil Tipi
                                    </label>
                                    <div className="flex gap-4">
                                        <label className="inline-flex items-center">
                                            <input
                                                type="radio"
                                                className="form-radio text-indigo-600"
                                                name="polygonType"
                                                value="Polygon"
                                                checked={
                                                    polygonData.type ===
                                                    'Polygon'
                                                }
                                                onChange={() =>
                                                    setPolygonData(
                                                        'type',
                                                        'Polygon',
                                                    )
                                                }
                                                disabled={!!editingPolygonId}
                                            />
                                            <span className="ml-2 text-sm text-gray-700">
                                                Poligon (Kapalı Alan)
                                            </span>
                                        </label>
                                        <label className="inline-flex items-center">
                                            <input
                                                type="radio"
                                                className="form-radio text-indigo-600"
                                                name="polygonType"
                                                value="LineString"
                                                checked={
                                                    polygonData.type ===
                                                    'LineString'
                                                }
                                                onChange={() =>
                                                    setPolygonData(
                                                        'type',
                                                        'LineString',
                                                    )
                                                }
                                                disabled={!!editingPolygonId}
                                            />
                                            <span className="ml-2 text-sm text-gray-700">
                                                Çizgi (Yol, Sınır vb.)
                                            </span>
                                        </label>
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">
                                        İsim
                                    </label>
                                    <input
                                        type="text"
                                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                                        value={polygonData.name}
                                        onChange={(e) =>
                                            setPolygonData(
                                                'name',
                                                e.target.value,
                                            )
                                        }
                                    />
                                    {errorsPolygon.name && (
                                        <div className="text-sm text-red-600">
                                            {errorsPolygon.name}
                                        </div>
                                    )}
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">
                                        Kategori
                                    </label>
                                    <div className="mt-1 flex gap-2">
                                        <select
                                            className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                                            value={polygonData.category_id}
                                            onChange={(e) =>
                                                setPolygonData(
                                                    'category_id',
                                                    e.target.value,
                                                )
                                            }
                                        >
                                            <option value="">Seçiniz...</option>
                                            {categories.map((cat) => (
                                                <option
                                                    key={cat.id}
                                                    value={cat.id}
                                                >
                                                    {cat.name}
                                                </option>
                                            ))}
                                        </select>
                                        <button
                                            type="button"
                                            onClick={() =>
                                                resetCategoryForm() ||
                                                setShowCategoryForm(
                                                    !showCategoryForm,
                                                )
                                            }
                                            className="inline-flex items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium leading-4 text-gray-700 shadow-sm hover:bg-gray-50"
                                        >
                                            + Ekle
                                        </button>
                                        {polygonData.category_id && (
                                            <button
                                                type="button"
                                                onClick={() =>
                                                    openEditCategory(
                                                        polygonData.category_id,
                                                    )
                                                }
                                                className="inline-flex items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium leading-4 text-gray-700 shadow-sm hover:bg-gray-50"
                                            >
                                                ✎ Düzenle
                                            </button>
                                        )}
                                    </div>
                                    {errorsPolygon.category_id && (
                                        <div className="text-sm text-red-600">
                                            {errorsPolygon.category_id}
                                        </div>
                                    )}

                                    {showCategoryForm && (
                                        <div className="mt-2 rounded-md border bg-gray-50 p-3 shadow-inner">
                                            <label className="block text-xs font-medium text-gray-700">
                                                {editingCategoryId
                                                    ? 'Kategoriyi Düzenle'
                                                    : 'Yeni Şekil Kategorisi'}
                                            </label>
                                            <div className="mt-1 flex flex-col gap-2">
                                                <input
                                                    type="text"
                                                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                                                    value={newCategoryName}
                                                    onChange={(e) =>
                                                        setNewCategoryName(
                                                            e.target.value,
                                                        )
                                                    }
                                                    placeholder="Kategori adı"
                                                />

                                                <div className="flex items-center gap-2">
                                                    <div className="w-full flex-1">
                                                        <label className="mb-2 block text-[10px] uppercase text-gray-500">
                                                            İkon Seç (
                                                            {
                                                                Object.keys(
                                                                    AvailableIcons,
                                                                ).length
                                                            }{' '}
                                                            ikon)
                                                        </label>
                                                        <div className="grid max-h-40 grid-cols-6 gap-2 overflow-y-auto rounded-md border border-gray-300 bg-white p-2">
                                                            {Object.entries(
                                                                AvailableIcons,
                                                            ).map(
                                                                ([
                                                                    key,
                                                                    IconComponent,
                                                                ]) => (
                                                                    <button
                                                                        key={
                                                                            key
                                                                        }
                                                                        type="button"
                                                                        onClick={() =>
                                                                            setNewCategoryIcon(
                                                                                key,
                                                                            )
                                                                        }
                                                                        className={`flex items-center justify-center rounded border p-2 transition-colors ${
                                                                            newCategoryIcon ===
                                                                            key
                                                                                ? 'border-indigo-600 bg-indigo-50 text-indigo-700'
                                                                                : 'border-transparent text-gray-600 hover:bg-gray-100'
                                                                        }`}
                                                                        title={
                                                                            key
                                                                        }
                                                                    >
                                                                        <IconComponent
                                                                            size={
                                                                                20
                                                                            }
                                                                        />
                                                                    </button>
                                                                ),
                                                            )}
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <label className="mb-2 block text-[10px] uppercase text-gray-500">
                                                            Renk
                                                        </label>
                                                        <input
                                                            type="color"
                                                            className="block h-12 w-12 cursor-pointer rounded-md border-gray-300 shadow-sm"
                                                            value={
                                                                newCategoryColor
                                                            }
                                                            onChange={(e) =>
                                                                setNewCategoryColor(
                                                                    e.target
                                                                        .value,
                                                                )
                                                            }
                                                        />
                                                    </div>
                                                </div>

                                                <div className="rounded-md border border-gray-200 bg-white p-2">
                                                    <label className="mb-2 block text-[10px] uppercase text-gray-500">
                                                        Görünürlük Zoom Aralığı
                                                    </label>
                                                    <div className="mb-2">
                                                        <label className="mb-1 flex justify-between text-xs font-medium text-gray-700">
                                                            <span>
                                                                Yakınlaşma
                                                                (Min):{' '}
                                                                {formatScale(
                                                                    newCategoryMaxZoom,
                                                                )}
                                                            </span>
                                                            <span>
                                                                Uzaklaşma
                                                                (Maks):{' '}
                                                                {formatScale(
                                                                    newCategoryMinZoom,
                                                                )}
                                                            </span>
                                                        </label>
                                                        <DualRangeSlider
                                                            minVal={
                                                                newCategoryMinZoom
                                                            }
                                                            maxVal={
                                                                newCategoryMaxZoom
                                                            }
                                                            setMinVal={
                                                                setNewCategoryMinZoom
                                                            }
                                                            setMaxVal={
                                                                setNewCategoryMaxZoom
                                                            }
                                                            maxZoomLimit={
                                                                mapConfig.ADMIN_MAX_ZOOM
                                                            }
                                                        />
                                                        <div className="mt-4 flex items-start gap-2">
                                                            <input
                                                                type="checkbox"
                                                                id="new-border-visible-poly"
                                                                checked={
                                                                    newCategoryBorderAlwaysVisible
                                                                }
                                                                onChange={(e) =>
                                                                    setNewCategoryBorderAlwaysVisible(
                                                                        e.target
                                                                            .checked,
                                                                    )
                                                                }
                                                                className="mt-0.5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                                                            />
                                                            <label
                                                                htmlFor="new-border-visible-poly"
                                                                className="text-xs text-gray-600"
                                                            >
                                                                Görsel kaybolsa
                                                                bile poligon
                                                                sınırlarını her
                                                                zaman göster
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className="mt-1 flex gap-2">
                                                    {editingCategoryId && (
                                                        <button
                                                            type="button"
                                                            onClick={() =>
                                                                deleteCategory(
                                                                    editingCategoryId,
                                                                )
                                                            }
                                                            className="inline-flex flex-1 items-center justify-center rounded-md border border-transparent bg-red-600 px-3 py-2 text-sm font-medium leading-4 text-white shadow-sm hover:bg-red-700"
                                                        >
                                                            Sil
                                                        </button>
                                                    )}
                                                    <button
                                                        type="button"
                                                        onClick={submitCategory}
                                                        disabled={
                                                            isSubmittingCategory
                                                        }
                                                        className="inline-flex flex-1 items-center justify-center rounded-md border border-transparent bg-indigo-600 px-3 py-2 text-sm font-medium leading-4 text-white shadow-sm hover:bg-indigo-700"
                                                    >
                                                        {editingCategoryId
                                                            ? 'Güncelle'
                                                            : 'Ekle'}
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">
                                        Koordinat Sayısı
                                    </label>
                                    <input
                                        type="text"
                                        readOnly
                                        className="mt-1 block w-full rounded-md border-gray-300 bg-gray-50 text-gray-500 shadow-sm sm:text-sm"
                                        value={
                                            polygonData.coordinates.length +
                                            ' nokta çizildi'
                                        }
                                    />
                                    {errorsPolygon.coordinates && (
                                        <div className="text-sm text-red-600">
                                            {errorsPolygon.coordinates}
                                        </div>
                                    )}
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">
                                        Bağlı Olduğu Element (Ebeveyn)
                                    </label>
                                    <ParentSelector
                                        value={`${polygonData.parent_type || ''}|${polygonData.parent_id || ''}`}
                                        onChange={(val) => {
                                            if (val === '|') {
                                                setPolygonData((prev) => ({
                                                    ...prev,
                                                    parent_type: '',
                                                    parent_id: '',
                                                }));
                                            } else {
                                                const [type, id] =
                                                    val.split('|');
                                                setPolygonData((prev) => ({
                                                    ...prev,
                                                    parent_type: type,
                                                    parent_id: id,
                                                }));
                                            }
                                        }}
                                        polygons={polygons}
                                        markers={markers}
                                        categories={categories}
                                        editingId={editingPolygonId}
                                        editingType="polygon"
                                    />
                                </div>
                                <div className="mt-4 flex items-center">
                                    <input
                                        id="polygon_hide_symbology"
                                        type="checkbox"
                                        className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                                        checked={polygonData.hide_symbology}
                                        onChange={(e) =>
                                            setPolygonData({
                                                ...polygonData,
                                                hide_symbology:
                                                    e.target.checked,
                                            })
                                        }
                                    />
                                    <label
                                        htmlFor="polygon_hide_symbology"
                                        className="ml-2 block text-sm text-gray-900"
                                    >
                                        Sembolojiyi Gizle (Haritada görünmez
                                        yap)
                                    </label>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">
                                        Açıklama (Markdown Destekli)
                                    </label>
                                    <p className="mb-1 text-xs text-gray-500">
                                        Metin içi kalınlaştırma (**kalın**),
                                        liste, link
                                        ([Google](https://google.com)) gibi
                                        Markdown özelliklerini
                                        kullanabilirsiniz.
                                    </p>
                                    <textarea
                                        rows={3}
                                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                                        value={polygonData.description}
                                        onChange={(e) =>
                                            setPolygonData(
                                                'description',
                                                e.target.value,
                                            )
                                        }
                                    />
                                </div>

                                <div className="border-t pt-4">
                                    <div className="mb-2 flex items-center justify-between">
                                        <label className="block text-sm font-medium text-gray-700">
                                            Ekstra Bağlantılar (Linkler)
                                        </label>
                                        <button
                                            type="button"
                                            onClick={() =>
                                                setPolygonData('links', [
                                                    ...polygonData.links,
                                                    { title: '', url: '' },
                                                ])
                                            }
                                            className="text-xs font-medium text-indigo-600 hover:text-indigo-800"
                                        >
                                            + Yeni Link Ekle
                                        </button>
                                    </div>
                                    <div className="space-y-2">
                                        {polygonData.links.map(
                                            (link, index) => (
                                                <div
                                                    key={index}
                                                    className="flex items-center gap-2"
                                                >
                                                    <input
                                                        type="text"
                                                        placeholder="Link Başlığı"
                                                        className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                                                        value={link.title}
                                                        onChange={(e) => {
                                                            const newLinks = [
                                                                ...polygonData.links,
                                                            ];
                                                            newLinks[
                                                                index
                                                            ].title =
                                                                e.target.value;
                                                            setPolygonData(
                                                                'links',
                                                                newLinks,
                                                            );
                                                        }}
                                                    />
                                                    <input
                                                        type="url"
                                                        placeholder="https://..."
                                                        className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                                                        value={link.url}
                                                        onChange={(e) => {
                                                            const newLinks = [
                                                                ...polygonData.links,
                                                            ];
                                                            newLinks[
                                                                index
                                                            ].url =
                                                                e.target.value;
                                                            setPolygonData(
                                                                'links',
                                                                newLinks,
                                                            );
                                                        }}
                                                    />
                                                    <button
                                                        type="button"
                                                        className="px-2 font-bold text-red-500 hover:text-red-700"
                                                        onClick={() => {
                                                            const newLinks = [
                                                                ...polygonData.links,
                                                            ];
                                                            newLinks.splice(
                                                                index,
                                                                1,
                                                            );
                                                            setPolygonData(
                                                                'links',
                                                                newLinks,
                                                            );
                                                        }}
                                                    >
                                                        ×
                                                    </button>
                                                </div>
                                            ),
                                        )}
                                    </div>
                                </div>

                                <ImageUploader
                                    existingImages={polygonData.existing_images}
                                    newImages={polygonData.new_images}
                                    onExistingRemove={(idx) => {
                                        const updated = [
                                            ...polygonData.existing_images,
                                        ];
                                        updated.splice(idx, 1);
                                        setPolygonData(
                                            'existing_images',
                                            updated,
                                        );
                                    }}
                                    onNewAdd={(files) => {
                                        setPolygonData('new_images', [
                                            ...polygonData.new_images,
                                            ...files,
                                        ]);
                                    }}
                                    onNewRemove={(idx) => {
                                        const updated = [
                                            ...polygonData.new_images,
                                        ];
                                        updated.splice(idx, 1);
                                        setPolygonData('new_images', updated);
                                    }}
                                />

                                <button
                                    type="submit"
                                    disabled={
                                        processingPolygon ||
                                        polygonData.coordinates.length < 3
                                    }
                                    className="w-full rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-indigo-700 disabled:bg-indigo-400"
                                >
                                    {editingPolygonId
                                        ? 'Poligon Güncelle'
                                        : 'Poligon Kaydet'}
                                </button>
                            </form>
                        )}

                        {activeTab === 'import-export' && (
                            <div className="space-y-6">
                                <div>
                                    <h4 className="mb-2 border-b pb-1 font-semibold text-gray-700">
                                        Dışa Aktar (GeoJSON)
                                    </h4>
                                    <p className="mb-3 text-xs text-gray-500">
                                        Tüm kategorileri, işaretçileri ve
                                        poligonları QGIS ve ArcGIS uyumlu
                                        standart GeoJSON (.geojson) formatında
                                        indirir.
                                    </p>
                                    <a
                                        href={route('export')}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="inline-flex w-full justify-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-indigo-700"
                                    >
                                        Tüm Verileri İndir (.geojson)
                                    </a>
                                </div>

                                <div className="mt-8 border-t pt-6">
                                    <h4 className="mb-2 pb-1 font-semibold text-gray-700">
                                        Akıllı GeoJSON / GeoPackage İçe Aktar
                                    </h4>
                                    <p className="mb-3 text-xs text-gray-500">
                                        QGIS, ArcGIS gibi sistemlerden aldığınız
                                        .geojson veya .gpkg dosyalarını
                                        haritadaki kategorilerle eşleştirerek
                                        içeri aktarın.
                                    </p>
                                    <button
                                        onClick={() =>
                                            setIsGeoJsonModalOpen(true)
                                        }
                                        className="inline-flex w-full justify-center rounded-md bg-green-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-green-700"
                                    >
                                        Akıllı GeoJSON Sihirbazını Aç
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>

            <GeoJsonImportModal
                isOpen={isGeoJsonModalOpen}
                onClose={() => setIsGeoJsonModalOpen(false)}
                categories={categories}
            />
        </AuthenticatedLayout>
    );
};

export default Index;
