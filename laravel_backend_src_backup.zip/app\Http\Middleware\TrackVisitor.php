<?php

namespace App\Http\Middleware;

use App\Models\PageVisit;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class TrackVisitor
{
    /**
     * Handle an incoming request.
     *
     * @param  Closure(Request): (Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        // Yalnızca GET isteklerini takip et (API veya form gönderimlerini yoksayabiliriz)
        if ($request->isMethod('GET') && ! $request->ajax()) {
            $sessionId = session()->getId();
            $date = now()->toDateString();

            if ($sessionId) {
                PageVisit::firstOrCreate([
                    'visit_date' => $date,
                    'session_id' => $sessionId,
                ], [
                    'user_id' => auth()->id(),
                ]);
            }
        }

        return $next($request);
    }
}
