<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('markers', function (Blueprint $table) {
            $table->id();

            // 1. İLİŞKİLER (Kimin tarafından ve hangi kategoride eklendiği)
            // Kullanıcı silinirse işaretçi kalsın ama kimin eklediği 'null' olsun
            $table->foreignId('user_id')->nullable()->constrained()->nullOnDelete();

            // Kategori silinmek istenirse, eğer o kategoriye ait işaretçi varsa silinmesini engelle
            $table->foreignId('category_id')->constrained()->restrictOnDelete();

            // 2. TEMEL BİLGİLER (İsmi ve Açıklaması)
            $table->string('name');
            $table->text('description')->nullable();

            // 3. LOKASYON (PostGIS Point Geometrisi)
            // 4326 (WGS84), haritalardaki standart GPS enlem/boylam sistemidir.
            $table->geometry('location', subtype: 'point', srid: 4326);

            // 4. ZAMAN DAMGALARI (Ne zaman eklendiği / güncellendiği)
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('markers');
    }
};
