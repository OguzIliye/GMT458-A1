<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Marker;
use App\Models\Polygon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Inertia\Inertia;
use Inertia\Response;

class MarkerController extends Controller
{
    /**
     * Yönetim panelinde Marker (işaretçi) listesini ve haritayı göstermek için kullanılır.
     * Veritabanındaki PostGIS koordinat verisini enlem (latitude) ve boylam (longitude) olarak parçalayarak alır.
     */
    public function index(): Response
    {
        // Select ST_X(location) as longitude and ST_Y(location) as latitude
        // Veritabanındaki "location" (Point) sütununu haritada kullanabilmek için enlem ve boylama ayırıyoruz.
        $markers = Marker::with('category')->select(
            'id', 'name', 'description', 'category_id', 'user_id', 'created_at', 'link',
            'parent_id', 'parent_type',
            DB::raw('ST_X(location::geometry) as longitude'),
            DB::raw('ST_Y(location::geometry) as latitude')
        )->get();

        // Admin ekranında parent seçimi yapabilmek için tüm poligonları da çekmemiz iyi olur,
        // ama bunu frontend'den api ile de alabiliriz veya sayfa yüklendiğinde gönderebiliriz.
        // Ancak admin/markers/index'te sadece markerlar listelendiği için, poligonları ve diğer markerları göndereceğiz.
        $allPolygons = Polygon::with('category')->select('id', 'name', 'category_id')->get();
        $categories = Category::all();

        return Inertia::render('Admin/Markers/Index', [
            'markers' => $markers,
            'polygons' => $allPolygons,
            'categories' => $categories,
        ]);
    }

    /**
     * Yeni bir marker (işaretçi) oluşturup veritabanına kaydeder.
     */
    public function store(Request $request): RedirectResponse
    {
        // Formdan gelen verilerin doğrulanması
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'link' => 'nullable|url|max:255',
            'links' => 'nullable|array',
            'links.*.title' => 'required|string|max:255',
            'links.*.url' => 'required|url|max:255',
            'category_id' => 'required|exists:categories,id',
            'latitude' => 'required|numeric|between:-90,90',
            'longitude' => 'required|numeric|between:-180,180',
            'parent_id' => 'nullable|integer',
            'parent_type' => 'nullable|string|in:App\Models\Marker,App\Models\Polygon',
            'new_images' => 'nullable|array',
            'new_images.*' => 'image|max:5120', // 5MB limit
            'hide_symbology' => 'boolean',
        ]);

        $imagePaths = [];
        if ($request->hasFile('new_images')) {
            foreach ($request->file('new_images') as $image) {
                $path = $image->store('elements', 'public');
                $imagePaths[] = $path;
            }
        }

        $marker = new Marker;
        $marker->name = $validated['name'];
        $marker->description = $validated['description'];
        $marker->link = $validated['link'] ?? null;
        $marker->links = $validated['links'] ?? null;
        $marker->category_id = $validated['category_id'];
        $marker->parent_id = $validated['parent_id'] ?? null;
        $marker->parent_type = $validated['parent_type'] ?? null;
        $marker->hide_symbology = $request->boolean('hide_symbology');
        $marker->images = $imagePaths;

        // İşlemi yapan kullanıcının ID'sini kaydet
        /** @phpstan-ignore-next-line */
        $marker->user_id = auth()->id();

        // PostGIS point insertion (Boylam ve Enlem verisini haritanın anlayacağı PostGIS Point veri tipine dönüştürerek kaydet)
        /** @phpstan-ignore-next-line */
        $marker->location = DB::raw("ST_SetSRID(ST_MakePoint({$validated['longitude']}, {$validated['latitude']}), 4326)");
        $marker->save();

        // İşlem başarılı olduktan sonra sayfayı yenile ve başarı mesajı göster
        return redirect()->back()->with('success', 'Marker başarıyla eklendi.');
    }

    /**
     * Var olan bir işaretçinin (marker) bilgilerini veya konumunu günceller.
     */
    public function update(Request $request, Marker $marker): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'link' => 'nullable|url|max:255',
            'links' => 'nullable|array',
            'links.*.title' => 'required|string|max:255',
            'links.*.url' => 'required|url|max:255',
            'category_id' => 'required|exists:categories,id',
            'latitude' => 'required|numeric|between:-90,90',
            'longitude' => 'required|numeric|between:-180,180',
            'parent_id' => 'nullable|integer',
            'parent_type' => 'nullable|string|in:App\Models\Marker,App\Models\Polygon',
            'new_images' => 'nullable|array',
            'new_images.*' => 'image|max:5120', // 5MB limit
            'existing_images' => 'nullable|array',
            'existing_images.*' => 'string',
            'hide_symbology' => 'boolean',
        ]);

        $currentImages = $marker->images ?? [];
        $keptImages = $request->input('existing_images', []);
        $removedImages = array_diff($currentImages, $keptImages);

        // Remove deleted images from storage
        foreach ($removedImages as $removed) {
            Storage::disk('public')->delete($removed);
        }

        $imagePaths = $keptImages;

        // Add new images
        if ($request->hasFile('new_images')) {
            foreach ($request->file('new_images') as $image) {
                $path = $image->store('elements', 'public');
                $imagePaths[] = $path;
            }
        }

        $marker->name = $validated['name'];
        $marker->description = $validated['description'];
        $marker->link = $validated['link'] ?? null;
        $marker->links = $validated['links'] ?? null;
        $marker->category_id = $validated['category_id'];
        $marker->parent_id = $validated['parent_id'] ?? null;
        $marker->parent_type = $validated['parent_type'] ?? null;
        $marker->hide_symbology = $request->boolean('hide_symbology');
        $marker->images = array_values($imagePaths);

        // Kendi kendisinin ebeveyni olmasını engelle
        if ($marker->parent_type === 'App\Models\Marker' && (int) $marker->parent_id === (int) $marker->id) {
            $marker->parent_id = null;
            $marker->parent_type = null;
        }

        /** @phpstan-ignore-next-line */
        $marker->location = DB::raw("ST_SetSRID(ST_MakePoint({$validated['longitude']}, {$validated['latitude']}), 4326)");
        $marker->save();

        return redirect()->back()->with('success', 'Marker başarıyla güncellendi.');
    }

    /**
     * Belirtilen işaretçiyi veritabanından tamamen siler.
     */
    public function destroy(Marker $marker): RedirectResponse
    {
        $marker->delete();

        return redirect()->back()->with('success', 'Marker başarıyla silindi.');
    }

    /**
     * Silinmiş işaretçiyi geri getirir (Restore).
     */
    public function restore(int|string $id): RedirectResponse
    {
        /** @var Marker $marker */
        $marker = Marker::withTrashed()->findOrFail($id);
        $marker->restore();

        return redirect()->back()->with('success', 'Marker başarıyla geri getirildi.');
    }
}
