import { useEffect, useRef } from 'react';

export default function ContextMenu({ x, y, items, onClose }) {
    const menuRef = useRef(null);

    useEffect(() => {
        const handleClickOutside = (e) => {
            if (menuRef.current && !menuRef.current.contains(e.target)) {
                onClose();
            }
        };

        const handleEscape = (e) => {
            if (e.key === 'Escape') {
                onClose();
            }
        };

        // Add a small delay to avoid immediately closing from the right-click event itself
        setTimeout(() => {
            document.addEventListener('click', handleClickOutside);
            document.addEventListener('contextmenu', handleClickOutside);
            document.addEventListener('keydown', handleEscape);
        }, 10);

        return () => {
            document.removeEventListener('click', handleClickOutside);
            document.removeEventListener('contextmenu', handleClickOutside);
            document.removeEventListener('keydown', handleEscape);
        };
    }, [onClose]);

    // Ensure the menu stays within viewport
    const menuStyle = {
        position: 'fixed',
        top: Math.min(y, window.innerHeight - (items.length * 40 + 20)),
        left: Math.min(x, window.innerWidth - 200),
        zIndex: 9999, // Ensure it's above everything
    };

    return (
        <div
            ref={menuRef}
            style={menuStyle}
            className="flex w-48 flex-col rounded-md border border-gray-200 bg-white py-1 shadow-xl"
            onContextMenu={(e) => e.preventDefault()} // Prevent native context menu on our custom one
        >
            {items.map((item, index) => {
                if (item === 'separator') {
                    return (
                        <div
                            key={`sep-${index}`}
                            className="mx-2 my-1 h-px bg-gray-200"
                        />
                    );
                }

                return (
                    <button
                        key={index}
                        onClick={(e) => {
                            e.stopPropagation();
                            item.onClick();
                            onClose();
                        }}
                        className={`px-4 py-2 text-left text-sm hover:bg-gray-100 ${
                            item.danger
                                ? 'text-red-600 hover:text-red-700'
                                : 'text-gray-700'
                        }`}
                    >
                        {item.label}
                    </button>
                );
            })}
        </div>
    );
}
