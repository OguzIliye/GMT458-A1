<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title inertia>{{ config('app.name', 'Laravel') }}</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        @routes
        @viteReactRefresh
        @vite(['resources/js/app.tsx'])
        @inertiaHead
    </head>
    <body class="font-sans antialiased">
        <style>
            #global-loader {
                position: fixed;
                inset: 0;
                background-color: #020617; /* slate-950 */
                z-index: 999999;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                transition: opacity 0.5s ease;
            }
            .loader-spinner {
                width: 48px;
                height: 48px;
                border: 4px solid #10b981; /* emerald-500 */
                border-bottom-color: transparent;
                border-radius: 50%;
                display: inline-block;
                box-sizing: border-box;
                animation: rotation 1s linear infinite;
                margin-bottom: 16px;
            }
            .loader-text {
                color: #34d399; /* emerald-400 */
                font-family: ui-sans-serif, system-ui, sans-serif;
                font-size: 14px;
                letter-spacing: 2px;
                text-transform: uppercase;
                font-weight: 600;
            }
            @keyframes rotation {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        </style>
        <div id="global-loader">
            <span class="loader-spinner"></span>
            <span class="loader-text">AHBVÜ Harita Yükleniyor...</span>
        </div>
        <script>
            window.addEventListener('load', function() {
                const loader = document.getElementById('global-loader');
                if (loader) {
                    loader.style.opacity = '0';
                    setTimeout(() => loader.remove(), 500);
                }
            });
        </script>

        @inertia
    </body>
</html>
