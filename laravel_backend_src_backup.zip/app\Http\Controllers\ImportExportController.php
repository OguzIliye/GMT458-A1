<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Marker;
use App\Models\Polygon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Process;
use Illuminate\Support\Facades\Storage;

class ImportExportController extends Controller
{
    public function export(): JsonResponse
    {
        $categories = Category::all()->keyBy('id');

        $features = [];

        // Markers
        $markers = Marker::select(
            'id', 'name', 'description', 'category_id', 'user_id', 'created_at', 'link',
            DB::raw('ST_X(location::geometry) as longitude'),
            DB::raw('ST_Y(location::geometry) as latitude')
        )->get();

        foreach ($markers as $marker) {
            $cat = $marker->category_id ? $categories->get($marker->category_id) : null;
            $features[] = [
                'type' => 'Feature',
                'geometry' => [
                    'type' => 'Point',
                    /** @phpstan-ignore-next-line */
                    'coordinates' => [(float) $marker->longitude, (float) $marker->latitude],
                ],
                'properties' => [
                    'id' => $marker->id,
                    'name' => $marker->name,
                    'description' => $marker->description,
                    'link' => $marker->link,
                    'category_name' => $cat ? $cat->name : null,
                    'category_type' => $cat ? $cat->type : null,
                    'category_color' => $cat ? $cat->color : null,
                    'category_icon' => $cat ? $cat->icon : null,
                ],
            ];
        }

        // Polygons and LineStrings
        $polygons = Polygon::select(
            'id', 'name', 'description', 'category_id', 'user_id', 'created_at', 'link',
            DB::raw('ST_AsGeoJSON(area) as geojson')
        )->get();

        foreach ($polygons as $poly) {
            $cat = $poly->category_id ? $categories->get($poly->category_id) : null;
            /** @phpstan-ignore-next-line */
            $geometry = json_decode($poly->geojson, true);

            $features[] = [
                'type' => 'Feature',
                'geometry' => $geometry,
                'properties' => [
                    'id' => $poly->id,
                    'name' => $poly->name,
                    'description' => $poly->description,
                    'link' => $poly->link,
                    'category_name' => $cat ? $cat->name : null,
                    'category_type' => $cat ? $cat->type : null,
                    'category_color' => $cat ? $cat->color : null,
                    'category_icon' => $cat ? $cat->icon : null,
                ],
            ];
        }

        $geojsonFeatureCollection = [
            'type' => 'FeatureCollection',
            'features' => $features,
        ];

        return response()->json($geojsonFeatureCollection)->header('Content-Disposition', 'attachment; filename="harita_verileri.geojson"');
    }

    public function importGeoJson(Request $request): RedirectResponse
    {
        $request->validate([
            'features' => 'required|array',
            'mapping' => 'required|array',
            'property_key' => 'required|string',
        ]);

        $features = $request->input('features');
        $mapping = $request->input('mapping');
        $propertyKey = $request->input('property_key');
        $userId = auth()->id();

        DB::beginTransaction();

        try {
            // 1. Yeni kategorileri oluştur ve ID'leri çöz
            $resolvedCategoryIds = [];
            foreach ($mapping as $val => $mapData) {
                if ($mapData['type'] === 'new') {
                    $newCat = Category::create([
                        'name' => $mapData['newName'] ?: $val,
                        'type' => 'polygon',
                        'color' => $mapData['newColor'],
                        'icon' => $mapData['newIcon'],
                    ]);
                    $resolvedCategoryIds[$val] = $newCat->id;
                } else {
                    $resolvedCategoryIds[$val] = $mapData['categoryId'];
                }
            }

            // 2. Şekilleri veritabanına kaydet
            foreach ($features as $feature) {
                if (! isset($feature['geometry']) || ! isset($feature['geometry']['type'])) {
                    continue;
                }

                $geomType = $feature['geometry']['type'];
                $coords = $feature['geometry']['coordinates'] ?? [];
                if (empty($coords)) {
                    continue;
                }

                $properties = $feature['properties'] ?? [];
                $val = isset($properties[$propertyKey]) ? (string) $properties[$propertyKey] : null;
                // Eşleşme yoksa null kalsın
                $categoryId = ($val !== null && $val !== '') ? ($resolvedCategoryIds[$val] ?? null) : null;

                $name = $properties['name'] ?? ($val ?? 'Adsız Şekil');
                $desc = $properties['description'] ?? null;

                $wkt = null;
                if ($geomType === 'Polygon') {
                    $wktPoints = [];
                    foreach ($coords[0] as $point) {
                        $wktPoints[] = $point[0].' '.$point[1];
                    }
                    $wkt = 'POLYGON(('.implode(',', $wktPoints).'))';
                } elseif ($geomType === 'LineString') {
                    $wktPoints = [];
                    foreach ($coords as $point) {
                        $wktPoints[] = $point[0].' '.$point[1];
                    }
                    $wkt = 'LINESTRING('.implode(',', $wktPoints).')';
                } elseif ($geomType === 'MultiLineString') {
                    // Destekliyorsak MultiLineString, sadece ilk çizgiyi alalım veya MultiLineString WKT yazalım
                    $wktLines = [];
                    foreach ($coords as $line) {
                        $linePoints = [];
                        foreach ($line as $point) {
                            $linePoints[] = $point[0].' '.$point[1];
                        }
                        $wktLines[] = '('.implode(',', $linePoints).')';
                    }
                    $wkt = 'MULTILINESTRING('.implode(',', $wktLines).')';
                } elseif ($geomType === 'Point') {
                    $wkt = 'POINT('.$coords[0].' '.$coords[1].')';
                }

                if ($wkt) {
                    if ($geomType === 'Point') {
                        $marker = new Marker;
                        /** @phpstan-ignore-next-line */
                        $marker->user_id = $userId;
                        $marker->category_id = $categoryId;
                        $marker->name = $name;
                        $marker->description = $desc;
                        /** @phpstan-ignore-next-line */
                        $marker->location = DB::raw("ST_GeomFromText('".$wkt."', 4326)");
                        $marker->save();
                    } else {
                        $poly = new Polygon;
                        /** @phpstan-ignore-next-line */
                        $poly->user_id = $userId;
                        $poly->category_id = $categoryId;
                        $poly->name = $name;
                        $poly->description = $desc;
                        /** @phpstan-ignore-next-line */
                        $poly->area = DB::raw("ST_GeomFromText('".$wkt."', 4326)");
                        $poly->save();
                    }
                }
            }

            DB::commit();

            return redirect()->back()->with('success', 'GeoJSON verileri başarıyla içe aktarıldı.');
        } catch (\Exception $e) {
            DB::rollBack();

            return redirect()->back()->withErrors(['error' => 'GeoJSON içe aktarılırken hata oluştu: '.$e->getMessage()]);
        }
    }

    public function convertGpkg(Request $request): JsonResponse|Response
    {
        $request->validate([
            'file' => 'required|file',
        ]);

        /** @var UploadedFile $file */
        $file = $request->file('file');
        // Rastgele isim vererek çakışmaları önleyelim
        $filename = uniqid().'.gpkg';
        $path = $file->storeAs('temp', $filename);

        if ($path === false) {
            return response()->json(['error' => 'Dosya yüklenemedi.'], 500);
        }

        $fullPath = storage_path('app/'.$path);

        $scriptPath = base_path('scripts/gpkg_to_geojson.py');

        // Python script'ini çalıştır
        $process = Process::run("python \"{$scriptPath}\" \"{$fullPath}\"");

        // Geçici dosyayı sil
        Storage::delete($path);

        if (! $process->successful()) {
            return response()->json(['error' => 'GPKG dönüştürülemedi: '.$process->errorOutput()], 500);
        }

        $output = $process->output();

        return response($output, 200, ['Content-Type' => 'application/json']);
    }
}
