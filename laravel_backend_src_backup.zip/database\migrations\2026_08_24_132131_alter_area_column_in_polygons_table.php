<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Alan kolonunu her türlü geometriyi (Polygon, LineString vb.) kabul edecek şekilde güncelliyoruz
        if (DB::getDriverName() === 'pgsql') {
            DB::statement('ALTER TABLE polygons ALTER COLUMN area TYPE geometry(Geometry, 4326) USING area::geometry(Geometry, 4326)');
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Geri alındığında sadece poligonları destekleyecek eski tipe dön
        if (DB::getDriverName() === 'pgsql') {
            DB::statement('ALTER TABLE polygons ALTER COLUMN area TYPE geometry(Polygon, 4326) USING area::geometry(Polygon, 4326)');
        }
    }
};
