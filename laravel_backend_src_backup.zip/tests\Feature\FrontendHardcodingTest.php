<?php

it('does not contain any unwhitelisted hardcoded numbers in React components', function () {
    // List of allowed props that can have hardcoded numbers (like icon sizes, HTML input constraints)
    $allowedProps = [
        'size', 'strokeWidth', 'rows', 'cols', 'min', 'max', 'step', 'maxLength', 'tabIndex', 'zIndex', 'width', 'height',
    ];

    // Get all JS/TS/JSX/TSX files
    $files = [];
    $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(resource_path('js')));
    foreach ($iterator as $file) {
        if ($file->isFile() && preg_match("/\.(jsx?|tsx?)$/", $file->getFilename())) {
            $files[] = $file->getPathname();
        }
    }

    $foundHardcoded = [];

    foreach ($files as $file) {
        $content = file_get_contents($file);

        // Find any prop={number}
        if (preg_match_all("/\b([a-zA-Z0-9_]+)\s*=\s*\{\s*([0-9]+(\.[0-9]+)?)\s*\}/", $content, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $propName = $match[1];
                $value = $match[2];

                // If the prop is not in our allowed list, it is a magic number violation!
                if (! in_array($propName, $allowedProps)) {
                    $foundHardcoded[] = basename($file).' -> '.$propName.'={'.$value.'}';
                }
            }
        }
    }

    // We expect no hardcoded numbers outside the allowed UI props
    expect($foundHardcoded)->toBeEmpty('Found hardcoded magic numbers: '.implode(', ', array_unique($foundHardcoded)));
});
